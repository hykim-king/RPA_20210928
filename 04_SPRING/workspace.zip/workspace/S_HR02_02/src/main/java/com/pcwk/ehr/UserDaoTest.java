package com.pcwk.ehr;

import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class UserDaoTest {
	final static Logger LOG = LogManager.getLogger(UserDaoTest.class);
	
	UserDao dao;
	UserVO  user01;
	ApplicationContext  context;
	
	public UserDaoTest() {
		
		context = new AnnotationConfigApplicationContext(DaoFactory.class);
		
		dao = context.getBean("userDao", UserDao.class);
		LOG.debug("==============================");
		LOG.debug("=context="+context);
		LOG.debug("=dao="+dao);
		LOG.debug("==============================");			
		
		user01=new UserVO("PCWK01","이상무01","1234");
	}
	
	public void add() throws ClassNotFoundException,SQLException{
		int flag = dao.add(user01);
		if(1==flag) {
			LOG.debug("==============================");
			LOG.debug("=성공=");
			LOG.debug("==============================");				
		}		
	}
	
	public void get() throws ClassNotFoundException,SQLException{
		UserVO outVO = dao.get(user01);
		if(null!=outVO) {
			LOG.debug("==============================");
			LOG.debug("=성공=");
			LOG.debug("==============================");				
		}		
	}
	
	public static void main(String[] args) {
		UserDaoTest main=new UserDaoTest();
			
			try {
				//추가
				main.add();
				
				main.get();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		


	}
	

}
