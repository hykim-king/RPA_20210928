package com.pcwk.ehr;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 객체의 생성 방법을 결정하고
 * 그렇게 만들어진 오브젝트를 돌려 준다.
 * 
 * 제어의 역전이란 제어 흐름을 꺼꾸로 뒤집는 것이다.
 * 오브젝트가 자신이 사용할 오브젝트를 스스로 선택하지 않는다.								
 * 당연히 생성하지도 않는다. 모든 제어 권한을 자신이 아닌 다를 대상에게 위임한다.
 * @author HKEDU
 *
 */

//스프링 빈 팩토리를 위한 오브젝트 설정을 담당하는 클래스
@Configuration
public class DaoFactory {
	
	/**
	 * 객체의 생성 방법을 결정하고
	 * 그렇게 만들어진 오브젝트를 돌려 준다.
	 * @return
	 */
	//오브젝트를 만들어 주는 메소드
	@Bean
	public UserDao userDao() {
		UserDao dao=null;
		
		dao = new UserDao(connectionMaker());
		
		return dao;
	}
	
	@Bean
	public ConnectionMaker connectionMaker() {
		return new NConnectionMaker();
	}
	
	
	
	
}
