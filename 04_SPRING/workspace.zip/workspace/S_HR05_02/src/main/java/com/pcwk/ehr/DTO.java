package com.pcwk.ehr;

/**
 * 모든 Value Object 조상
 * @author HKEDU
 *
 */
public class DTO {

	public DTO() {
		// TODO Auto-generated constructor stub
	}

}
