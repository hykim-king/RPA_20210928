package com.pcwk.ehr.col;

import java.util.List;
import java.util.Set;

public class CollectionBeanSet {

	private Set<String>  addressList;
	
	
	public CollectionBeanSet() {
		// TODO Auto-generated constructor stub
	}


	public Set<String> getAddressList() {
		return addressList;
	}



	public void setAddressList(Set<String> addressList) {
		this.addressList = addressList;
	}

	
}
