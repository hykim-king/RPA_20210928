package com.pcwk.ehr.col;

import java.util.List;

public class CollectionBean {

	private List<String>  addressList;
	
	
	public CollectionBean() {
		// TODO Auto-generated constructor stub
	}


	public List<String> getAddressList() {
		return addressList;
	}



	public void setAddressList(List<String> addressList) {
		this.addressList = addressList;
	}

	
}
