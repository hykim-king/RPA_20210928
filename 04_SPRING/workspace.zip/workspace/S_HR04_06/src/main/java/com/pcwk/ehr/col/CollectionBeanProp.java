package com.pcwk.ehr.col;

import java.util.Properties;

public class CollectionBeanProp {

	private Properties  addressList;
	
	public Properties getAddressList() {
		return addressList;
	}

	public void setAddressList(Properties addressList) {
		this.addressList = addressList;
	}

	public CollectionBeanProp() {
		// TODO Auto-generated constructor stub
	}

}
