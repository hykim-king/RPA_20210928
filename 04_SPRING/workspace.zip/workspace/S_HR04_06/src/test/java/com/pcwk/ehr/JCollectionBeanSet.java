package com.pcwk.ehr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pcwk.ehr.col.CollectionBean;
import com.pcwk.ehr.col.CollectionBeanSet;

//메소드 수행 순선:asc
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContextSet.xml")
public class JCollectionBeanSet {
	final Logger  LOG = LogManager.getLogger(getClass());
	@Autowired
	ApplicationContext  context;
	CollectionBeanSet  collectionBeanSet;
	
	@Before
	public void setUp() throws Exception {
		collectionBeanSet = (CollectionBeanSet) context.getBean("collectionBeanSet");
		LOG.debug("================");
		LOG.debug("=context="+context);
		LOG.debug("=collectionBeanSet="+collectionBeanSet);
		LOG.debug("================");
		assertNotNull(context);
		assertNotNull(collectionBeanSet);
	}

	@Test
	public void test() {
		LOG.debug("================");
		LOG.debug("=test=");
		LOG.debug("================");	
		
		Set<String> list = collectionBeanSet.getAddressList();
		
		for(String str  :list) {
			LOG.debug(str);
		}
		
	}
	

	@After
	public void tearDown() throws Exception {
		LOG.debug("================");
		LOG.debug("=tearDown=");
		LOG.debug("================");			
	}	

}

