package com.pcwk.ehr;

import static org.junit.Assert.*;

import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pcwk.ehr.col.CollectionBeanProp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContextProp.xml")
public class JCollectionBeanProp {
    final Logger LOG = LogManager.getLogger(getClass());
    
    @Autowired
    ApplicationContext  context;
    
    @Autowired
    CollectionBeanProp  collectionBeanProp;
    
	@Before
	public void setUp() throws Exception {
		assertNotNull(context);
		assertNotNull(collectionBeanProp);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		Properties prop = collectionBeanProp.getAddressList();
		
		Set<Object> sets = prop.keySet();
		
		for (Object obj :sets) {
			LOG.debug(obj.toString()+","+prop.getProperty(obj.toString()));
		}
		
		
	}

}
