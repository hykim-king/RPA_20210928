package com.pcwk.ehr.anno.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pcwk.ehr.anno.domain.AnnoVO;
import com.pcwk.ehr.anno.service.AnnoService;

@Controller
public class AnnoController {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private AnnoService annoService;
	
	@RequestMapping(value="anno/annoView.do")
	public String annoView() {
		LOG.debug("annoView:");
		
		return "anno/anno";
	}
	
	
	@RequestMapping(value = "anno/doSelectOne.do",method = RequestMethod.POST)
	public String  doSelectOne(Model model,AnnoVO vo) throws SQLException{
		//String userId = req.getParameter("userId");
		//String passwd = req.getParameter("passwd");
		
		//LOG.debug("userId:"+userId);
		//LOG.debug("passwd:"+passwd);
		
		
		//AnnoVO  inVO=new AnnoVO();
		//inVO.setUserId(userId);
		//inVO.setPasswd(passwd);
		LOG.debug("vo:"+vo);
		AnnoVO outVO = annoService.doSelectOne(vo);
		model.addAttribute("vo", outVO);
		
		return "anno/anno";
	}
	
}
