package com.pcwk.ehr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
   final Logger  LOG = LoggerFactory.getLogger(getClass());
   
   //화면 요청 URL
   @RequestMapping(value = "main/main.do")
   public String hello(Model model) {
	   LOG.debug("========================");
	   LOG.debug("=hello=");
	   LOG.debug("========================");
	   
	  // /WEB-INF/views/ + main/main + .jsp
	   model.addAttribute("msg", "Hello, world!");
	   return "main/main";
   }
}
    