package com.pcwk.ehr.anno.service;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.anno.dao.AnnoDao;
import com.pcwk.ehr.anno.domain.AnnoVO;
/**
 *@Component를 상속한 @Service 이고 Service로 인식
 * @author HKEDU
 *
 *
 *
 *	<bean id="annoService" class="com.pcwk.ehr.anno.service.AnnoServiceImpl">
	   <property name="dao" ref="annoDao"/>
	</bean>
	
 */
@Service
public class AnnoServiceImpl implements AnnoService {
    final Logger LOG = LoggerFactory.getLogger(getClass());
	@Autowired
	AnnoDao dao;
	

	@Override
	public AnnoVO doSelectOne(Object inVO) throws SQLException {
		LOG.debug("-----------------");
		LOG.debug("-Service--");
		LOG.debug("-----------------");
		return dao.doSelectOne(inVO);
	}

}
