package com.pcwk.ehr.anno.dao;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.pcwk.ehr.anno.domain.AnnoVO;

/**
 * <bean id="annoDao" class="com.pcwk.ehr.anno.dao.AnnoDao"/>
 * @Component를 상속한 @Repository 이고 DAO로 인식
 * @author HKEDU
 *
 */

@Repository
public class AnnoDao {

	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	public AnnoDao() {}
	
	public AnnoVO  doSelectOne(Object inVO) throws SQLException{
		LOG.debug("========================");
		LOG.debug("=doSelectOne=");
		LOG.debug("========================");
		AnnoVO  vo = (AnnoVO) inVO;
		vo.setUserId(vo.getUserId()+"Call");
		vo.setPasswd(vo.getPasswd()+"DDD");
		
		return vo;
	}
	
}
