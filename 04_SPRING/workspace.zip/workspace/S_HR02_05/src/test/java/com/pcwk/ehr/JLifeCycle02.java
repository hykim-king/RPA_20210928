package com.pcwk.ehr;

import static org.junit.Assert.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JLifeCycle02 {

	final Logger LOG = LogManager.getLogger(getClass());
	@Before
	public void setUp() throws Exception {
		LOG.debug("===============");
		LOG.debug("=1 setUp()=");
		LOG.debug("===============");
	}

	@After
	public void tearDown() throws Exception {
		LOG.debug("===============");
		LOG.debug("=3 tearDown()=");
		LOG.debug("===============");		
	}

	@Test
	public void test01() {
		LOG.debug("===============");
		LOG.debug("=2 test01()=");
		LOG.debug("===============");
	}
	
	@Test
	public void test02() {
		LOG.debug("===============");
		LOG.debug("=2 test02()=");
		LOG.debug("===============");
	}	

}
