package com.pcwk.ehr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class JUserDaoTest {
    final Logger  LOG = LogManager.getLogger(getClass());
	
    ApplicationContext  context;
    UserDao dao;
    UserVO  user01;
    

	//org.junit.runners.model.TestTimedOutException: test timed out after 1 milliseconds
	@Test(timeout = 10000)
	public void addAndGet() {
		LOG.debug("====================");
		LOG.debug("=test()=");
		LOG.debug("====================");		
		
		//1. 전체삭제
		//2. 1건 입력
		//3. 건수 check
		//4. 데이터 1건 조회
		//5. 입력데이터와 비교
		try {
			//1.
			dao.deleteAll();
            //2.
		    int count = dao.add(user01);
		    assertEquals(count,1);
		    //assertThat(count, is(1));
		    //3.
		    int addNum = dao.getCount();
		    assertEquals(addNum, 1);
		    
		    //4.
		    UserVO outVO = dao.get(user01);
		    
		    //5.
		    assertEquals(user01.getuId(), outVO.getuId());
		    assertEquals(user01.getName(),outVO.getName());
		    assertEquals(user01.getPasswd(),outVO.getPasswd());
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	
	@Before
	public void setUp() throws Exception {
		user01 = new UserVO("PCWK01","이상무01","1234");
		
		context = new GenericXmlApplicationContext("applicationContext.xml");
		dao= (UserDao) context.getBean("userDao");
		
		
		LOG.debug("1====================");
		LOG.debug("1=context="+context);
		LOG.debug("1=dao="+dao);
		LOG.debug("1====================");
		assertNotNull(context);
		assertNotNull(dao);
	}

	@After
	public void tearDown() throws Exception {
		LOG.debug("0====================");
		LOG.debug("0=tearDown=");
		LOG.debug("0====================");		
	}

}
