package com.pcwk.ehr;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
//1. 메소드는 public으로 선언								
//
//2.메소드에 @Test를 붙여 준다.								

public class JTest01 {
    final Logger LOG = LogManager.getLogger(getClass());
	
    @Test
	public void test() {
		LOG.debug("======================");
		LOG.debug("=test()=");
		LOG.debug("======================");
	}

    @Test
    public void test02() {
		LOG.debug("======================");
		LOG.debug("=test02()=");
		LOG.debug("======================");   	
    }
    
    @Test
    public void test03() {
		LOG.debug("======================");
		LOG.debug("=test03()=");
		//fail();
		LOG.debug("======================");     	
    }
	
    
}
