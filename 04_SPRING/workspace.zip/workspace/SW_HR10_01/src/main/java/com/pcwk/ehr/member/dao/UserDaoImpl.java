package com.pcwk.ehr.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.stereotype.Repository;

import com.pcwk.ehr.member.domain.Level;
import com.pcwk.ehr.member.domain.UserVO;

/**
 *         <!-- dao -->
        <bean id="userDao" class="com.pcwk.ehr.member.dao.UserDaoImpl">
          <!-- setter통한 의존관계 주입 -->
          <property name="dataSource" ref="dataSource"/>
        </bean>
 * @author HKEDU
 *
 */
@Repository("userDao")
public class UserDaoImpl implements UserDao {
	final static Logger LOG = LogManager.getLogger(UserDaoImpl.class);
	
	@Autowired
	SqlSessionTemplate  sqlSessionTemplate;
	
	final String NAMESPACE = "com.pcwk.ehr.member";
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	RowMapper<UserVO>  rowMapper = new RowMapper<UserVO>() {

		public UserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserVO  user =new UserVO();
			user.setuId(rs.getString("u_id"));
			user.setName(rs.getString("name"));
			user.setPasswd(rs.getString("passwd")); 
			//1 -> BASIC
			user.setLevel(Level.valueOf(rs.getInt("u_level")));
			user.setLogin(  rs.getInt("login"));
			user.setRecommend(rs.getInt("recommend") );
			user.setEmail(rs.getString("email")); 
			user.setRegDt(rs.getString("reg_dt"));
			
			return user;
		}
		
	};
	
	public UserDaoImpl() {}


    //OK
	@SuppressWarnings("deprecation")
	public List<UserVO>  getAll(){
		List<UserVO>  list = new ArrayList<UserVO>();
		
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT                    \n");
		sb.append("     u_id,                 \n");
		sb.append("     name,                 \n");
		sb.append("     passwd,               \n");
		sb.append("     u_level,              \n");
		sb.append("     login,                \n");
		sb.append("     recommend,            \n");
		sb.append("     email,                \n");
		sb.append("     TO_CHAR(reg_dt,'yyyy/mm/dd hh24:mi:ss')  reg_dt              \n");
		sb.append(" FROM hr_member \n");
		sb.append(" ORDER BY u_id  \n");
		
		LOG.debug("sql=\n"+sb.toString());
		Object[] args = {};
		list = jdbcTemplate.query(sb.toString(), args, rowMapper);
		
		for(UserVO vo  :list) {
			LOG.debug("vo:"+vo);
		}
		
		
		
		return list;
	}

	/**
	 * OK
	 * 등록건수 
	 * @return
	 * @throws SQLException
	 */
	public int getCount() throws SQLException{
		int count = 0;
		String statement = NAMESPACE +".getCount";
		
		count = this.sqlSessionTemplate.selectOne(statement);
		LOG.debug("==============================");
		LOG.debug("=count="+count);
		LOG.debug("==============================");			
		
		return count;
	}

	
    /**OK
     * 전체 삭제 
     * @throws SQLException
     */
    public void deleteAll() throws SQLException{
    	String statement = NAMESPACE+".deleteAll";
    	LOG.debug("==============================");
		LOG.debug("=statement="+statement);
		LOG.debug("==============================");	
		
		int flag = this.sqlSessionTemplate.delete(statement);
		LOG.debug("==============================");
		LOG.debug("=flag="+flag);
		LOG.debug("==============================");    	
    }

	/**OK
	 * 사용자 등록 
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int doInsert(final UserVO inVO) throws SQLException{
		int flag = 0;
		String statement = NAMESPACE +".doInsert";
		
		LOG.debug("==============================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("==============================");	
		
		flag = this.sqlSessionTemplate.insert(statement, inVO);
	    LOG.debug("flag:"+flag);
		return flag;
	}
	
	/**OK
	 * 사용자 조회
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	@SuppressWarnings("deprecation")
	public UserVO doSelectOne(UserVO inVO) throws SQLException{
		UserVO outVO = null;
		String statement = NAMESPACE +".doSelectOne";
		
		LOG.debug("==============================");
		LOG.debug("=inVO="+inVO.toString());
		LOG.debug("=statement="+statement);
		LOG.debug("==============================");	
		
		
		outVO = sqlSessionTemplate.selectOne(statement, inVO);
		
		LOG.debug("==============================");
		LOG.debug("=outVO="+outVO.toString());
		LOG.debug("==============================");	
		return outVO;
	}

	public int doDelete(UserVO inVO) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int doUpdate(UserVO inVO) throws SQLException {
		int flag = 0;
		StringBuilder sb=new StringBuilder(300);
		sb.append(" UPDATE hr_member         \n");
		sb.append(" SET name       = ?       \n");
		sb.append("     ,passwd    = ?       \n");
		sb.append("     ,u_level   = ?       \n");
		sb.append("     ,login     = ?       \n");
		sb.append("     ,recommend = ?       \n");
		sb.append("     ,email     = ?       \n");
		sb.append("     ,reg_dt    = SYSDATE \n");
		sb.append(" WHERE u_id     = ?       \n");
		
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");		
		Object[] args = {inVO.getName(),inVO.getPasswd(),inVO.getLevel().getValue()
				        ,inVO.getLogin(),inVO.getRecommend(),inVO.getEmail(),inVO.getuId() };
		flag = jdbcTemplate.update(sb.toString(), args);
		LOG.debug("flag="+flag);
		return flag;
	}

	public List<UserVO> doRetrieve(Object inVO) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}
























