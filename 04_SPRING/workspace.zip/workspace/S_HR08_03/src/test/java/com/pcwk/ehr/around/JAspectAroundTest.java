package com.pcwk.ehr.around;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pcwk.ehr.aspectj.Member;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/aspectj/around-applicationContext.xml")
public class JAspectAroundTest {
    final Logger LOG = LogManager.getLogger(getClass());
	
	@Autowired
	ApplicationContext context;
	
	@Autowired
	Member member;
	@Test
	public void aroundAspect() {
//		- ^^^^^^^^^^^^^^^^^^^^^^^^
//		- [BEFORE] 메소드 수행 전
//		   - -----------------------
//		   - -doSave()-
//		   - -----------------------
//		- [AFTER] 메소드 수행 후
//		- ^^^^^^^^^^^^^^^^^^^^^^^^
		
		member.doSave();
	}
	
	
	@Test
	public void beans() {
		LOG.debug("beans");
		assertNotNull(context);
		assertNotNull(member);
	}

}
