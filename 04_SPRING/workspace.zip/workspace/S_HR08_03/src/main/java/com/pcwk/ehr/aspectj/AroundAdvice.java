package com.pcwk.ehr.aspectj;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;

public class AroundAdvice {

	final Logger LOG = LogManager.getLogger(getClass());
	
	
	public Object aroundLog(ProceedingJoinPoint pjp) throws Throwable{
		LOG.debug("^^^^^^^^^^^^^^^^^^^^^^^^");
		LOG.debug("[BEFORE] 메소드 수행 전");
		
		Object returnObj = pjp.proceed();
		
		LOG.debug("[AFTER] 메소드 수행 후");
		LOG.debug("^^^^^^^^^^^^^^^^^^^^^^^^");
		
		return returnObj;
	}
	
}
