package com.pcwk.ehr;

import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserService;

public class UserServiceTx implements UserService {
	final Logger  LOG = LogManager.getLogger(getClass());
	
	UserService userService;
	PlatformTransactionManager transactionManager;
	
	public UserServiceTx() {
		
	}
	
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}


	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void upgradeLevels() throws Exception {
		//트랜잭션 시작
		TransactionStatus  status = transactionManager.getTransaction(new DefaultTransactionDefinition());
		try {
			//------------------------------------
			userService.upgradeLevels();
			//------------------------------------
			
			transactionManager.commit(status); ;//정상적으로 작업을 마치면 트랜잭션 commit
		}catch(Exception e) {
			LOG.debug("===================================");
			LOG.debug("=rollback*****=");
			LOG.debug("===================================");
			transactionManager.rollback(status);;//실패하면 트랜잭션 롤백
			throw e;
		}
	}

	public int add(UserVO inVO) throws SQLException {
		
		return userService.add(inVO);
	}

	public Boolean canUpgradeLevel(UserVO user) throws IllegalAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	public void upgradeLevel(UserVO inVO) throws SQLException {
		// TODO Auto-generated method stub

	}

}
