package com.pcwk.ehr;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
/**
 * 다이나믹 프록시로 트랜잭션 처리
 * @author HKEDU
 *
 */
public class TransactionHandler implements InvocationHandler {
    final Logger LOG = LogManager.getLogger(getClass());
    /**어떤 종류에 인터페이스도 적용 가능한 target */
    private Object target;
    
    /**트랜잭션을 적용할 메소드 패턴 */
    private String pattern;
    
    PlatformTransactionManager transactionManager;
    
    public TransactionHandler() {}
    
	public void setTarget(Object target) {
		this.target = target;
	}


	public void setPattern(String pattern) {
		this.pattern = pattern;
	}


	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		//트랜잭션 메소드 선별
		if(method.getName().startsWith(pattern)) {
			return invokeTransaction(method,args);
		}else {
			return method.invoke(target, args);
		}
		
	}
	
	
	public Object invokeTransaction(Method method, Object[] args) throws Throwable {
		//트랜잭션 시작
		TransactionStatus  status = transactionManager.getTransaction(new DefaultTransactionDefinition());
		Object ret = null;
		try {
			//------------------------------------
			ret = method.invoke(target, args);
			//------------------------------------
			
			transactionManager.commit(status); ;//정상적으로 작업을 마치면 트랜잭션 commit
		
		}catch(Exception e) {
			LOG.debug("===================================");
			LOG.debug("=rollback*****=");
			LOG.debug("===================================");
			transactionManager.rollback(status);;//실패하면 트랜잭션 롤백
			throw e;
		}
		
		return ret;
	}	
	
	
	
	
	
	
}
