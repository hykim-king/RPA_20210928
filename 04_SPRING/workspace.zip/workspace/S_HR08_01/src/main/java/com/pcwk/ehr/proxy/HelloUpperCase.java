package com.pcwk.ehr.proxy;

public class HelloUpperCase implements Hello {

	Hello hello;
	
	public HelloUpperCase() {}
	
	public HelloUpperCase(Hello hello) {
		this.hello = hello;
	}
	
	@Override
	public String sayHello(String name) {
		//부가 기능
		return hello.sayHello(name).toUpperCase();
	}

	@Override
	public String sayHi(String name) {
		//부가 기능
		return hello.sayHi(name).toUpperCase();
	}

	@Override
	public String sayThankYou(String name) {
		//부가 기능
		return hello.sayThankYou(name).toUpperCase();
	}

}
