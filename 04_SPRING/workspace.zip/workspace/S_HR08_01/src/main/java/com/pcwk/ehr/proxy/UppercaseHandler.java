package com.pcwk.ehr.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UppercaseHandler implements InvocationHandler {
	final Logger LOG = LogManager.getLogger(getClass());
	Object target; //어떤 종류에 인터페이스도 적용 가능하도록 수정
	
	//다이내믹 프록시로 부터 전달 받은 요청을 다시
	//타깃 오브젝트에 위임하기 위해 주입 받는다.
	public UppercaseHandler(Object target) {
		this.target = target;
	}
	
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		//LOG.debug("method:"+method.getName());
		Object ret = method.invoke(target, args);
		if(ret instanceof  String && method.getName().startsWith("sayH") ) {
			return ((String)ret).toUpperCase();
		}else {
			return ret;
		}

	}

}
