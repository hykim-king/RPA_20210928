package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import oracle.security.crypto.fips.SelfTestException;



public class UserDao {
	final static Logger LOG = LogManager.getLogger(UserDao.class);
	
	private JdbcTemplate jdbcTemplate;
	
	//interface
	private DataSource dataSource;
	
	RowMapper<UserVO>  rowMapper = new RowMapper<UserVO>() {

		public UserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserVO  user =new UserVO();
			user.setuId(rs.getString("u_id"));
			user.setName(rs.getString("name"));
			user.setPasswd(rs.getString("passwd")); 
			
			return user;
		}
		
	};
	
	public UserDao() {}
	
	//DataSource를 구현한  SimpleDriverDataSource를 주입
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	

    
	@SuppressWarnings("deprecation")
	public List<UserVO>  getAll(){
		List<UserVO>  list = new ArrayList<UserVO>();
		
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT u_id    \n");
		sb.append("       ,name    \n");
		sb.append("       ,passwd  \n");
		sb.append(" FROM hr_member \n");
		sb.append(" ORDER BY u_id  \n");
		
		LOG.debug("sql=\n"+sb.toString());
		Object[] args = {};
		list = jdbcTemplate.query(sb.toString(), args, rowMapper);
		
		for(UserVO vo  :list) {
			LOG.debug("vo:"+vo);
		}
		
		
		
		return list;
	}

	/**
	 * 등록건수 
	 * @return
	 * @throws SQLException
	 */
	public int getCount() throws SQLException{
		int count = 0;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납	
		
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT COUNT(*) cnt    \n");
		sb.append(" FROM hr_member         \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("==============================");			
		
		count = this.jdbcTemplate.queryForObject(sb.toString(), Integer.class);
		LOG.debug("==============================");
		LOG.debug("=count="+count);
		LOG.debug("==============================");			
		
		return count;
	}

	
    /**
     * 전체 삭제 
     * @throws SQLException
     */
    public void deleteAll() throws SQLException{
    	StringBuilder sb=new StringBuilder(100);
		sb.append(" DELETE FROM hr_member \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("==============================");	
		
		jdbcTemplate.update(sb.toString());
    }

	/**
	 * 사용자 등록 
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(final UserVO inVO) throws SQLException{
		int flag = 0;
		
		Object[] args = {inVO.getuId(),inVO.getName(),inVO.getPasswd()};
		
		StringBuilder sb=new StringBuilder(100);
		sb.append(" INSERT INTO hr_member VALUES (?,?,?) \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());	
		LOG.debug("=args="+args);
		LOG.debug("==============================");	
		
		flag = jdbcTemplate.update(sb.toString(), args);
	    LOG.debug("flag:"+flag);
		return flag;
	}
	
	/**
	 * 사용자 조회
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	@SuppressWarnings("deprecation")
	public UserVO get(UserVO inVO) throws SQLException{
		UserVO outVO = null;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납		
		
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT u_id,    \n");
		sb.append("        name,    \n");
		sb.append("        passwd   \n");
		sb.append(" FROM hr_member  \n");
		sb.append(" WHERE u_id = ?  \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");
		Object[] args = {inVO.getuId()};
		outVO = this.jdbcTemplate.queryForObject(sb.toString(), args, rowMapper);
		
		LOG.debug("==============================");
		LOG.debug("=outVO="+outVO.toString());
		LOG.debug("==============================");	
		return outVO;
	}
}
























