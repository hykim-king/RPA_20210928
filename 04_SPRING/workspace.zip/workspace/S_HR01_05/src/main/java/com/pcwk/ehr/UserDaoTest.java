package com.pcwk.ehr;

import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDaoTest {
	static final Logger LOG = Logger.getLogger(UserDaoTest.class);
	
	UserDao dao;
	UserVO  user01;
	
	public UserDaoTest() {
		dao = new UserDao();
		user01=new UserVO("PCWK01","이상무01","1234");
	}
	
	public void add() throws ClassNotFoundException,SQLException{
		int flag = dao.add(user01);
		if(1==flag) {
			LOG.debug("==============================");
			LOG.debug("=성공=");
			LOG.debug("==============================");				
		}		
	}
	
	public void get() throws ClassNotFoundException,SQLException{
		UserVO outVO = dao.get(user01);
		if(null!=outVO) {
			LOG.debug("==============================");
			LOG.debug("=성공=");
			LOG.debug("==============================");				
		}		
	}
	
	public static void main(String[] args) {
		UserDaoTest main=new UserDaoTest();
			
			try {
				//추가
				main.add();
				
				main.get();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		


	}
	

}
