package com.pcwk.ehr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AppleSpeaker implements Speaker {
	final Logger LOG = LogManager.getLogger(getClass());
	
	public AppleSpeaker() {
		LOG.debug("AppleSpeaker() 생성자");
	}

	public void volumeUp() {
		LOG.debug("AppleSpeaker 소리를 올린다.");

	}

	public void volumeDown() {
		LOG.debug("AppleSpeaker 소리를 내린다.");

	}

}
