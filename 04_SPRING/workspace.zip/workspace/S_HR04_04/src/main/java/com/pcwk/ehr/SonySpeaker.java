package com.pcwk.ehr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SonySpeaker implements Speaker {

	final Logger LOG = LogManager.getLogger(getClass());
	
	public SonySpeaker() {
		LOG.debug("SonySpeaker() 생성자 호출");
	}

	public void volumeUp() {
		LOG.debug("SonySpeaker 소리를 올린다.");
	}
	
	public void volumeDown() {
		LOG.debug("SonySpeaker 소리를 내린다.");
	}

}
