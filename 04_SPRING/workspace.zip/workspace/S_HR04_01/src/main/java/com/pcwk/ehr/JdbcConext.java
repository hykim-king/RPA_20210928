package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

public class JdbcConext {
	
	private DataSource dataSource;
	
	public JdbcConext() {}
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public int workWithStatementStrategy(StatementStrategy stmt)throws SQLException {
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납
		int flag = 0;
    	Connection connection = null;
    	PreparedStatement pstmt = null;
    	try {
    		
    		connection = dataSource.getConnection();
    		
    		//StatementStrategy strategy=new DeleteAllStatement();
    		pstmt = stmt.makeStatement(connection);
    		
    		flag = pstmt.executeUpdate();
    		
    	}catch(SQLException e) {
    		
    	}finally {
    		//4.자원반납
    		//PreparedStatment 자원 반납
    		if(null != pstmt) {
    			try {
    				pstmt.close();
    			}catch(SQLException e) {
    				
    			}
    		}
    		
    		//Connection 자원반납
    		if(null != connection) {
    			try {
    				connection.close();
    			}catch(SQLException e) {
    				
    			}
    		}
    		
    	}		
    	
    	return flag;
	}
}
