package com.pcwk.ehr.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pcwk.ehr.cmn.Controller;
import com.pcwk.ehr.cmn.HandlerMapping;
import com.pcwk.ehr.cmn.ViewResolver;

/**
 * Servlet implementation class DispatcherServlet
 */
@WebServlet(description = "클라이언트의 요청을 가정 먼저 처리 Front Controller", urlPatterns = { "*.do" })
public class DispatcherServlet extends HttpServlet {
       
	
	private HandlerMapping  handlerMapping;
	private ViewResolver    viewResolver;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DispatcherServlet() {
        super();
        handlerMapping = new HandlerMapping();
        viewResolver   = new ViewResolver();
        
        viewResolver.setPrefix("/");
        viewResolver.setSuffix(".jsp");
    }

    private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	//1. 클라이언트의 요청 path정보를 추출
    	//https://mvnrepository.com/artifact/org.aspectj/aspectjtools.do
    	String uri = request.getRequestURI();
    	System.out.println("uri:"+uri);
    	String path= uri.substring(uri.lastIndexOf("/"));
    	System.out.println("path:"+path);
    	
    	//2. HandlerMapping통해 Path에 해당되는 Controller return
    	Controller ctrl = handlerMapping.getController(path);
    	
        //3.ViewResolver를 통해 viewname에 해당하는 화면을 검색
    	String viewName = ctrl.handlerRequest(request, response);
		System.out.println("-------------------");
		System.out.println("---viewName---"+viewName);
		System.out.println("-------------------");
		    	
    	String view = "";
    	if(!viewName.contains(".do")) {
    		view = viewResolver.getView(viewName);
    	}else {
    		view = viewName;
    	}

    	System.out.println("---view---"+view);   
    	String cPath = request.getContextPath();
    	response.sendRedirect(cPath+view);
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request,response);
		
	}

}
