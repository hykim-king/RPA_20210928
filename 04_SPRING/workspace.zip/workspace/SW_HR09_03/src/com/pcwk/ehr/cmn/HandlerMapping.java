package com.pcwk.ehr.cmn;

import java.util.HashMap;
import java.util.Map;

import com.pcwk.ehr.member.controller.MemberController;

public class HandlerMapping {

	private Map<String,Controller> mappings;
	
	public HandlerMapping() {
		mappings = new HashMap<String, Controller>();
		
		mappings.put("/doUpdate.do", new MemberController());
	}
	
	/**
	 * url에 해당되는 Controller return
	 * @param path
	 * @return
	 */
	public Controller getController(String path) {
		return mappings.get(path);
	}
	
}
