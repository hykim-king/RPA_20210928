package com.pcwk.ehr.cmn;

public class ViewResolver {
	public String prefix;//  /
	public String suffix;//  .jsp
	
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	
	//member/member_list
	//  /member/member_list.jsp
	public String getView(String viewName) {
		return prefix+viewName+suffix;
	}
}
