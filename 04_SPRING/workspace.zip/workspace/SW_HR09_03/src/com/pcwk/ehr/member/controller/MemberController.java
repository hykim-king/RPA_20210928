package com.pcwk.ehr.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pcwk.ehr.cmn.Controller;

public class MemberController implements Controller {

	@Override
	public String handlerRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("-------------------");
		System.out.println("---MemberController---");
		System.out.println("-------------------");
		
		
		return "member/member_list";
	}

}
