SELECT A.*,B.*
FROM(
    SELECT tt1.rnum,
           tt1.u_id,
           tt1.name,
           tt1.passwd,
           tt1.u_level,
           tt1.recommend,
           tt1.email,
           DECODE(TO_CHAR(SYSDATE,'YYYYMMDD'),TO_CHAR(tt1.reg_dt,'YYYYMMDD')
                 ,TO_CHAR(tt1.reg_dt,'HH24:MI')
                 ,TO_CHAR(tt1.reg_dt,'YYYY/MM/DD HH24:MI:SS')) reg_dt
    FROM (
        SELECT ROWNUM rnum,t1.*
        FROM (
            SELECT *
            FROM hr_member
            --where조건
            ORDER BY reg_dt desc
        )t1
    )tt1
    --WHERE rnum BETWEEN  1  AND 10
    WHERE rnum BETWEEN  (:PAGE_SIZE * (:PAGE_NUM-1)+1)  AND :PAGE_SIZE * (:PAGE_NUM-1)+:PAGE_SIZE
)A
CROSS JOIN
(
    SELECT COUNT(*) TOTALCNT
    FROM hr_member
    --where조건
)B
;

-- 데이터 집어넣기
DELETE FROM hr_member;

INSERT INTO hr_member
SELECT 'piku' || LPAD(ROWNUM, 7, 0) u_id,
       '김삐꾸' || LPAD(ROWNUM, 7, 0) name,
       '12345' passwd,
       MOD(ROWNUM, 3)+1 u_level,
       DECODE(MOD(ROWNUM, 3)+1, 1, 49, 51) login,
       DECODE(MOD(ROWNUM, 3)+1, 3, 31, 29) recommend,
       'piku' || LPAD(ROWNUM, 7, 0) || '@mail.com' email,
       SYSDATE - ROWNUM/24 reg_dt
FROM dual
CONNECT BY LEVEL <= 10000
;

commit;