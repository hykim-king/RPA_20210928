package com.pcwk.ehr.member.controller;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.bridge.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.pcwk.ehr.cmn.MessageVO;
import com.pcwk.ehr.cmn.SearchVO;
import com.pcwk.ehr.cmn.StringUtil;
import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserService;

@RestController("restUserController")
@RequestMapping("rest_user")
public class RestUserController {

	final Logger LOG = LogManager.getFormatterLogger(getClass());
	final String VIEW_NAME = "user/user_mng";
	
	@Autowired
	UserService userService;
	
	
	public RestUserController() {}
	

	
	
	
	@RequestMapping(value = "/user_view.do",method = RequestMethod.GET)
	public String userView(Model model)throws SQLException{
		
		return VIEW_NAME;
	}
	
	
	@RequestMapping(value="/doRetrieve",method = RequestMethod.POST)
	//@RequestBody JSON으로 전달된 데이터를 SearchVO로 메핑
	public ResponseEntity<List<UserVO>>   doRetrieve(@RequestBody SearchVO inVO)throws SQLException{
		

		//pageSize==10
		if(0==inVO.getPageSize()) {
			inVO.setPageSize(10);
		}
		
		//pageNum==1
		if(0==inVO.getPageNum()) {
			inVO.setPageNum(1);
		}
		
		//검색구분
		if(null == inVO.getSearchDiv()) {
			inVO.setSearchDiv(StringUtil.nvl(inVO.getSearchDiv()));
		}
		  
		//검색어
		if(null == inVO.getSearchWord()) {
			inVO.setSearchWord(StringUtil.nvl(inVO.getSearchWord()));
		}
		
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");	
		
		List<UserVO> list = this.userService.doRetrieve(inVO);	
		return new ResponseEntity<List<UserVO>>(list, HttpStatus.OK);
	}
	
	
	@RequestMapping(value ="/{uId}",method=RequestMethod.PUT)
	//@RequestBody :화면에서 전송된 JSON Object로 변환
	public MessageVO doUpdate(@RequestBody UserVO inVO)throws SQLException{
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");		
		String resultMsg = "";
		
		int flag = userService.doUpdate(inVO);
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 수정 되었습니다.";
		}else {
			resultMsg = "수정 실패";
		}			   
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		return message;		
	}
	     
	
	
	//http://localhost:8080/ehr/user/doDelete.do
	@RequestMapping(value ="/{uId}", method= RequestMethod.DELETE)
	public MessageVO doDelete(@PathVariable("uId") String uId)throws SQLException{
		UserVO inVO=new UserVO();
		inVO.setuId(uId);
		LOG.debug("=========================");
		LOG.debug("=uId="+uId);
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");
		
		String resultMsg = "";
		
		int flag = userService.doDelete(inVO);
		
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 삭제 되었습니다.";
		}else {
			resultMsg = "삭제 실패";
		}
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		return message;
	}

	//@PathVariable 부라우저에서 요청 URL로 전달된 매개변수를 가져올수 있다.
	//piku0000001
	//http://localhost:8080/ehr/rest_user/piku0000001
	@RequestMapping(value="/{uId}",method = RequestMethod.GET)	
	public UserVO doSelectOne(@PathVariable("uId") String uId) throws SQLException{
		UserVO inVO=new UserVO();
		LOG.debug("=uId="+uId);   
		
		inVO.setuId(uId);
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");	
		
		UserVO outVO = userService.doSelectOne(inVO);
		LOG.debug("=========================");
		LOG.debug("=outVO="+outVO);
		LOG.debug("=========================");
		
		return outVO;   
	}       
	   
	
	@RequestMapping(value="/add.do" ,method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody //스프링에서 비동기 처리를 하는 경우,HTTP 요청의 분문 body 부분이 그대로 전달된다.
	public String add(UserVO inVO) throws SQLException {
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");		
		String resultMsg = "";
		
		int flag = userService.add(inVO);
		
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 등록 되었습니다.";
		}else {
			resultMsg = "등록 실패";
		}		
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		Gson gson=new Gson();
		
		String jsonString = gson.toJson(message);
		LOG.debug("=jsonString=\n"+jsonString);
		
		return jsonString;		
		
	}
	

	
	
}



































