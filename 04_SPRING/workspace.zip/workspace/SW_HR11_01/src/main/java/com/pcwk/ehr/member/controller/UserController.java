package com.pcwk.ehr.member.controller;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.bridge.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.pcwk.ehr.cmn.MessageVO;
import com.pcwk.ehr.cmn.SearchVO;
import com.pcwk.ehr.cmn.StringUtil;
import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserService;

@Controller("userController")
@RequestMapping("user")
public class UserController {

	final Logger LOG = LogManager.getFormatterLogger(getClass());
	final String VIEW_NAME = "user/user_mng";
	
	@Autowired
	UserService userService;
	
	
	public UserController() {}
	
	//Rest VIEW
	//http://localhost:8080/ehr/user/json_view
	@RequestMapping(value = "/json_view",method = RequestMethod.GET)
	public String jsonView(Model model)throws SQLException{
		
		return "json/json_view";
	}
	
	@RequestMapping(value = "/user_view.do",method = RequestMethod.GET)
	public String userView(Model model)throws SQLException{
		
		return VIEW_NAME;
	}
	@RequestMapping(value="/doRetrieve.do"
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String  doRetrieve(SearchVO inVO)throws SQLException{
		
		String jsonString = "";

		//pageSize==10
		if(0==inVO.getPageSize()) {
			inVO.setPageSize(10);
		}
		
		//pageNum==1
		if(0==inVO.getPageNum()) {
			inVO.setPageNum(1);
		}
		
		//검색구분
		if(null == inVO.getSearchDiv()) {
			inVO.setSearchDiv(StringUtil.nvl(inVO.getSearchDiv()));
		}
		
		//검색어
		if(null == inVO.getSearchWord()) {
			inVO.setSearchWord(StringUtil.nvl(inVO.getSearchWord()));
		}
		
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");	
		
		List<UserVO> list = this.userService.doRetrieve(inVO);
		Gson gson=new Gson();
		jsonString = gson.toJson(list);
		LOG.debug("=========================");
		LOG.debug("=jsonString=\n"+jsonString);
		LOG.debug("=========================");			
		return jsonString;
	}
	
	
	@RequestMapping(value ="/doUpdate.do",method=RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody	//스프링에서 비동기 처리를 하는 경우,HTTP 요청의 분문 body 부분이 그대로 전달된다.
	public String doUpdate(UserVO inVO)throws SQLException{
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");		
		String resultMsg = "";
		
		int flag = userService.doUpdate(inVO);
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 수정 되었습니다.";
		}else {
			resultMsg = "수정 실패";
		}			
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		String jsonString = new Gson().toJson(message);
		LOG.debug("=jsonString=\n"+jsonString);
		return jsonString;		
	}
	
	
	
	//http://localhost:8080/ehr/user/doDelete.do
	@RequestMapping(value ="/doDelete.do", method= RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
    @ResponseBody	//스프링에서 비동기 처리를 하는 경우,HTTP 요청의 분문 body 부분이 그대로 전달된다.
	public String doDelete(UserVO inVO)throws SQLException{
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");
		
		String resultMsg = "";
		
		int flag = userService.doDelete(inVO);
		
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 삭제 되었습니다.";
		}else {
			resultMsg = "삭제 실패";
		}
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		Gson gson=new Gson();
		
		String jsonString = gson.toJson(message);
		LOG.debug("=jsonString=\n"+jsonString);
		
		return jsonString;
	}

	@RequestMapping(value="/doSelectOne.do" ,method = RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
	@ResponseBody //스프링에서 비동기 처리를 하는 경우,HTTP 요청의 분문 body 부분이 그대로 전달된다.	
	public String doSelectOne(UserVO inVO) throws SQLException{
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");	
		
		UserVO outVO = userService.doSelectOne(inVO);
		LOG.debug("=========================");
		LOG.debug("=outVO="+outVO);
		LOG.debug("=========================");
		
		Gson gson=new Gson();
		String jsonString = gson.toJson(outVO);
		LOG.debug("=========================");
		LOG.debug("=jsonString="+jsonString);
		LOG.debug("=========================");		
		return jsonString;
	} 
	
	
	@RequestMapping(value="/add.do" ,method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody //스프링에서 비동기 처리를 하는 경우,HTTP 요청의 분문 body 부분이 그대로 전달된다.
	public String add(UserVO inVO) throws SQLException {
		LOG.debug("=========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=========================");		
		String resultMsg = "";
		
		int flag = userService.add(inVO);
		
		if(1==flag) {
			resultMsg = inVO.getuId()+"가 등록 되었습니다.";
		}else {
			resultMsg = "등록 실패";
		}		
		
		MessageVO message=new MessageVO(flag+"", resultMsg);
		
		Gson gson=new Gson();
		
		String jsonString = gson.toJson(message);
		LOG.debug("=jsonString=\n"+jsonString);
		
		return jsonString;		
		
	}
	

	
	
}



































