package com.pcwk.ehr;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.SQLException;
import java.util.List;

import javax.mail.Message;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pcwk.ehr.cmn.MessageVO;
import com.pcwk.ehr.cmn.SearchVO;
import com.pcwk.ehr.member.dao.UserDao;
import com.pcwk.ehr.member.domain.Level;
import com.pcwk.ehr.member.domain.UserVO;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                                   "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
public class JUserControllerTest {
	final Logger LOG = LogManager.getLogger(getClass());
	
	@Autowired
	WebApplicationContext webApplicationContext;
	
	//브라우저 대역 Mock
	MockMvc  mockMvc;

	UserVO  user01;
    UserVO  user02;
    UserVO  user03;
    
    SearchVO searchVO;
    
    @Autowired
    UserDao   userDao;
    
	@Before
	public void setUp() throws Exception {
		LOG.debug("===============");
		LOG.debug("setUp()");
		LOG.debug("webApplicationContext:"+webApplicationContext);
		LOG.debug("mockMvc:"+mockMvc);
		LOG.debug("===============");
		
		searchVO = new SearchVO("", "", 10, 1);
		
		user01 = new UserVO("PCWK01","이상무01","1234",Level.BASIC,1,0,"jamesol01@paran.com");
		user02 = new UserVO("PCWK02","이상무02","1234",Level.SILVER,51,2,"jamesol02@paran.com");
		user03 = new UserVO("PCWK03","이상무03","1234",Level.GOLD,100,31,"jamesol03@paran.com");
        //생성
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		
		assertNotNull(webApplicationContext);
		assertNotNull(mockMvc);
	}

	@Test
	public void  doRetrieve()throws Exception{
		searchVO.setSearchDiv("20");
		searchVO.setSearchWord("김삐꾸000001");
		//호출 URL, param,호출방식
		MockHttpServletRequestBuilder requestBuilder= 
				    MockMvcRequestBuilders.get("/user/doRetrieve.do")
				.param("searchDiv", searchVO.getSearchDiv())
				.param("searchWord", searchVO.getSearchWord())
				.param("pageSize", String.valueOf(searchVO.getPageSize()))
				.param("pageNum", String.valueOf(searchVO.getPageNum()))
				;	
		
		ResultActions resultActions =this.mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				;	
		String result = resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString()
				;
		
		LOG.debug("===============");
		LOG.debug("result:\n"+result);		
		LOG.debug("===============");
		
		//JSON String to List<UserVO>
		Gson gson=new Gson();
		List<UserVO> list = 
				gson.fromJson(result, new TypeToken<List<UserVO>>(){}.getType());
		
		assertEquals(list.size(), 10);
		
				
	}
	
	
	@Test
	@Ignore
	public void doUpdate()throws Exception{
		  //1. 전체삭제
		  //2. 신규등록: user01
		  //3. user01수정
		  //4. user01데이터 update
		  //5. 1건조회후 서로 비교 user01
		
		//1.
		userDao.deleteAll();
		
		//2.
		add(user02);
		assertEquals(1, userDao.getCount());
		
		//3.
		String upStr = "_U";
		user02.setName(user02.getName()+upStr);
		user02.setPasswd(user02.getPasswd()+upStr);
		user02.setLevel(Level.GOLD);
		user02.setLogin(user02.getLogin()*10);
		user02.setRecommend(user02.getRecommend()+10);
		user02.setEmail(user02.getEmail()+upStr);
		
		MockHttpServletRequestBuilder requestBuilder= MockMvcRequestBuilders.post("/user/doUpdate.do")
				.param("uId", user02.getuId())
				.param("name", user02.getName())
				.param("passwd", user02.getPasswd())
				.param("level", user02.getLevel()+"")
				.param("login", user02.getLogin()+"")
				.param("recommend", user02.getRecommend()+"")
				.param("email", user02.getEmail())				
				;
		ResultActions resultActions =this.mockMvc.perform(requestBuilder)
				.andExpect(status().is2xxSuccessful())
				;				
		String result = resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString()
				;		
		LOG.debug("===============");
		LOG.debug("result:\n"+result);		
		LOG.debug("===============");			
				
		Gson  gson=new Gson();
		MessageVO resultMsg = gson.fromJson(result, MessageVO.class);
		assertEquals("1", resultMsg.getMsgId());
		
		//5.
		UserVO vsVO = userDao.doSelectOne(user02);
		isSameUser(vsVO, user02);
		
		
	}
	
	
	
	//삭제,등록,단건조회
	@Test
	@Ignore
	public void addAndGet() throws Exception {
		LOG.debug("====================");
		LOG.debug("=addAndGet()=");
		LOG.debug("====================");			
		//1. 삭제
		doDelete(user01);
		doDelete(user02);
		doDelete(user03);
		
		userDao.deleteAll();
		
		//2. 1건 입력
		add(user01);
		assertEquals(1, userDao.getCount());
		add(user02);
		assertEquals(2, userDao.getCount());
		add(user03);
		assertEquals(3, userDao.getCount());
		
		//4.
	    UserVO outVO01 = doSelectOne(user01);
	    isSameUser(outVO01, user01);		
		
	    UserVO outVO02= doSelectOne(user02);
	    isSameUser(outVO02,user02);	    
	    
	    UserVO outVO03= doSelectOne(user03);
	    isSameUser(outVO03,user03);	    
	}
	
	private void isSameUser(UserVO outVO, UserVO userVO) {
	    assertEquals(outVO.getuId(), userVO.getuId());
	    assertEquals(outVO.getName(),userVO.getName());
	    assertEquals(outVO.getPasswd(),userVO.getPasswd());		
	    
	    //로그인, 추천,이메일,레벨
	    assertEquals(outVO.getLogin(),userVO.getLogin());
	    assertEquals(outVO.getRecommend(),userVO.getRecommend());
	    assertEquals(outVO.getEmail(),userVO.getEmail());
	    assertEquals(outVO.getLevel(),userVO.getLevel());
	}	
	///doSelectOne.do
	//@Test
	
	public UserVO doSelectOne(UserVO user02) throws Exception{
		//호출 URL, param,호출방식
		MockHttpServletRequestBuilder requestBuilder= MockMvcRequestBuilders.get("/user/doSelectOne.do")
				.param("uId", user02.getuId());
		
		ResultActions resultActions =this.mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				;		
		
		String result = resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString()
				;		
		
		LOG.debug("===============");
		LOG.debug("result:\n"+result);		
		LOG.debug("===============");
		
		Gson gson=new Gson();
		UserVO outVO = gson.fromJson(result, UserVO.class);
		
		return outVO;
	}
	
	
	//@Test
	//@Ignore
	public void add(UserVO user02) throws Exception {
		//호출 URL, param,호출방식
		MockHttpServletRequestBuilder requestBuilder= MockMvcRequestBuilders.post("/user/add.do")
				.param("uId", user02.getuId())
				.param("name", user02.getName())
				.param("passwd", user02.getPasswd())
				.param("level", user02.getLevel()+"")
				.param("login", user02.getLogin()+"")
				.param("recommend", user02.getRecommend()+"")
				.param("email", user02.getEmail())				
				;	
		
		ResultActions resultActions =this.mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				;		
		
		String result = resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString()
				;		
		LOG.debug("===============");
		LOG.debug("result:\n"+result);		
		LOG.debug("===============");		
	}
	
	
	//@Test
	//@Ignore
	public void doDelete(UserVO user02)throws Exception{
		//호출 URL, param,호출방식
		MockHttpServletRequestBuilder requestBuilder= MockMvcRequestBuilders.get("/user/doDelete.do")
				.param("uId", user02.getuId());
		
		ResultActions resultActions =this.mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				;
		String result = resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString()
				;
		LOG.debug("===============");
		LOG.debug("result:\n"+result);		
		LOG.debug("===============");		
		
		//JSON String result
		Gson  gson=new Gson();
		MessageVO resultMsg = gson.fromJson(result, MessageVO.class);
		
		assertEquals("1", resultMsg.getMsgId());
		
		
	}
	


}







