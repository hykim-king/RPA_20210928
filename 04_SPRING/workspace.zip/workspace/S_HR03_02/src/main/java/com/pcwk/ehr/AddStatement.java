package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AddStatement implements StatementStrategy {
	final  Logger LOG = LogManager.getLogger(getClass());
	
	private UserVO inVO;
	
	public AddStatement(UserVO inVO) {
		this.inVO = inVO;
	}
	
	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" INSERT INTO hr_member VALUES (?,?,?) \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");		
		
		//3.
		PreparedStatement pstmt = connection.prepareCall(sb.toString());
		pstmt.setString(1, inVO.getuId());
		pstmt.setString(2, inVO.getName());
		pstmt.setString(3, inVO.getPasswd());
		
		return pstmt;
	}

}
