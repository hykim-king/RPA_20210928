package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;



public class UserDao {
	final static Logger LOG = LogManager.getLogger(UserDao.class);
	
	//interface
	private DataSource dataSource;
	
	public UserDao() {}
	
	//DataSource를 구현한  SimpleDriverDataSource를 주입
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * 등록건수 
	 * @return
	 * @throws SQLException
	 */
	public int getCount() throws SQLException{
		int count = 0;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납	
		
		//1.
		Connection connection = dataSource.getConnection();
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT COUNT(*) cnt    \n");
		sb.append(" FROM hr_member         \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("==============================");		
		
		//3.
		PreparedStatement pstmt = connection.prepareStatement(sb.toString());
		//4.
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			count = rs.getInt(1);
		}
		LOG.debug("==============================");
		LOG.debug("=count="+count);
		LOG.debug("==============================");		
		
		//5.
		rs.close();
		pstmt.close();
		connection.close();
		
		return count;
	}
	

	
	public int jdbcContextWithStatementStrategy(StatementStrategy stmt)throws SQLException {
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납
		int flag = 0;
    	Connection connection = null;
    	PreparedStatement pstmt = null;
    	try {
    		
    		connection = dataSource.getConnection();
    		
    		//StatementStrategy strategy=new DeleteAllStatement();
    		pstmt = stmt.makeStatement(connection);
    		
    		flag = pstmt.executeUpdate();
    		
    	}catch(SQLException e) {
    		
    	}finally {
    		//4.자원반납
    		//PreparedStatment 자원 반납
    		if(null != pstmt) {
    			try {
    				pstmt.close();
    			}catch(SQLException e) {
    				
    			}
    		}
    		
    		//Connection 자원반납
    		if(null != connection) {
    			try {
    				connection.close();
    			}catch(SQLException e) {
    				
    			}
    		}
    		
    	}		
    	
    	return flag;
	}
	
	
    /**
     * 전체 삭제 
     * @throws SQLException
     */
    public void deleteAll() throws SQLException{
    	//StatementStrategy strategy=new DeleteAllStatement();
    	jdbcContextWithStatementStrategy(new DeleteAllStatement());
    }

	/**
	 * 사용자 등록 
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(UserVO inVO) throws SQLException{
		int flag = 0;
		flag = jdbcContextWithStatementStrategy(new AddStatement(inVO));		
		return flag;
	}
	
	/**
	 * 사용자 조회
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public UserVO get(UserVO inVO) throws SQLException{
		UserVO outVO = null;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납		
		
		//1.
		Connection connection = dataSource.getConnection();
		
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT u_id,    \n");
		sb.append("        name,    \n");
		sb.append("        passwd   \n");
		sb.append(" FROM hr_member  \n");
		sb.append(" WHERE u_id = ?  \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");	
		//3.
		PreparedStatement pstmt = connection.prepareCall(sb.toString());
		pstmt.setString(1, inVO.getuId());
		
		//4.
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			outVO = new UserVO();
			outVO.setuId(rs.getString("u_id"));
		    outVO.setName(rs.getString("name"));
			outVO.setPasswd(rs.getString("passwd")); 
		}
		
		
		
		//5.
		rs.close();
		pstmt.close();
		connection.close();
		
		
		if(null == outVO ) {
			throw new EmptyResultDataAccessException("조회 데이터가 없어요.", 0);
		}
		
		LOG.debug("==============================");
		LOG.debug("=outVO="+outVO.toString());
		LOG.debug("==============================");	
		
		return outVO;
	}
}
























