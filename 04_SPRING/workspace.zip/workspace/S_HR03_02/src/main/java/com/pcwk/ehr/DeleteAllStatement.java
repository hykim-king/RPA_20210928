package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DeleteAllStatement implements StatementStrategy {
	final  Logger LOG = LogManager.getLogger(getClass());
	
	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		PreparedStatement pstmt = null;
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" DELETE FROM hr_member \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("==============================");	
		
		pstmt = connection.prepareStatement(sb.toString());
		
		return pstmt;
	}

}
