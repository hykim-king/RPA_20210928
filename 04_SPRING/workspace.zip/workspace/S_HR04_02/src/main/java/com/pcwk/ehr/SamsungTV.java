package com.pcwk.ehr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SamsungTV implements Tv {
    final Logger LOG = LogManager.getLogger(getClass());
    
    public void destroyMethod() {
    	LOG.debug("SamsungTV destroyMethod() 호출.");
    }
    public void initMethod() {
    	LOG.debug("SamsungTV initMethod() 호출.");
    }
    
	public void powerOn() {
		LOG.debug("SamsungTV 전원을 켠다.");

	}

	public void powerOff() {
		LOG.debug("SamsungTV 전원을 끈다.");

	}

	public void volumeUp() {
		LOG.debug("SamsungTV 볼륨을 높인다.");

	}

	public void volumeDown() {
		LOG.debug("SamsungTV 볼륨을 내린다.");

	}

}
