package com.pcwk.ehr;

public interface Tv {
	
	public void powerOn();
	
	public void powerOff();
	
	public void volumeUp();
	
	public void volumeDown();
}
