package com.pcwk.ehr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LgTv implements Tv {
	final Logger LOG = LogManager.getLogger(getClass());
	
	public void powerOn() {
		LOG.debug("LgTV 전원을 켠다.");

	}

	public void powerOff() {
		LOG.debug("LgTV 전원을 끈다.");

	}

	public void volumeUp() {
		LOG.debug("LgTV 볼륨을 올린다.");

	}

	public void volumeDown() {
		LOG.debug("LgTV 볼륨을 내린다.");

	}

}
