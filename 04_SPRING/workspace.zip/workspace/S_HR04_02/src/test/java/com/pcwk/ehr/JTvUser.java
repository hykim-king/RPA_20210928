package com.pcwk.ehr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//메소드 수행 순선:asc
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class JTvUser {
	final Logger  LOG = LogManager.getLogger(getClass());
	
	@Autowired
	ApplicationContext  context;
	
	Tv  tv;
	Tv  tv02;
	
	@Before
	public void setUp() throws Exception {
		LOG.debug("================");
		LOG.debug("=context="+context);
		LOG.debug("================");
		
		tv = (Tv) context.getBean("tv");
		tv02= (Tv) context.getBean("tv");
		LOG.debug("=tv="+tv);
		LOG.debug("=tv02="+tv02);
		
		assertEquals(tv, tv02);
		assertNotNull(tv);
		assertNotNull(context);
	}

	@After
	public void tearDown() throws Exception {
		LOG.debug("================");
		LOG.debug("=tearDown=");
		LOG.debug("================");			
	}

	@Test
	public void tvText() {
		LOG.debug("================");
		LOG.debug("=tvText=");
		LOG.debug("================");		
		
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		
		
		
	}

}

