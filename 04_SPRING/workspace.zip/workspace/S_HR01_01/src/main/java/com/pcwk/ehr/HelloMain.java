package com.pcwk.ehr;

public class HelloMain {

	public static void main(String[] args) {
		System.out.println("Hello world!");

	}

}
