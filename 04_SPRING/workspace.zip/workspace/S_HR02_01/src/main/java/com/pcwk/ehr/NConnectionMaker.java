package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NConnectionMaker implements ConnectionMaker {
    final Logger  LOG = LogManager.getLogger(this.getClass());
    
	final String DB_DRIVER ="oracle.jdbc.driver.OracleDriver";
	final String DB_URL    ="jdbc:oracle:thin:@localhost:1521:xe";
	final String USER_ID   ="SPRING";
	final String USER_PASS ="SPRING9";    
	
	public Connection makeConnection() throws ClassNotFoundException, SQLException {
		Connection connection = null;
		Class.forName(DB_DRIVER);
		
		connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("==============================");
		LOG.debug("=connection="+connection);
		LOG.debug("==============================");
		
		return connection;
	}

}
