package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

public class UserServiceImpl implements UserService {
    final Logger LOG = LogManager.getLogger(getClass());
    
    /** basic에서 silver로 가기위한 최소 로그인수 */
    public static final int MIN_LOGCOUNT_FOR_SILVER = 50;
    /** silver에서 gold로 가기위한 최소 추천수 */
    public static final int MIN_RECOMMEND_FOR_GOLD  = 30;
    
    UserDao   userDao;
    DataSource  dataSource;
    PlatformTransactionManager transactionManager;
    
    MailSender  mailSender;
    
    
	public UserServiceImpl() {
		
	}
	  
	
	
	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}



	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}



	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}



	public void upgradeLevels() throws Exception {
		//모든 사용자 정보를 가지고 온다.
		//BASIC 이고 로그인 50이상이면 -> SILVER
		//SILVER 추천 30번 이상이면    -> GOLD
		//GOLD 는 대상 아님
		//트랜잭션 동기화 관리자를 이용해 동기화를 초기화
		//PlatformTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
		
		//트랜잭션 시작
		TransactionStatus  status = transactionManager.getTransaction(new DefaultTransactionDefinition());
		
		try {
			List<UserVO>  list = userDao.getAll();
			for(UserVO user   :list) {
				boolean  changeLevel = false;
				
				try {
					if(canUpgradeLevel(user)) {
						upgradeLevel(user);
					}
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}//--for
			
			transactionManager.commit(status); ;//정상적으로 작업을 마치면 트랜잭션 commit
		}catch(Exception e) {
			LOG.debug("===================================");
			LOG.debug("=rollback*****=");
			LOG.debug("===================================");
			transactionManager.rollback(status);;//실패하면 트랜잭션 롤백
			throw e;
		}

	}//--upgradeLevels() 

	public int add(UserVO inVO) throws SQLException {
        //level이 null이면 Level.BASIC
		if(null == inVO.getLevel()) {
			inVO.setLevel(Level.BASIC);
		}
		
		return userDao.doInsert(inVO);
	}

	public Boolean canUpgradeLevel(UserVO user) throws IllegalAccessException {
		
		Level currentLevel = user.getLevel();
		
		switch(currentLevel) {
			case BASIC:
				return (user.getLogin() >= MIN_LOGCOUNT_FOR_SILVER);
			case SILVER:
				return (user.getRecommend() >= MIN_RECOMMEND_FOR_GOLD);
			case GOLD:
				return false;
			default:
			    throw new IllegalAccessException("Unknown Level:"+currentLevel);
		}
		
	}

	public void upgradeLevel(UserVO user) throws SQLException {
		user.upgradeLevel();		
		userDao.doUpdate(user);
		sendUpgradeMail(user);
		
	}
	
	/**
	 * 등업 사용자에게 mail전송.
	 * @param user
	 */
	private void sendUpgradeMail(UserVO user) {
//		PasswordAuthentication													
//		Authenticator													
//		Session: Authenticator+PasswordAuthentication													
//		JavaMailSenderImpl		
		SimpleMailMessage  simpleMessage=new SimpleMailMessage();
		simpleMessage.setTo(user.getEmail());
		simpleMessage.setFrom("jamesol@naver.com");
		simpleMessage.setSubject("등업안내");
		simpleMessage.setText("사용자의 등급이 "+user.getLevel().name());
		
		
		mailSender.send(simpleMessage);

	}

}

















