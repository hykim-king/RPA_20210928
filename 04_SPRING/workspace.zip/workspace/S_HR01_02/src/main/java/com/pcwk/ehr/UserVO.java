package com.pcwk.ehr;

public class UserVO {
	/** 사용자 ID */
	private String uId      ;
	
	/** 이름 */
	private String name     ;
	
	/** 비밀번호 */
	private String passwd   ;                                            	

	/** default생성자 */
	public UserVO() {}

	/**
	 * 인자 uId,name,passwd 생성자
	 * @param uId
	 * @param name
	 * @param passwd
	 */
	public UserVO(String uId, String name, String passwd) {
		super();
		this.uId = uId;
		this.name = name;
		this.passwd = passwd;
	}

	public String getuId() {
		return uId;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	@Override
	public String toString() {
		return "UserVO [uId=" + uId + ", name=" + name + ", passwd=" + passwd + "]";
	}
	
	
	
}
