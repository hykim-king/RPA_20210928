package com.pcwk.ehr;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class ImgToByte {

	public static void main(String[] args) throws IOException {
		BufferedImage bi = ImageIO.read(new File("C:\\file_repo\\duke.png"));

		// convert BufferedImage to byte[]
		byte[] bytes = toByteArray(bi, "png");
		System.out.print(java.util.Arrays.toString(bytes));
		System.out.println("----------");
		// Base64 인코딩 ///////////////////////////////////////////////////
		/* base64 encoding */
		Encoder encoder = Base64.getEncoder();
		byte[] encodedBytes = encoder.encode(bytes);

		System.out.print(new String(encodedBytes));
	}

	public static byte[] toByteArray(BufferedImage bi, String format) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bi, format, baos);
		byte[] bytes = baos.toByteArray();
		return bytes;

	}
}
