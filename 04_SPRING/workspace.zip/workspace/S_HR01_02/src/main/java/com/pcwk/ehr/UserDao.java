package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserDao {
	static final Logger LOG = LogManager.getLogger(UserDao.class);
	
	final String DB_DRIVER ="oracle.jdbc.driver.OracleDriver";
	final String DB_URL    ="jdbc:oracle:thin:@localhost:1521:xe";
	final String USER_ID   ="SPRING";
	final String USER_PASS ="SPRING9";
	/**
	 * 사용자 등록 
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(UserVO inVO) throws ClassNotFoundException,SQLException{
		int flag = 0;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납
		
		//1.
		Connection connection = null;
		Class.forName(DB_DRIVER);
		
		connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("==============================");
		LOG.debug("=connection="+connection);
		LOG.debug("==============================");
		
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" INSERT INTO hr_member VALUES (?,?,?) \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");		
		
		//3.
		PreparedStatement pstmt = connection.prepareCall(sb.toString());
		pstmt.setString(1, inVO.getuId());
		pstmt.setString(2, inVO.getName());
		pstmt.setString(3, inVO.getPasswd());
		
		flag = pstmt.executeUpdate();
		LOG.debug("=flag="+flag);
		
		//4.자원반납
		pstmt.close();
		connection.close();
		return flag;
	}
	
	/**
	 * 사용자 조회
	 * @param inVO
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public UserVO get(UserVO inVO) throws ClassNotFoundException,SQLException{
		UserVO outVO = null;
		//1.DB연결
		//2.SQL Statement,PreparedStatment
		//3.PreparedStatment수행
		//4.조회 ResultSet으로 정보를 받아와 처리
		//5.자원반납		
		
		//1.
		Connection connection = null;
		Class.forName(DB_DRIVER);
		
		connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("==============================");
		LOG.debug("=connection="+connection);
		LOG.debug("==============================");
		
		//2.
		StringBuilder sb=new StringBuilder(100);
		sb.append(" SELECT u_id,    \n");
		sb.append("        name,    \n");
		sb.append("        passwd   \n");
		sb.append(" FROM hr_member  \n");
		sb.append(" WHERE u_id = ?  \n");
		LOG.debug("==============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param="+inVO.toString());
		LOG.debug("==============================");	
		//3.
		PreparedStatement pstmt = connection.prepareCall(sb.toString());
		pstmt.setString(1, inVO.getuId());
		
		//4.
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			outVO = new UserVO();
			outVO.setuId(rs.getString("u_id"));
		    outVO.setName(rs.getString("name"));
			outVO.setPasswd(rs.getString("passwd")); 
		}
		LOG.debug("==============================");
		LOG.debug("=outVO="+outVO.toString());
		LOG.debug("==============================");			
		
		//5.
		rs.close();
		pstmt.close();
		connection.close();
		return outVO;
	}
}
























