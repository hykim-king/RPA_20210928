package com.pcwk.ehr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Log4JMain {
    static final Logger LOG = LogManager.getLogger(Log4JMain.class);
	public static void main(String[] args) {
		LOG.debug("Hello, world.");
	}

}
