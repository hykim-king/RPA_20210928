package com.pcwk.ehr.aspectj;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations ="/com/pcwk/ehr/aspectj/aspectj-applicationContext.xml" )
public class JAspectJBefore {
   final Logger LOG = LogManager.getLogger(getClass());
   
   @Autowired
   ApplicationContext  context;
   
   @Autowired
   Member  mebmer;
   
   
   @Test
   public void beforeAspect() {
	   mebmer.doSave();
	   
	   mebmer.doUpdate();
	   
	   mebmer.delete();
   }
   
	
   @Test
   public void beans() {
		LOG.debug("=================");
		LOG.debug("=beans()=");
		LOG.debug("=context="+context);
		LOG.debug("=mebmer="+mebmer);
		LOG.debug("=================");
		
		assertNotNull(context);
		assertNotNull(mebmer);
   }

}
