package com.pcwk.arraylist.ex01;

import java.util.ArrayList;

//import java.util.ArrayList;
public class Student {

	int studentID;//학번
	String studentName;//이름
	ArrayList<Subject>  subjectList;//수강과목 리스트
	
	public Student() {
		
	}
	
	public Student(int studentID,String studentName) {
		this.studentID = studentID;
		this.studentName = studentName;
		
		subjectList = new ArrayList<Subject>();
		
	}
	
	//과목추가
	public void addSubject(String name, int score) {
		Subject  subject=new Subject();
		subject.setName(name);//과목이름
		subject.setScorePoint(score);//점수
		
		subjectList.add(subject);//수강과목 리스트에 추가
		
	}
	
	//과목에 내용과 총점 추가
	public void showStudentInfo() {
		int total = 0;
		
		for(Subject subject:subjectList) {
			total += subject.getScorePoint();
//			
//			Lee학생 국어 100점 
//                 수학 50점 
			System.out.println("학생: "+this.studentName+"의 "+subject.getName()+" 과목 성적은 "+subject.getScorePoint()+"입니다.");
		}
		System.out.println("학생: "+this.studentName+"의 총점은 "+total+" 입니다.");
		
	}
	
	
	
	
	

}
