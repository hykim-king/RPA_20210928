package com.pcwk.arraylist.ex01;

public class StudentMain {

	public StudentMain() {
		
	}

	public static void main(String[] args) {
		Student student01=new Student(1001,"Lee");
		student01.addSubject("국어", 100);
		student01.addSubject("수학", 50);

		student01.showStudentInfo();
		System.out.println("=========================");
		
		Student  student02=new Student(1002,"Kim");
		student02.addSubject("국어", 70);
		student02.addSubject("수학", 85);
		student02.addSubject("영어", 100);
		
		student02.showStudentInfo();
	}

}
//학생: Lee의 국어 과목 성적은 100입니다.
//학생: Lee의 수학 과목 성적은 50입니다.
//학생: Lee의 총점은 150 입니다.
//=========================
//학생: Kim의 국어 과목 성적은 70입니다.
//학생: Kim의 수학 과목 성적은 85입니다.
//학생: Kim의 영어 과목 성적은 100입니다.
//학생: Kim의 총점은 255 입니다.
