package com.pcwk.arraylist.ex02.q5;

public class Dog {

	private String name;
	private String type;
	
	
	public Dog() {
		
	}

	public Dog(String name, String type) {
		this.name = name;
		this.type = type;
	}
	/**
	 * 
	 * @return : 이름,종류
	 */
	public String showDogInfo() {
		return "이름:"+name+", 종류:"+type;
	}
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}

	


}
