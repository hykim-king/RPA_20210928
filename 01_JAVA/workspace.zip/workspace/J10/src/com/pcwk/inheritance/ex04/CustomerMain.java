package com.pcwk.inheritance.ex04;

public class CustomerMain {

	public static void main(String[] args) {
//		Customer customer=new Customer();
//		customer.setCustomerID(10010);
//		customer.setCustomerName("이순신");
//		customer.bonusPoint = 1000;
//		
//		System.out.println(customer.showCustomerInfo());
		System.out.println("=========================");
		VIPCustomer vipCustomer=new VIPCustomer();
		vipCustomer.setCustomerID(10020);
		vipCustomer.setCustomerName("김유신");
		//vipCustomer.setBonusPoint(10000);
		vipCustomer.bonusPoint = 10000;
		System.out.println(vipCustomer.showCustomerInfo());
		
	}

}
//Customer() 생성자 호출 : 아버지의 생성자 호출
//VIPCustomer() 생성자 호출: 자식의 생성자 호출
//김유신님의 등급은 VIP이며, 보너스 포인트는 10000입니다.