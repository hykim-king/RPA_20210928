package com.pcwk.inheritance.ex07;

public class Eagle extends Animal {

	@Override
	public void move() {
		System.out.println("독수리가 하늘을 납니다.");
	}
}
