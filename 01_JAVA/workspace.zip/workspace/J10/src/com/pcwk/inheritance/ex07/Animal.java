package com.pcwk.inheritance.ex07;

public class Animal {

	public void move() {
		System.out.println("동물이 움직 입니다.");
	}
}
