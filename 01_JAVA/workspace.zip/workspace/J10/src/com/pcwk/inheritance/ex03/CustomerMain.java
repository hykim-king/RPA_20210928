package com.pcwk.inheritance.ex03;

public class CustomerMain {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.setCustomerID(10010);
		customer.setCustomerName("이순신");
		customer.bonusPoint = 1000;
		
		System.out.println(customer.showCustomerInfo());
		System.out.println("=========================");
		VIPCustomer vipCustomer=new VIPCustomer();
		vipCustomer.setCustomerID(10020);
		vipCustomer.setCustomerName("김유신");
		//vipCustomer.setBonusPoint(10000);
		vipCustomer.bonusPoint = 10000;
		System.out.println(vipCustomer.showCustomerInfo());
		
		
	}

}
