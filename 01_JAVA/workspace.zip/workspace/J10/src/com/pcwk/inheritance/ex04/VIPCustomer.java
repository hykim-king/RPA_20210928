package com.pcwk.inheritance.ex04;

public class VIPCustomer extends Customer {
//	private int customerID;//고객아이디
//	private String customerName;//고객이름
//	private String customerGrade;//고객등급
//	int bonusPoint;//보너스 포인트
//	double bonusRatio;//적립비율
	
	private int agentID;//VIP 고객 담당 상담원
	double saleRatio;//할인율
	
	public VIPCustomer() {
		super();//컴파일러가 자동으로 추가하는 코드: 상위클래스에 Customer() 생성자 호출
		customerGrade = "VIP";//고객등급 VIP
		bonusRatio    = 0.05; //적립비율
		saleRatio     = 0.1;  //할인율 10%
		System.out.println("VIPCustomer() 생성자 호출");

	}
	
	public int calcPrice(int price) {
		bonusPoint += price*bonusRatio;// 보너스 포인트 적립
		
		return price - (int)(price*saleRatio);
	}

	public int getAgentID() {
		return agentID;
	}
	

	
}
