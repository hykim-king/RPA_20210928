package com.pcwk.inheritance.ex06;

import java.util.Date;

public class CustomerMain {

	public static void main(String[] args) {
		Customer customer=new Customer(10010,"김수희");
		customer.bonusPoint = 1000;
		int price = 1_000_000;//소니 헤드폰
		System.out.println(customer.getCustomerName()+" 님이 구매한 소니 헤드폰은 "
				+customer.calcPrice(price)+"원 입니다.");
//		
//		System.out.println(customer.showCustomerInfo());
		System.out.println("=========================");
		VIPCustomer vipCustomer=new VIPCustomer(10020,"고은지",100);
		//vipCustomer.setCustomerID(10020);
		//vipCustomer.setCustomerName("김유신");
		//vipCustomer.setBonusPoint(10000);
		vipCustomer.bonusPoint = 10000;
		System.out.println(vipCustomer.showVIPInfo());
		
		price = 2_000_000;//iphone 13Pro
		System.out.println(vipCustomer.getCustomerName()+" 님이 구매한 IPHONE 13은Pro는 "
		 +vipCustomer.calcPrice(price)+"원 입니다.");
		
		
		//가상메서드
		//상속에서 상위 클래스와 하위 클래스에 같은 이름의 메서드가 존재 할때
		//호출되는 메서드는 인스턴스에 따라 결정된다.
		Customer   vc =new VIPCustomer(10020,"이상무",100);
		price = 10_000_000;
		System.out.println("==========================");
		System.out.println(vc.calcPrice(price));
		System.out.println("==========================");
		
		//@Deprecated																									
        //이후 버전에서는 사용되지 않을 수 있는 변수, 메서드
		Date  date=new Date();
		System.out.println(date.getDate());

	}

}
//Customer() 생성자 호출 : 아버지의 생성자 호출
//VIPCustomer() 생성자 호출: 자식의 생성자 호출
//김유신님의 등급은 VIP이며, 보너스 포인트는 10000입니다.