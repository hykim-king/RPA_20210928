package com.pcwk.inheritance.ex07;

public class Tiger extends Animal {

	public Tiger() {
	
	}

	@Override
	public void move() {
		System.out.println("호랑이가 네 발로 뜁니다.");
	}
	
}
