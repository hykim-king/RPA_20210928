package com.pcwk.inheritance.ex07;

public class AminalMain {

	public static void main(String[] args) {
		AminalMain amiMain=new AminalMain();
		amiMain.moveAnimal(new Human());
		amiMain.moveAnimal(new Eagle());
		amiMain.moveAnimal(new Tiger());
	}

	public void moveAnimal(Animal ani) {
		ani.move();
	}
//  메서드를 여러게 정의할 필요 없음.	
//	public void moveAnimal(Eagle eagle) {
//
//	}
//
//	public void moveAnimal(Human human) {
//
//	}

}
