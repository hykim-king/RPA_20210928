/**
 * package: com.pcwk.oop
 * file name: Person.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop;

/**
 * @author HKEDU
 *
 */
public class Person {
	String name;      //이름
	int height;       //키
	int weight;	      //몸무게
	char gender;      //성별
	boolean isMarried;//결혼여부
	
	

}
