/**
 * package: com.pcwk.oop.ex04.constructor
 * file name: Person.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex05.constructor;

/**
 * @author HKEDU
 *
 */
public class Person {

	String name; //이름
	float  weight;//몸무게
	float  height;//키
	
	//default생성자
	public Person() {
		
	}
	
	//이름을 param으로 받는 생성자
	//멤버 변수 초기화
	public Person(String pname) {
		name = pname;
	}
	
}
