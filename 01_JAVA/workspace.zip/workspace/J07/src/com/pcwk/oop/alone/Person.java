/**
 * package: com.pcwk.oop.alone
 * file name: Person.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.alone;

/**
 * @author HKEDU
 *
 */
public class Person {
	int age;    //나이
	String name;//이름
	boolean isMarried; //결혼여부
	int numberOfChildren;//자녀 수
	
}
