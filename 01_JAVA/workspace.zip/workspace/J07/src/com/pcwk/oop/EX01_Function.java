/**
 * package: com.pcwk.oop
 * file name: EX01_Function.java
 * description: 함수
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop;

/**
 * @author HKEDU
 *
 */
public class EX01_Function {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 12;
		
		int sum = add(num1,num2);
		System.out.println(num1+"+"+num2+"="+sum);

	}

	/**
	 * 더하기 함수
	 * @param n1
	 * @param n2
	 * @return n1+n2
	 */
	public static int add(int n1,int n2) {
		int result = n1+n2;
		
		return result;
	}
	
	
}
