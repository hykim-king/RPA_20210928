/**
 * package: com.pcwk.oop.ex06.constructor
 * file name: PersonMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex06.constructor;

/**
 * @author HKEDU
 *
 */
public class PersonMain {

	/**
	 * 
	 */
	public PersonMain() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person=new Person("이상무", 70.0f, 180.2f);

		System.out.println("이름:"+person.name);
		System.out.println("몸무게:"+person.weight);
		System.out.println("키:"+person.height);
		
		System.out.println("=======================");
		Person person01=new Person("마민성");
		System.out.println("이름:"+person01.name);
		System.out.println("몸무게:"+person01.weight);
		System.out.println("키:"+person01.height);

	}

}
