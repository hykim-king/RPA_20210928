/**
 * package: com.pcwk.oop.ex05.constructor
 * file name: PersonMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex05.constructor;

/**
 * @author HKEDU
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//단 다른 생성자가 하나도 없는 경우만.										
        //컴파일러가 default생성자를 만든다.
		Person person=new Person();//Error
		
	}

}
