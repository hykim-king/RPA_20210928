/**
 * package: com.pcwk.oop.ex07.reference
 * file name: Student.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex07.reference;

/**
 * @author HKEDU
 *
 */
public class Student {
	//멤버 변수
	int studentId;
	String studentName;
	//int    mathScore;
	//String mathSubject;
	//subject형
	Subject  koreanSubject;
	Subject  mathSubject;
	
	//생성자
	/**
	 * 
	 */
	public Student() {
		// TODO Auto-generated constructor stub
	}

	
	//메서드
	
	
	
}
