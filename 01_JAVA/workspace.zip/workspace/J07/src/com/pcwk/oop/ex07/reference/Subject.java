/**
 * package: com.pcwk.oop.ex07.reference
 * file name: Subject.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex07.reference;

/**
 * @author HKEDU
 *
 */
public class Subject {

	
	String subjectName;
	int    score;
}
