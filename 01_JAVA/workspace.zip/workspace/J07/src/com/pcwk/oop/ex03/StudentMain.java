/**
 * package: com.pcwk.oop.ex03
 * file name: StudentMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex03;

/**
 * @author HKEDU
 *
 */
public class StudentMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student  student01=new Student();
		student01.studentName = "이상무";
		
		System.out.println("이름:"+student01.studentName);
		
		Student  student02=new Student();
		student02.studentName = "홍길동";
		System.out.println("이름:"+student02.studentName);
		
		//student01:com.pcwk.oop.ex03.Student@123a439b
		//@+hashCode
		System.out.println("student01:"+student01.toString());//참조변수의 주소
		System.out.println("student02:"+student02);//참조변수의 주소

		
	}

}
