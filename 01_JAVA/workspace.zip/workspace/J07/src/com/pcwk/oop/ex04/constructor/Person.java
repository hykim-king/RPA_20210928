/**
 * package: com.pcwk.oop.ex04.constructor
 * file name: Person.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex04.constructor;

/**
 * @author HKEDU
 *
 */
public class Person {

	String name; //이름
	float  weight;//몸무게
	float  height;//키
	
	//java 컴파일러가 자동으로 제공하는 디폴트 생성자
	public Person() {
		
	}
	
}
