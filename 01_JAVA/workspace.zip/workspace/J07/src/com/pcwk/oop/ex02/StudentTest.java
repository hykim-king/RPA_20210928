/**
 * package: com.pcwk.oop.ex02
 * file name: StudentTest.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex02;
import com.pcwk.oop.ex01.Student;
/**
 * @author HKEDU
 *
 */
public class StudentTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student student=new Student();
		student.setStudentName("이상무");
		
		System.out.println("학생 이름:"+student.getStudentName());

	}

}
