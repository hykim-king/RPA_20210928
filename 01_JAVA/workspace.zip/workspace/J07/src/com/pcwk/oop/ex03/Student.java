/**
 * package: com.pcwk.oop.ex01
 * file name: Student.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex03;

/**
 * @author HKEDU
 *
 */
public class Student {
	int studentId;
	String studentName;
	int grade;
	String address;
	
	//메서드: 클래스 내부에서 사용하는 멤버 함수
	//멤버 변수를 사용해서 프로그래밍 한다.
	
	/**
	 * getXXX() : getter
	 * 학생이름 return
	 * @return String
	 */
	public String getStudentName() {
		return studentName;
	}
	
	/**
	 * setXXX() : setter
	 * 학생의 이름을 설정
	 * @param name
	 */
	public void setStudentName(String name) {
		studentName = name;
	}
	


}
