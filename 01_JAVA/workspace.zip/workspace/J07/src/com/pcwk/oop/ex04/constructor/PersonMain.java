/**
 * package: com.pcwk.oop.ex04.constructor
 * file name: PersonMain.java
 * description: 생성자
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.ex04.constructor;

/**
 * @author HKEDU
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person=new Person();
		

	}

}
