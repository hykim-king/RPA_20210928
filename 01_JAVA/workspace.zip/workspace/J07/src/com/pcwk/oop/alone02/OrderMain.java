/**
 * package: com.pcwk.oop.alone02
 * file name: OrderMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.alone02;

/**
 * @author HKEDU
 *
 */
public class OrderMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Order order=new Order();
		order.orderNo = 201803120001L; 
		order.userId  = "abc123";
		order.name  = "홍길순";
		order.orderDate = "2021년 10월 7일";
		order.productNo = "PD0345-12";
		order.address   = "서울 영등포구 양산로 53 209, 401, 402호";
		
		System.out.println("주문번호:"+order.orderNo);
		System.out.println("주문자 아이디:"+order.userId);
		System.out.println("주문자 일자:"+order.orderDate);
		System.out.println("주문자 이름:"+order.name);
		System.out.println("주문자 번호:"+order.productNo);
		System.out.println("주문자 주소:"+order.address);
		
	}

}
