/**
 * package: com.pcwk.oop
 * file name: Student.java
 * description: 클래스
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop;

/**
 * @author HKEDU
 *
 */
public class Student {

	int studentId;		//학번
	String studentName;	//학생이름
	int grade;			//학년
	String address;		//사는 곳

	//메서드 
	/**
	 * 학생의 이름과 주소 출력.
	 */
	public void showStudentInfo() {
		System.out.println(studentName+","+address);
	}
}
