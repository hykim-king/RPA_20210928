/**
 * package: com.pcwk.oop.alone02
 * file name: Order.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.alone02;

/**
 * @author HKEDU
 *
 */
public class Order {
	long orderNo;    //주문번호(21억 이상 이므로 int대신 long)   
	
	String userId;   //주문자 아이디
	String orderDate;//주문일자
	String name;     //주문자 이름
	String productNo;//주문상품번호
	String address;  //배송주소
	
	
}
