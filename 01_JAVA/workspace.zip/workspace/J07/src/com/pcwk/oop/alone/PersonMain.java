/**
 * package: com.pcwk.oop.alone
 * file name: PersonMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-08
 * version: 0.3
 *
 */
package com.pcwk.oop.alone;

/**
 * @author HKEDU
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person=new Person();
		person.age = 40;
		person.name="james";
		person.isMarried = true;
		person.numberOfChildren = 3;
		
		String comment = "이 사람의";
		
		System.out.println(comment+" 나이 "+person.age);
		System.out.println(comment+" 이름 "+person.name);
		System.out.println(comment+" 결혼 "+(person.isMarried?"기혼":"미혼" )   );
		System.out.println(comment+" 자녀수 "+person.numberOfChildren);
		
	}

}
