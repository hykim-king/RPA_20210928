package com.pcwk.ex04.api.naversearch;

public class Item {
	
	private String title        ;//제목
	private String link         ;//링크
	private String image        ;//이미지
	private String author       ;//저자
	private int    price        ;//가격
	private int    discount     ;//할인가격
	private String publisher    ;//출판사
	private String pubdate      ;//출판일
	private String isbn         ;//ISBN
	private String description  ;//상세설명
	
	public Item() {}

	public String getTitle() {
		return title;
	}

	public String getLink() {
		return link;
	}

	public String getImage() {
		return image;
	}

	public String getAuthor() {
		return author;
	}

	public int getPrice() {
		return price;
	}

	public int getDiscount() {
		return discount;
	}

	public String getPublisher() {
		return publisher;
	}

	public String getPubdate() {
		return pubdate;
	}

	public String getIsbn() {
		return isbn;
	}

	public String getDescription() {
		return description;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public void setPubdate(String pubdate) {
		this.pubdate = pubdate;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Item [title=" + title + ", link=" + link + ", image=" + image + ", author=" + author + ", price="
				+ price + ", discount=" + discount + ", publisher=" + publisher + ", pubdate=" + pubdate + ", isbn="
				+ isbn + ", description=" + description + "]";
	}
	
	
}
