package com.pcwk.ex04.api.naversearch;

public class Difine {

	
	public static final String NAVER_BLOG ="https://openapi.naver.com/v1/search/encyc.json?query=";
	public static final String NAVER_BOOK ="https://openapi.naver.com/v1/search/blog?query=";
	public static final String NAVER_DICTIONARY ="https://openapi.naver.com/v1/search/blog?query=";
	
	
}
