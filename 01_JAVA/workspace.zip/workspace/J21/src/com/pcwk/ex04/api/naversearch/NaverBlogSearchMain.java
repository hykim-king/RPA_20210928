package com.pcwk.ex04.api.naversearch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

import com.google.gson.Gson;
import com.pcwk.cmn.Common;

public class NaverBlogSearchMain implements Common {

	public static void main(String[] args) {
		String clientId = "PF2hZcj7_cmVHc8unUOn";//클라이언트 아이디
		String clientSecret = "Z2F9wQ0NVO";//클라이언트 시크릿
		String text;//검색어
		BufferedReader br=null;
		
		Items  items = null;//json string -> Java
		StringBuilder sb=new StringBuilder();
		
		//파일에 기록
		FileWriter  fw=null;
		BufferedWriter  bw=null;
		String apiURL = "";
		try {
			//콘솔 입력
			Scanner scanner=new Scanner(System.in);
			System.out.print("검색구분> ⓐ사전 ⓑ책 ⓒ블로그");
			
			String searchDiv = "";
			searchDiv = scanner.next();
			
			System.out.print("검색어를 입력 하세요>");
			String searchWord = scanner.next();
			text = URLEncoder.encode(searchWord, "UTF-8");//%ED%95%9C%EA%B0%95
			
			//백과사전
			if(searchDiv.equalsIgnoreCase("a")) {
				apiURL = Difine.NAVER_DICTIONARY;
			//책	
			}else if(searchDiv.equalsIgnoreCase("b")) {
				apiURL =Difine.NAVER_BOOK;
			//BLOG	
			}else if(searchDiv.equalsIgnoreCase("c")) {
				apiURL =Difine.NAVER_BLOG;
			}else {
				System.out.print("검색어를 확인 하세요.");
				return;
			}
			
			URL  url =new URL(apiURL+text);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("GET");//GET방식으로 접근
			con.setRequestProperty("X-Naver-Client-Id", clientId);
			con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
			
			int responseCode = con.getResponseCode();
			// HTTP/1.0 200 OK
			// HTTP/1.0 401 Unauthorized
			LOG.debug("responseCode:"+responseCode);
			
			if(200==responseCode) {//로그인 성공
				br=new BufferedReader (new InputStreamReader(con.getInputStream()));
			}else {
				LOG.debug("클라이언트 아이디,클라이언트 시크릿을 확인하세요");
				return;
			}
			
			String inputLine;
			
			fw = new FileWriter(searchWord+".json");
			bw = new BufferedWriter(fw);
			
			while( (inputLine = br.readLine())!=null ) {
				sb.append(inputLine);
				LOG.debug(inputLine);
			}
			bw.append(sb.toString());
			LOG.debug("파일생성 완료!");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			try {
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//JSON String to Java
		items = new Gson().fromJson(sb.toString().trim(), Items.class);
		LOG.debug("조회일:"+items.getLastBuildDate());
		LOG.debug("총글수:"+items.getTotal());
		LOG.debug("시작번호:"+items.getStart());
		LOG.debug("출력글수:"+items.getDisplay());
		
		for(Item book :items.getItems()) {
			LOG.debug(book);
		}
		
	}
	
	

}
