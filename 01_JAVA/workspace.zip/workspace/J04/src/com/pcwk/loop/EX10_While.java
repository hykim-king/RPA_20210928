/**
 * package: com.pcwk.loop
 * file name: EX10_While.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX10_While {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num =1;
		num += 2;
		num += 3;
		num += 4;
		num += 5;
		num += 6;
		num += 7;
		num += 8;
		num += 9;
		num += 10;

		System.out.println("1부터 10까지 합 "+num);
	}

}
