/**
 * package: com.pcwk.loop
 * file name: EX11_While.java
 * description: while 1 ~10 합계
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX11_While {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num ;//증가
		int sum ;//합계
		num = 1;
		sum = 0;
		
		while(num<=100) {
			sum=sum+num;//sum+=num
			++num;
			System.out.println(num);
		}
		
		System.out.println("1~10까 합계:"+sum);
		

	}

}
