/**
 * package: com.pcwk.loop
 * file name: EX14_NestedFor.java
 * description: Nested Loop
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX15_NestedForAlone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int i;
		int j;
		//3~7단 출력
		for(i=3;i<=7;i++) {
			for(j=1;j<=9;j++) {
				//2*1=2
				System.out.println(i+"*"+j+"="+(i*j));
			}
			System.out.println();
		}
	}
}
