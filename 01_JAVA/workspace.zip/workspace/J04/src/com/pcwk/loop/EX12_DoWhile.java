/**
 * package: com.pcwk.loop
 * file name: EX12_DoWhile.java
 * description: do~while
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX12_DoWhile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num = 1;
		int sum = 0;
		
		do {
			sum+=num;//sum=sum+num;
			num++;
		}while(num>10);

		System.out.println("1~10까지 합:"+sum);
	}

}
//1~10까지 합:1