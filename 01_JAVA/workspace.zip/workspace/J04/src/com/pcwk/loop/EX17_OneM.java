/**
 * package: com.pcwk.loop
 * file name: EX16_Continue.java
 * description:continue: 1~100까지 홀수만 더하기
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX17_OneM {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int sum = 0;
		int i;
		
		for(i=1;i<=100;i++) {
			
			if(i%3!=0) {//3에 배수가 아니면 참
				continue;//건너 뛰기.
			}
			System.out.println("i:"+i);
			sum+=i;
			
		}
		
		System.out.println("1~100까지 홀수합 sum:"+sum);
		
	}

}
