/**
 * package: com.pcwk.loop
 * file name: EX14_NestedFor.java
 * description: Nested Loop
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX14_NestedFor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int i;
		int j;
		
		for(i=2;i<=9;i++) {
			for(j=1;j<=9;j++) {
				//2*1=2
				System.out.println(i+"*"+j+"="+(i*j));
			}
			System.out.println();
		}
		
		
		

	}

}
