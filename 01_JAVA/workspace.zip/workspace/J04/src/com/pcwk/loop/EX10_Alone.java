/**
 * package: com.pcwk.loop
 * file name: EX10_Alone.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX10_Alone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//안녕하세요1
		//안녕하세요2
		//..
		//안녕하세요10
		for(int i=1;i<=10;i++) {
			System.out.println("안녕하세요"+i);
		}

	}

}
