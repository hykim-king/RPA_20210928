/**
 * package: com.pcwk.loop
 * file name: EX13_For.java
 * description: for
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX13_For {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int sum;
		int i;
		int j;
		for(i=1,sum=0;i<=10;i++) {
			sum+=i;
			System.out.println(i);
		}
		
		System.out.println("1~10까지 합계:"+sum);

	}

}
