/**
 * package: com.pcwk.control
 * file name: EX05_SwitchCase.java
 * description:switch~case
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX05_SwitchCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int ranking = 9;
		char medalColor = ' ';
		
		switch(ranking) {
		case 1:
			medalColor = 'G';
			break;
		case 2:
			medalColor = 'S';
			break;
		case 3:
			medalColor = 'B';
			break;
		default:
			medalColor = ' ';
			break;
		
		}//--switch end

		System.out.println("Ranking: "+ranking);
		System.out.println("medalColor: "+medalColor);
		
		
		
		
	}//--main

}//--class
