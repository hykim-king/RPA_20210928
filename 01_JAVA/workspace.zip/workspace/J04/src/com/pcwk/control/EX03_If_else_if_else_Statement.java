/**
 * package: com.pcwk.control
 * file name: EX03_If_else_if_else_Statement.java
 * description: if~ else if else
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX03_If_else_if_else_Statement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int age   =60 ;  //나이
		int charge=0;   //입장료

		if(age<8) {
			charge = 1_000;//_는 천단위 구분 기호
			System.out.println("미 취학 학생 입니다.");
		//}else if(age>=8 && age<14) {	
		}else if(age < 14) {//8<=age<14			
			charge = 2_000;
			System.out.println("초등 학생 입니다.");
		}else if(age < 20) {
			charge = 2_500;
			System.out.println("중고등 학생 입니다.");
		}else if(age <60) {
			charge = 3000;
			System.out.println("일반인 입니다.");
		}else {
			charge = 0;
			System.out.println("경로 우대입니다.");
		}
		
		System.out.println("나이는 "+age +"살 입장료는 "+charge+" 입니다.");
		
	}

}
