/**
 * package: com.pcwk.control
 * file name: EX06_SwitchCase.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX06_SwitchCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// switch ~ case : 월별 일수 구하기!
		int month = 4;
		int days  = 0;
		switch(month) {
		case 1:case 3:case 5:case 7:case 8:case 10:case 12:
			days = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			days = 30;
			break;
		case 2:
			days = 28;
			break;
		
		}

		System.out.println("월:"+month);
		System.out.println("일수:"+days);
		
		
	}

}
