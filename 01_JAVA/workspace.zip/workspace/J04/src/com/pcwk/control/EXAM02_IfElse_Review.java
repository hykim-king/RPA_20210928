/**
 * package: com.pcwk.control
 * file name: EXAM02_IfElse_Review.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EXAM02_IfElse_Review {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		char gender = 'F';
		
		if(gender=='F') {//만약 gender가 'F'라면
			System.out.println("여성 입니다.");
		}else {//그렇치 않으면
			System.out.println("남성 입니다.");
		}

	}

}
