/**
 * package: com.pcwk.control
 * file name: EX09_Alone.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX09_Alone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 5층 건물이 있습니다.
		// 1층 약국
		// 2층 정형외과
		// 3층 피부과
		// 4층 치과
		// 5층 헬스클럽
		
		int floor = 5;        //층
		String shopName = ""; //가계
		
		switch(floor) {
		case 1:
			shopName = "약국";
			break;
		case 2:
			shopName = "정형외과";
			break;
		case 3:
			shopName = "피부과";
			break;
		case 4:
			shopName = "치과";
			break;	
		case 5:
			shopName = "헬스클럽";
			break;		
		}
		
		System.out.println(floor+" 층");
		System.out.println(shopName);
		
		
		
		
		
		
		
		
		
		
		

	}

}
