/**
 * package: com.pcwk.control
 * file name: EX01_IF_ELSE_Statement.java
 * description: 제어문 if~else
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX01_IF_ELSE_Statement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int age = 7;
		
		if(age>=8) {
			System.out.println("학교에 다닙니다.");
		}else {
			System.out.println("학교에 다니지 않습니다.");
		}
	}
}
