/**
 * package: com.pcwk.control
 * file name: EX08_SwitchCase.java
 * description: Switch ~ case문자열
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX08_SwitchCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String medal ="Gold";
		switch(medal) {
		case "Gold":
			System.out.println("금메달 입니다.");
			break;
		case "Silver":
			System.out.println("은메달 입니다.");
			break;
		case "Bronze":
			System.out.println("동메달 입니다.");
			break;
		default:
			System.out.println("NO메달 입니다.");			
			break;
		}

	}
}
