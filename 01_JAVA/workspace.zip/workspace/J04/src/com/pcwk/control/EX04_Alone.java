/**
 * package: com.pcwk.control
 * file name: EX04_Alone.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX04_Alone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int score  = 101;
		char grade = ' ';
		
		//유효성 체크
		if(score>=101) {
			System.out.println("점수를 확인 하세요.\n(0~100 입니다.)");
			return ;//
		}
		
		if(score >=90) {
			grade = 'A';
		}else if(score >=80) {
			grade = 'B';
		}else if(score >=70) {
			grade = 'C';
		}else if(score >=60) {
			grade = 'D';
		}else {
			grade = 'F';
		}
		
		System.out.println("점수는: "+score);
		System.out.println("학점: "+grade);
		
		
	}

}
