/**
 * package: com.pcwk.control
 * file name: EX06_SwitchCase.java
 * description:
 * user: HKEDU
 * create date: 2021-10-05
 * version: 0.3
 *
 */
package com.pcwk.control;

/**
 * @author HKEDU
 *
 */
public class EX07_SwitchCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// switch ~ case : 월별 일수 구하기!
		int year  = 2016;//2016,2020윤년
		int month = 12;
		int days  = 0;    
		
		//1 ~ 12이 아니면 월이 유효하지 않다.
		//1<=month<=12
		//1<=month && month<=12
		if( !( 1<=month && month<=12)){// (1>month || month>12)
			System.out.println("월을 확인 하세요.\n(1~12월)");
			return;
		}
		
		switch(month) {
		case 4:case 6:case 9:case 11:
			days = 30;
			break;
		case 2://윤달
			// 4에 배수인 해는 윤년으로 하고 그리고 100의 배수인 해는 윤년에서 뺀다.
			// 그러나 400의 배수인 해는 도로 윤년이다.
			if( (year%400==0) || (year%4 ==0 && year%100 != 0) ) {//윤년
				days = 29;
			}else {
				days = 28;
			}
			
			break;
		default:
			days = 31;
			break;
		
		}

		System.out.println("월:"+month);
		System.out.println("일수:"+days);
		
		
	}

}
