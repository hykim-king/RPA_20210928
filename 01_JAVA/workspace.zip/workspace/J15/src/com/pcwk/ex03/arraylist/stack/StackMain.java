package com.pcwk.ex03.arraylist.stack;

public class StackMain {

	public static void main(String[] args) {
		MyStack myStack=new MyStack();

		myStack.push("A");
		myStack.push("B");
		myStack.push("C");
		
		System.out.println(myStack);
		System.out.println(myStack.pop());
		System.out.println(myStack.pop());
		System.out.println(myStack.pop());
		
		System.out.println(myStack);
	}

}
