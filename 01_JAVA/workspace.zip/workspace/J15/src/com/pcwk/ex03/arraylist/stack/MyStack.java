package com.pcwk.ex03.arraylist.stack;

import java.util.*;

public class MyStack {
	ArrayList<String>  arrayStack;
	
	
	public MyStack() {
		arrayStack = new ArrayList<>();
	}
	
	
	//추가:스택에 맨 뒤에 추가
	public void push(String data) {
		arrayStack.add(data);
	}
	
	//가져오기:
	public String pop() {
		//top이 비어 있는지 check
		int len = arrayStack.size();
		if(0==len) {
			System.out.println("스택이 비어 있습니다.");
			return null;
		}
		
		
		//len - 1 : top
		return arrayStack.remove(len-1);
	}
	
	@Override
	public String toString() {
		return arrayStack.toString();
	}
}
