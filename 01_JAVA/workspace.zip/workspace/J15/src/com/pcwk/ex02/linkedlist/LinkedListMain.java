package com.pcwk.ex02.linkedlist;
import java.util.LinkedList;

public class LinkedListMain {

	public static void main(String[] args) {
		LinkedList<String>  myList=new LinkedList<>();
		//요소추가
		myList.add("A");//0
		myList.add("B");//1
		myList.add("C");//2
		
		//리스트 출력:toString()을 LinkedList에서 오버라이딩 함
		System.out.println(myList.toString());
		
		myList.add(1, "D");
		System.out.println(myList);

		
		myList.addFirst("O");
		System.out.println(myList);
	}

}
