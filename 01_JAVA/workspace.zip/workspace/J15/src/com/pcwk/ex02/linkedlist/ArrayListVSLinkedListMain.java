package com.pcwk.ex02.linkedlist;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ArrayListVSLinkedListMain {

	public static void main(String[] args) {
		// 순차적인 추가에 : 경과 시간으로 ArrayList vs. LinkedList
		// 중간 추가에 : 경과 시간으로 ArrayList vs. LinkedList
		
		//1970/1/1 현재까지 경과된 시간을 MillSecond으로 표시
		System.out.println(System.currentTimeMillis());
		
		ArrayList arrayList=new ArrayList<>(1_000_000);		
		LinkedList  linkList=new LinkedList<>();
		
		System.out.println("==순차적인 추가==");
		System.out.println("ArrayList: "+addSequence(arrayList));
		System.out.println("LinkedList: "+addSequence(linkList));
		
		System.out.println("==중간에 추가==");
		System.out.println("ArrayList: "+addMiddle(arrayList));
		System.out.println("LinkedList: "+addMiddle(linkList));	
		
		System.out.println("==순차적인 삭제==");
		System.out.println("ArrayList: "+removeArrayList(arrayList));
		System.out.println("LinkedList: "+removeLinkedList(linkList));			
	}
	
	//순서대로 추가
	public static long addSequence(List<String> list) {
		long start = System.currentTimeMillis();
		
		for(int i=0;i<1_000_000;i++) {
			list.add(i+"");
		}
		
		long end   = System.currentTimeMillis();;
		//경과 시간
		return end - start;
	}
	
	//중간에 추가 
	public static long addMiddle(List<String> list) {
		long start = System.currentTimeMillis();
		
		for(int i=0;i<1_000_000;i++) {
			list.add(1000,i+"");
		}
		
		long end   = System.currentTimeMillis();;
		//경과 시간
		return end - start;
	}	

	
	
	//(꼭)arrayList는 뒤에서 부터 삭제 해야함.
	public static long removeArrayList(List<String> list) {
		long start = System.currentTimeMillis();
		
		for(int i=list.size()-1;i>=0;i--) {
			list.remove(i);
		}
		
		long end   = System.currentTimeMillis();
		//경과 시간
		return end - start;		
	}
	
	//linkedList삭제
	public static long removeLinkedList(List<String> list) {
		long start = System.currentTimeMillis();
		
		for(int i=0;i<list.size();i++) {
			list.remove(i);
		}
		
		long end   = System.currentTimeMillis();
		
		//경과 시간
		return end - start;			
	}
	
	
	
	
}
