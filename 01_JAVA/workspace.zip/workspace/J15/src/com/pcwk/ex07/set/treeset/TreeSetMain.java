package com.pcwk.ex07.set.treeset;

import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		
		TreeSet<String> treeSet=new TreeSet<>();
		treeSet.add("이");
		treeSet.add("박");
		treeSet.add("김");
		
		for(String name   :treeSet) {
			System.out.println(name);
		}
		
	}

}
//김
//박
//이