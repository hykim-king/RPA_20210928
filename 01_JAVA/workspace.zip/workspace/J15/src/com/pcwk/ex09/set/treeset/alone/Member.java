package com.pcwk.ex09.set.treeset.alone;

public class Member implements Comparable<Member> {
	private int memberId;     // 회원ID
	private String memberName;// 회원이름
	
	
	public Member(int memberId, String memberName) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
	}

	@Override
	public boolean equals(Object obj) {
		if( obj instanceof  Member) {
			Member member = (Member)obj;
			if(this.memberId ==member.getMemberId()) {
				return true;
			}else {
				return false;
			}
		}
		
		return false;
	}
	
	@Override
	public int hashCode() {
		return this.memberId;
	}
	

	public int getMemberId() {
		return memberId;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + "]";
	}

	@Override
	public int compareTo(Member o) {
		//두 값을 비교해서 
		//새로 추가한 회원 아이가 더 크면 음수
		//새로 추가한 회원 아이가 같으면 0
		//새로 추가한 회원 아이가 작으면 양수
		//return (this.memberId - o.getMemberId())*(-1);
		System.out.println(this.memberName.compareTo(o.getMemberName()));
		return this.memberName.compareTo(o.getMemberName());
	}


	
	
	
	
	

}
