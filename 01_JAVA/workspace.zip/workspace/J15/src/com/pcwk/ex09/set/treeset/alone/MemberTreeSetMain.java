package com.pcwk.ex09.set.treeset.alone;



public class MemberTreeSetMain {

	public static void main(String[] args) {
		MemberTreeSet memberTreeSet=new MemberTreeSet();
		
		Member  member01=new Member(1,"오일남");
		Member  member02=new Member(67,"강새벽");
		Member  member03=new Member(101,"장덕수");
		
		
		memberTreeSet.addMember(member02);
		memberTreeSet.addMember(member03);
		memberTreeSet.addMember(member01);
		
		memberTreeSet.showAllMember();
	}

}
