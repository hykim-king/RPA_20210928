package com.pcwk.ex05.arraylist.iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorMain {

	public static void main(String[] args) {
		ArrayList<String>  arrayList=new ArrayList<>();
		arrayList.add("오일남");
		arrayList.add("강새벽");
		arrayList.add("장덕수");
		arrayList.add("알리 압둘");
		
		Iterator<String> iter =arrayList.iterator();
		
		while(iter.hasNext()==true) {
			String squidMember = iter.next();
			System.out.println(squidMember);
		}

	}

}
