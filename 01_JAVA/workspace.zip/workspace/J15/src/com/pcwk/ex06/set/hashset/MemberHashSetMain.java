package com.pcwk.ex06.set.hashset;

public class MemberHashSetMain {

	public static void main(String[] args) {
		MemberHashSet memberHashSet=new MemberHashSet();
		

		Member  member01=new Member(1,"오일남");
		Member  member02=new Member(67,"강새벽");
		Member  member03=new Member(101,"장덕수");
		
		memberHashSet.addMember(member01);
		memberHashSet.addMember(member02);
		memberHashSet.addMember(member03);
		//순서 보장되지 않음
		memberHashSet.showAllMember();
		Member  member04=new Member(67,"한미녀");
		
		//객체의 동일성 구현이 필요.
		memberHashSet.addMember(member04);
		memberHashSet.showAllMember();
	}

}
//Member [memberId=101, memberName=장덕수]
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//
//Member [memberId=101, memberName=장덕수]
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=67, memberName=한미녀]

//member equals(),hashCode()

//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=101, memberName=장덕수]
//
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=101, memberName=장덕수]
