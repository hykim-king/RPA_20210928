package com.pcwk.ex06.set.hashset;

import java.util.HashSet;
import java.util.Iterator;

public class MemberHashSet {

	private HashSet<Member>  hashSet;
	
	public MemberHashSet() {
		//HashSet<Member> 생성
		hashSet = new HashSet<>();
	}
	
	/**
	 * 멤버추가
	 * @param member
	 */
	public void addMember(Member member) {
		hashSet.add(member);
	}
	
	/**
	 * 멤버삭제
	 * @param memberId
	 * @return 삭제되면 true/ 그렇치 않으면 false
	 */
	public boolean removeMember(int memberId) {
		boolean flag = false;
		//iterator로 순회
		
		Iterator<Member> iter = hashSet.iterator();
		while(iter.hasNext()) {
			Member m = iter.next();
			if(memberId == m.getMemberId()) {//memberId가 같으면 
				hashSet.remove(m);
				flag = true;
				System.out.println(memberId+" 삭제 되었습니다.");
				return flag;
			}
		}
		
		if(flag==false) {
			System.out.println(memberId+" 삭제 데이터가 없습니다.");
		}
		
		return flag;
	}
	
	/**
	 * 모든 멤버 콘솔 출력!
	 */
	public void showAllMember() {
		for(Member m :hashSet) {
			System.out.println(m);
		}
		
		System.out.println();
	}
	
	
	
	
	
	
	
	
	
}
