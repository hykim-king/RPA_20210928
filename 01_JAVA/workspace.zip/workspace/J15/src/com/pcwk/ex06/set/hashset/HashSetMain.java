package com.pcwk.ex06.set.hashset;

import java.util.HashSet;
import java.util.Set;

public class HashSetMain {

	public static void main(String[] args) {
		Set<String> hashSet=new HashSet<>();
		//HashSet<String> hashSet=new HashSet<>();
		
		hashSet.add("오일남");
		hashSet.add("오일남");
		hashSet.add("강새벽");
		hashSet.add("장덕수");
		hashSet.add("알리 압둘");
		
		System.out.println(hashSet);
	}

}
//[오일남, 강새벽, 알리 압둘, 장덕수]