package com.pcwk.ex01.vector;

import java.util.Vector;
//ctrl+shif+o : import 사용않하는 것, *표로 된것을 class으로 변경
public class VectorMain {

	public static void main(String[] args) {
		Vector<String> vector01=new Vector<>(5);

		vector01.add("1");
		vector01.add("2");
		vector01.add("3");
		vector01.add("4");
		vector01.add("5");
		vector01.add("6");
		print(vector01);
		
	}
	
	
	public static void print(Vector<String> v) {
		//Vector에 내용 출력:toString() call
		System.out.println(v);
//		for(String s :v) {
//			System.out.print(s+",");
//		}
//		System.out.println();
		
		
		//Vector size() : vector에 담고 있는 element 개수
		System.out.println("element 개수:"+v.size());
		
		//Vector의 용량  
		System.out.println("담을수 있는 용량 :"+v.capacity());
		
	}

}
//[1, 2, 3, 4, 5, 6]
//element 개수:6
//담을수 있는 용량 :10