package com.pcwk.ex08.set.treeset;

import java.util.Iterator;
import java.util.TreeSet;

public class MemberTreeSet {
	private TreeSet<Member> treeSet;
	
	public MemberTreeSet() {
		treeSet = new TreeSet<>();
	}
	
	/**
	 * 멤버 추가
	 * @param member
	 */
	public void addMember(Member member) {
		treeSet.add(member);
	}
	
	/**
	 * 멤버 삭제
	 * @param memberId
	 * @return
	 */
	public boolean removeMember(int memberId) {
		Iterator<Member>  iter = treeSet.iterator();
		//다음 데이터가 있으면 true
		while(iter.hasNext()) {
			Member m = iter.next();
			if(memberId == m.getMemberId()) {
				treeSet.remove(m);
				
				return true;
			}
		}
		
		System.out.println(memberId+"가 존재하지 않습니다.");
		
		return false;
		
	}
	
	/**
	 * 멤버 전체 출력
	 */
	public void showAllMember() {
		for(Member m  :this.treeSet) {
			System.out.println(m.toString());
		}
		System.out.println();
	}
	
	
	
	
	
	
	
}
