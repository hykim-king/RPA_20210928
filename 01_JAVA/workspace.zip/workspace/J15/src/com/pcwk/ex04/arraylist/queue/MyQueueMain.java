package com.pcwk.ex04.arraylist.queue;

import java.util.LinkedList;
import java.util.Queue;

public class MyQueueMain {

	public static void main(String[] args) {
		MyQueue myQueue=new MyQueue();
		myQueue.enQueue("A");
		myQueue.enQueue("B");
		myQueue.enQueue("C");
		
		System.out.println(myQueue);
		//queue
		//Queue : First in First Out (FIFO)			
		
		System.out.println(myQueue.deQueue());
		System.out.println(myQueue.deQueue());
		System.out.println(myQueue.deQueue());
		
		//null
		System.out.println(myQueue.deQueue());
		
		
		//기존에 있던 queue를 생성: 
		//LinkedList는 Queue interface를 구현 함.
		Queue<String>  q = new LinkedList<>();
		
	}

}
