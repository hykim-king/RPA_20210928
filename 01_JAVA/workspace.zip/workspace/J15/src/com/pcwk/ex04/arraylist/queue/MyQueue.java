package com.pcwk.ex04.arraylist.queue;

import java.util.ArrayList;

public class MyQueue {
	//Queue : First in First Out (FIFO)								
	private ArrayList<String> arrayQueue;
	
	public MyQueue() {
		arrayQueue = new ArrayList<>();
	}
	
	
	//queue추가
	/**
	 * queye에 추가 
	 * @param data
	 */
	public void enQueue(String data) {
		//arrayList 끝에 추가
		arrayQueue.add(data);
	}
	
	
	
	//queue 데이테 조회
	/**
	 * 데이테 조회
	 * @return
	 */
	public String deQueue() {
		
		//null처리
		int len = arrayQueue.size();
		if(0==len) {
			System.out.println("큐가 비었습니다.");
			return null;
		}
		
		
		//arrayList에 첫 데이터 
		//삭제하고, 그 데이터를 return;
		return arrayQueue.remove(0);
	}
	
	@Override
	public String toString() {
		return this.arrayQueue.toString();
	}
	
	
	
	
	
	
	
	
	
	
	
}
