/**
 * package: com.pcwk.loop
 * file name: Q04_04.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class Q04_04 {

	
	// spaceCount
	// 3   *   3
	// 2  ***  2
	// 1 ***** 1
	// 0*******0	
	public static void main(String []args) {
	    char start ='*';
	    char blank =' ';
	    
	    int lineCount = 4;
	    int blankCount= 3;
	    int starCount = 1;
	    
	    
		for(int i=0;i<lineCount;i++) {
			for (int j = 0; j < blankCount; j++) {
				System.out.print(blank);
			}
			for (int j = 0; j < starCount; j++) {
				System.out.print(start);
			}
			for (int j = 0; j < blankCount; j++) {
				System.out.print(blank);
			}	
			blankCount -= 1;//space는 감소
			starCount  += 2;//별은 2씩 증가			
			System.out.println();
		}
	}
}
