/**
 * package: com.pcwk.loop
 * file name: Q04_01.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class Q04_01_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 3;

		double result = 0;
		char operator = '+';

		switch (operator) {
		case '+':
			result = num1 + num2;
			break;
		case '-':
			result = num1 - num2;
			break;
		case '*':
			result = num1 * num2;
			break;
		case '/':
			result = num1 / (num2 * 1.0);
			break;
		default:
			System.out.println("연산자를 확인 하세요.");
			return;
		}
		

		System.out.println(num1 + ("" + operator) + num2 + "=" + result);
	}

}
