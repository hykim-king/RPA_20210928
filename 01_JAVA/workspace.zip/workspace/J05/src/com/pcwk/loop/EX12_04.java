/**
 * package: com.pcwk.loop
 * file name: EX12_04.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX12_04 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 1+(-2)+3+(-4)+...과 같은 식으로 계속 더해나갔을 때, 몇까지 더해야 총합 100이상이 되는지 구하시오.
		int sum = 0;//합계
		int sign= 1;//+,-전환 부호 변수
		int cnt =1;
		for(int i=1;true;sign=-sign,i++) {
			cnt = (i*sign);
			sum+=cnt;
			System.out.println(i+",  cnt:"+cnt);
			
			//System.out.println("sum:"+sum);
			if(sum>=100) {
				break;
			}
			
		}
		System.out.println("==============");
		System.out.println("sum:"+sum);
		System.out.println("cnt:"+ (cnt<0?cnt=-cnt:cnt));
		System.out.println("==============");
		
		
		
		


	}

}
