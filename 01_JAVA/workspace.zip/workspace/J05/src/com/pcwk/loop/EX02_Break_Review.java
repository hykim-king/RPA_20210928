/**
 * package: com.pcwk.loop
 * file name: EX01_Break.java
 * description: break
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX02_Break_Review {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int sum = 0;
		int num = 0;
		
		for(num=1;;num++) {//합한 값이 100보다 클때 종료
			sum+=num;
			if(sum>=500) {
				break;
			}
			
		}
		
		System.out.println("num:"+num);
		System.out.println("sum:"+sum);

	}

}
