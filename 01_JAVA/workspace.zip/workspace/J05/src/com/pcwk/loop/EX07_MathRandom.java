/**
 * package: com.pcwk.loop
 * file name: EX07_MathRandom.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX07_MathRandom {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//1<=x<4 사이 난수
		int com = (int)(Math.random()*3)+1;
		
		System.out.println(com);

	}

}
