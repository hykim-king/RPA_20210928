/**
 * package: com.pcwk.loop
 * file name: EX11_NamedLoop.java
 * description:이름 붙은 반복문
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX11_NamedLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Loop1: for(int i=2;i<=9;i++) {
			
			for(int j=1;j<=9;j++) {
				if(j==5) {
					break Loop1;
				}
				System.out.println(i+"*"+j+"="+(i*j));
			}
			System.out.println();
			
		}//--for i

	}

}
