/**
 * package: com.pcwk.loop
 * file name: EX09_Num.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

import java.util.Scanner;

/**
 * @author HKEDU
 *
 */
public class EX09_Num {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	// 사용자로 부터 숫자를 입력 받고, 각 숫자 자리의 합을 구하기.	
	// 12345				1+2+3+4+5					=15						

		int num = 0;
		int sum = 0;
		System.out.print("숫자를 입력 하세요.ex)12345 >");
		Scanner scanner=new Scanner(System.in);
		num = scanner.nextInt();
		System.out.println("num="+num);
		while(num!=0) {
			sum+=num % 10;
			System.out.println("끝자리: "+num % 10);
			
			//자리 이동
			num/=10;
			//num = num/10;
		}//--while end

		System.out.println("sum: "+sum);
		
	}

}
