/**
 * package: com.pcwk.loop
 * file name: EX08_RockPaperScissorsGame.java
 * description: 가위(1),바위(2),보(3)
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;
import java.util.Scanner;
/**
 * @author HKEDU
 *
 */
public class EX08_RockPaperScissorsGame {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//사용자 가위(1),바위(2),보(3)

		System.out.print("가위(1),바위(2),보(3)중 하나를 입력 하세요>");
		int user;//사용자
		Scanner scanner=new Scanner(System.in);
		user = scanner.nextInt();
		
		
		int com = (int)(Math.random()*3)+1;//컴퓨터
		
		System.out.println("당신은 "+user +"입니다.");
		System.out.println("Computer는 "+com +"입니다.");
		
//		 0 비겼습니다.					
//		-1, 2 컴퓨터 승					
//		 1,-2 사용자승					
		
		switch(user - com) {
		case -1: case 2:
				System.out.println("컴퓨터 승");
			break;
		case 1: case -2:
				System.out.println("사용자 승");
			break;
		case 0:
				System.out.println("비겼습니다");
			break;
		}

	}

}
