/**
 * package: com.pcwk.loop
 * file name: EX04_Scanner.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;
import java.util.Scanner;
/**
 * @author HKEDU
 *
 */
public class EX04_Scanner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int score= 0;
		System.out.print("점수를 입력해주세요.>");
		//
		Scanner  scanner=new Scanner(System.in);
		score = scanner.nextInt();//숫자를 입력하고 Enter 치면 다음 문장으로 이동
		
		System.out.println("당신의 접수는 "+score+"입니다.");
		
	}

}
