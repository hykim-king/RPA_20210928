/**
 * package: com.pcwk.loop
 * file name: EX03_EnhancedFor.java
 * description: 향상된 for
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX03_EnhancedFor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] arr = {10,20,30,40,50};
		int sum   = 0;
		
		
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		System.out.println();
		
		//향상된 for
		for(int tmp :arr) {
			System.out.print(tmp+",");
			sum+=tmp;
		}
		
		System.out.println("sum:"+sum);
		
		
		
		
		
		
		
		
		

	}

}
