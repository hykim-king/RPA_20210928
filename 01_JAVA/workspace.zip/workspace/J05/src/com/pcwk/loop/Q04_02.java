/**
 * package: com.pcwk.loop
 * file name: Q04_02.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class Q04_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 구구단을 짝수 단만 출력하도록 프로그램을 만들어 보세요.

		for (int i = 2; i <= 9; i++) {

			if (i % 2 != 0) {
				continue;
			}

			for (int j = 1; j <= 9; j++) {
				System.out.println(i + "*" + j + "=" + (i * j));
			}

			System.out.println();
		}

	}

}
