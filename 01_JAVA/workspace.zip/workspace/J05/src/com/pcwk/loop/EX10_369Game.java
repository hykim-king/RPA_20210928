/**
 * package: com.pcwk.loop
 * file name: EX10_369Game.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class EX10_369Game {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//1부터 100사이 숫자 중에 3의 배수(3,6,9)가 포함 되어 있으면, 
		//포함된 개수만큼 박수를 치는 369게임
		
		for(int i=1;i<=100;i++) {
			System.out.print("i="+i);
			
			//-------------
			int tmp = i;
			do {
				//i=100짝짝 제외
				if(tmp%10%3==0 && tmp%10!=0) {
					System.out.print("짝");
				}
				
				
			}while( (tmp/=10) !=0);
			//-----------------------
			
			System.out.println();
		}


	}

}
