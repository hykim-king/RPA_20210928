/**
 * package: com.pcwk.loop
 * file name: EX05_NestedIf.java
 * description: 중첩 IF
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

import java.util.Scanner;

/**
 * @author HKEDU
 *
 */
public class EX06_NestedSwitch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 90점 이상 A
		// 98이상이면 A+
		// 94미만 A-
		//
		// 80점 이상 B
		// 88이상이면 B+
		// 84미만 B-
		//
		// 70점 이상 C
		// 78이상이면 C+
		// 74미만 C-
		//
		// 60점 이상 D
		// 68이상이면 D+
		// 64미만 D-
		// 60점 미만이면 F

		int score = 0;// 점수
		char grade = ' ';// A,B,C,D,F
		char opt = '0';// +,-,0

		System.out.print("점수를 입력 하세요>");
		// 점수를 console에서 입력 받기
		Scanner scanner = new Scanner(System.in);
		score = scanner.nextInt();

		System.out.println("당신의 점수는 " + score + "입니다.");

		// int/int -> int
        // 88/10   ->  8
		switch (score / 10) {
		case 10:
		case 9:
			grade = 'A';
			if (score >= 98) {
				opt = '+';
			} else if (score < 94) {
				opt = '-';
			}
			break;
		case 8:

			grade = 'B';

			if (score >= 88) {
				opt = '+';
			} else if (score < 84) {
				opt = '-';
			}
			break;
		case 7:
			grade = 'C';

			if (score >= 78) {
				opt = '+';
			} else if (score < 74) {
				opt = '-';
			}
			break;
		case 6:
			grade = 'D';

			if (score >= 68) {
				opt = '+';
			} else if (score < 64) {
				opt = '-';
			}
			break;
		default:
			grade = 'F';
			opt = ' ';
			break;

		}

		System.out.println("당신의 학점은 " + grade + "" + opt);

	}

}
