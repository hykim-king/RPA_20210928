/**
 * package: com.pcwk.loop
 * file name: Q04_03.java
 * description:
 * user: HKEDU
 * create date: 2021-10-06
 * version: 0.3
 *
 */
package com.pcwk.loop;

/**
 * @author HKEDU
 *
 */
public class Q04_03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 구구단을 단보다 곱하는 수가 작거나 같은 경우까지만
		// 출력하는 프로그램을 만들어 보세요.
		for (int i = 2; i <= 9; i++) {



			for (int j = 1; j <= 9; j++) {
				if(i<j) {
					break;
				}
				
				System.out.println(i + "*" + j + "=" + (i * j));				
//필요없는 반복이 발생 효율이 좋지 못하다.				
//				if(i>=j) {
//					System.out.println(i + "*" + j + "=" + (i * j));
//				}
			}

			System.out.println();
		}
	}

}
