/**
 * package: com.pcwk.array
 * file name: EX05_ArrayChar.java
 * description: char 저장 배열 
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX05_ArrayChar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		char[]  alphabet=new char[26];
		char ch = 'A';//ASCII code 65, a:97
		
		//알파벳 할당:A,B....Z
		for(int i=0;i<alphabet.length;i++,ch++){
			//System.out.println(ch);
			alphabet[i]=ch;
		}
		
		
		//알파벳 출력
		for(int i=0;i<alphabet.length;i++) {
			System.out.print(alphabet[i]+",");
		}

	}

}
