/**
 * package: com.pcwk.array
 * file name: EX09_Exam01.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX09_Exam01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 총합과 평균: int[] score ={100,88,100,100,90};

		int[] score ={100,88,100,100,90};
		int sum   = 0;   //총점
		float avg = 0.0f;//평균
		
		for(int i=0;i<score.length;i++) {
			sum+=score[i];
		}
		
		System.out.println("sum:"+sum);
		
		avg = sum/(float)score.length;
		
		System.out.println("avg:"+avg);
		
	}

}
//sum:478
//avg:95.6