/**
 * package: com.pcwk.array
 * file name: EX10_Exam02.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX10_Exam02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//최대값, 최소값을 출력 하세요. int []score = {78,88,91,33,100,55,95};
		int []score = {78,88,91,33,100,55,95};
		int max = score[0];//최대값
		int min = score[0];//최소값
		
		for(int i=1;i<score.length;i++) {
			if(score[i]>max) {//최대값
				max= score[i];
			}
			
			if(score[i]<min) {//최소값
				min = score[i];
			}
		}
		System.out.println("최대값:"+max);
		System.out.println("최소값:"+min);
	}

}
//최대값:100
//최소값:33