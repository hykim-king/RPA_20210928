/**
 * package: com.pcwk.array
 * file name: EX07_MultiArray.java
 * description: 다차원 배열
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX07_MultiArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int [][] arr= { {1,2,3}
		               ,{4,5,6} };
		
		System.out.println("arr.length:"+arr.length);//행 length
		System.out.println("arr[1].length:"+arr[1].length);//열 length
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+",");
			}
			System.out.println();
		}

	}

}
