/**
 * package: com.pcwk.array
 * file name: EX02_ArrayReview.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX02_ArrayReview {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] arr = new int[] {3,6,9,12};								
		System.out.println(arr[0]+2);//5
		
		System.out.println(arr[1]+arr[2]);//15
		// java.lang.ArrayIndexOutOfBoundsException
		//System.out.println(arr[4]-3);
	}

}
