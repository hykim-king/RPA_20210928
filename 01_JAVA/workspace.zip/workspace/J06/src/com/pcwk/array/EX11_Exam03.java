/**
 * package: com.pcwk.array
 * file name: EX11_Exam03.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX11_Exam03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 섞기(shuffle),자리바꾸기,
		int[] numArr = new int[10];
		
		for(int i=0;i<numArr.length;i++) {
			numArr[i]=i;
			System.out.print(numArr[i]);
		}
		
		System.out.println();
		
		//shuffle
		for(int i=0;i<50;i++) {
			int n = (int)(Math.random()*10);
			//System.out.println(n);
			
			int tmp   = numArr[0];// 빈컵 - 우유
			numArr[0] = numArr[n];// 빈우유 -> 주스 
			numArr[n] = tmp;//주스 -> 빈컵(우유담겨 있는)			
		}

		for(int i=0;i<numArr.length;i++) {
			System.out.print(numArr[i]);
		}		
		
	}

}
