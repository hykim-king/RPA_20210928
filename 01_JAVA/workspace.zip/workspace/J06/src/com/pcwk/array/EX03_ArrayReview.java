/**
 * package: com.pcwk.array
 * file name: EX03_ArrayReview.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX03_ArrayReview {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int   score01[]= {1,2,3,4,5,6,7,8,9,10};

		int   sum = 0;
		
		System.out.println("score01.length:"+score01.length);
		
		for(int i=0;i<score01.length;i++) {
			sum=sum+score01[i];
		}
		
		System.out.println("sum:"+sum);
		
	}

}
