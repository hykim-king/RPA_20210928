/**
 * package: com.pcwk.array
 * file name: EX04_Array.java
 * description: Array 유효값
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX04_Array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double[]  data=new double[5];
		
		int size = 0;//유효한 값 저장 인덱스
		data[0] = 10.0;//배열요소 0번째에 10.0대입
		size++;
		data[1] = 20.0;//배열요소 1번째에 20.0대입
		size++;
		data[2] = 30.0;//배열요소 2번째에 30.0대입
		size++;
		
		for(int i=0;i<size;i++) {
			System.out.println(data[i]);
		}
		System.out.println();
		//------------------------------
		for(int i=0;i<data.length;i++) {
			System.out.println(data[i]);
		}
	}

}
