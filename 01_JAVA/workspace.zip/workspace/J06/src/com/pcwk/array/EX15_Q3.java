/**
 * package: com.pcwk.array
 * file name: EX15_Q3.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX15_Q3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 배열의 길이가 5인 정수형 배열을 선언하고,
		// 1~ 10중 짝수만을 배열에 저장한 후 그 합을 출력하세요.
		
		int numArr[]=new int[5];//배열의 길이가 5인 정수형 배열을 선언
		
		int idx = 0;//numArr 배열 index
		for(int i=1;i<=10;i++) {
			if(i%2==0) {//1~ 10중 짝수만을 배열에 저장
				numArr[idx]=i;
				idx++;
			}
		}

		int sum = 0;
		//향상된 for
		for(int num:numArr) {
			System.out.print(num+",");
			sum+=num;//합을 출력
		}
		System.out.println();
		System.out.println("sum:"+sum);

	}

}
//2,4,6,8,10,
//sum:30
