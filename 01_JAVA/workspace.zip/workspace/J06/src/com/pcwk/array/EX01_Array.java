/**
 * package: com.pcwk.array
 * file name: EX01_Array.java
 * description: Array배열 생성과 초기화
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX01_Array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//배열 선언과 초기화
		//int[] score = new int[] {88,90,91};
		
		int   score01[]= {88,90,91,92};
        
		//[] : 인덱스 연산자, 첨자 연산자
		//Cannot define dimension expressions when an array initializer is provided
		//int[] score02 = new int[3] {88,90,91};
		
		System.out.println("score01[0]="+score01[0]);
		System.out.println("score01[1]="+score01[1]);
		int add = score01[0]+score01[1];
		System.out.println("add="+add);
		//
		//score01.length: 배열에 길이
		for(int i=0;i<score01.length;i++) {
			System.out.println(score01[i]);
		}

	}

}
