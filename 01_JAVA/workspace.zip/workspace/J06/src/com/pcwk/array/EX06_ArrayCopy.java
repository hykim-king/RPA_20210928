/**
 * package: com.pcwk.array
 * file name: EX06_ArrayCopy.java
 * description: 배열 copy
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX06_ArrayCopy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int [] array01 = {10,20,30,40,50};
		int [] array02 = {1,2,3,4,5};
		//향상된 for
		for( int tmp  : array02) {
			System.out.print(tmp+",");
		}
		System.out.println();
		//복사할 배열, 복사할 첫 위치,대상배열,붙여넣을 위치, 복사할 요소 개수
		System.arraycopy(array01, 0, array02, 1, 4);
		
		for(int i=0;i<array02.length;i++) {
			System.out.println(array02[i]);
		}
		
	}
}
//1,2,3,4,5,
//1
//10
//20
//30
//40