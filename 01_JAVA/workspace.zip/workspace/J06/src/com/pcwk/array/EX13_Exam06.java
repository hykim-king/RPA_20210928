/**
 * package: com.pcwk.array
 * file name: EX13_Exam06.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX13_Exam06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 정렬하기(sort) 오름차순(1,2,3,4), 내림차순(4,3,2,1)
		//int [] numArr = {79,88,91,33,100};
		int [] numArr = {3,1,4,2,0};
		//01. 배열에 숫자한게를 찾는다.
		//02. 나머지 배열 숫자와 비교를 한다.(오름차순)
		//03. 자리를 바꾼다.
		
		//향상된 for
		for(int num  :numArr) {
			System.out.print(num+",");
		}
		System.out.println();
		
		//버블 sort
		for(int i=0;i<numArr.length-1;i++) {
			for(int j=0;j<numArr.length-1-i;j++) {
				//if(numArr[j]>numArr[j+1]) {//앞의 값이 크면 자리를 교환(오름차순)
				if(numArr[j]<numArr[j+1]) {//앞의 값이 크면 자리를 교환(내림차순)
					int tmp     = numArr[j];
					numArr[j]   = numArr[j+1];
					numArr[j+1] = tmp;
				}
			}
		}
		
		//sort이후 
		for(int i=0;i<numArr.length;i++) {
			System.out.print(numArr[i]+",");
		}
	}

}
