/**
 * package: com.pcwk.array
 * file name: EX12_Exam05.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX12_Exam05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 01. 배열 1~ 45
		// 02. shuffle
		// 03. 6개만 출력
		
		//01.
		int[] ball=new int[45];
		
		for(int i=0;i<ball.length;i++) {
			ball[i] = i+1;
			System.out.print(ball[i]+",");
		}
		System.out.println();
		
		
		for(int i=0;i<6;i++) {
			//0<=x<1.0
			//0<=x<45.0
			//0<=x<45
			int n = (int)(Math.random()*45);
			//자리교환
			int tmp = ball[i];
			ball[i] = ball[n];
			ball[n] = tmp;
		}
		
		for(int i=0;i<6;i++) {
			System.out.print(ball[i]+",");
		}
		
		

	}

}
