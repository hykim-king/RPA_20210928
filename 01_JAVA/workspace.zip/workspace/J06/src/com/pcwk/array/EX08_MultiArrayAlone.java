/**
 * package: com.pcwk.array
 * file name: EX08_MultiArrayAlone.java
 * description:
 * user: HKEDU
 * create date: 2021-10-07
 * version: 0.3
 *
 */
package com.pcwk.array;

/**
 * @author HKEDU
 *
 */
public class EX08_MultiArrayAlone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 01. 소문자를 할당한다.
		// 02. 두줄씩 출력 한다.
		char [][]alphabet= new char[13][2];
		char ch = 'a';
		
		//소문자 :a~z;
		for(int i=0;i<alphabet.length;i++) {
			for(int j=0;j<alphabet[i].length;j++) {
				alphabet[i][j]=ch;
				ch++;
			}
		}
		
		//출력
		for(int i=0;i<alphabet.length;i++) {
			for(int j=0;j<alphabet[i].length;j++) {
				System.out.print( alphabet[i][j]+",");
                 
			}
			System.out.println();
		}
	}

}
//a,b,
//c,d,
//e,f,
//g,h,
//i,j,
//k,l,
//m,n,
//o,p,
//q,r,
//s,t,
//u,v,
//w,x,
//y,z,