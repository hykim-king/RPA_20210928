package com.pcwk.ex03.url;

import java.net.*;
import java.util.Date;
import java.io.*;

import com.pcwk.cmn.Common;

public class URLConnectionEx01Main implements Common {

	public static void main(String[] args) {
		URL url = null;
		String address = "http://www.learningmen.com:80/ins/5000200458270?site_=normal";
		
		try {
			url = new URL(address);
			URLConnection conn = url.openConnection();
			
			LOG.debug("date:"+new Date(conn.getDate()));
			LOG.debug("date:"+conn.getDate());
			LOG.debug("content type: "+conn.getContentType());
			
			LOG.debug("content length: "+conn.getContentLength());
			LOG.debug("content getHeaderFields: "+conn.getHeaderFields());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
