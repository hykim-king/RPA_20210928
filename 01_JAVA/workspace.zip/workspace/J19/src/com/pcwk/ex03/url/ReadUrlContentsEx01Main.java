package com.pcwk.ex03.url;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import com.pcwk.cmn.Common;

public class ReadUrlContentsEx01Main implements Common {

	public static void main(String[] args) {
		URL url = null;
		String address = "http://www.learningmen.com/ins/5000200458270?site_=normal";
		BufferedReader input = null;
		String line = "";// Line단위 데이터 저장

		try {
			url = new URL(address);
			// InputStreamReader(InputStream)
			input = new BufferedReader(new InputStreamReader(url.openStream()));

			while ((line = input.readLine()) != null) {
				System.out.println(line);
			}

			input.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
