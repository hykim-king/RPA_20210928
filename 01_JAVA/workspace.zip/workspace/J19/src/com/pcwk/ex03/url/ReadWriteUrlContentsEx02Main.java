package com.pcwk.ex03.url;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import com.pcwk.cmn.Common;

public class ReadWriteUrlContentsEx02Main implements Common {

	public static void main(String[] args) {
		URL url = null;
		String address = "http://www.learningmen.com/ins/5000200458270?site_=normal";

		BufferedReader input = null;
		String line = "";// Line단위 데이터 저장

		// writer
		// leanMan.html
		FileWriter fw = null;
		BufferedWriter bw = null;

		try {
			url = new URL(address);
			// InputStreamReader(InputStream)
			input = new BufferedReader(new InputStreamReader(url.openStream()));

			// 파일 Writer
			fw = new FileWriter("leanMan.html");
			bw = new BufferedWriter(fw);

			while ((line = input.readLine()) != null) {
				System.out.println(line);
				bw.write(line+"\n");
			}

			//자원반납
			input.close();
			bw.close();
			LOG.debug("====================");
			LOG.debug("=생성완료===");
			LOG.debug("====================");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
