package com.pcwk.ex03.url;
import java.net.*;
import java.io.*;

import com.pcwk.cmn.Common;

public class URLEx01Main implements Common  {
	
	public static void main(String[] args) throws MalformedURLException, URISyntaxException {
		//LOG.debug("Common Log");
		URL url=new URL("http://www.learningmen.com:80/ins/5000200458270?site_=normal");
		LOG.debug("호스트명:포트 "+url.getAuthority());
		LOG.debug("프로토콜 "+url.getProtocol());
		LOG.debug("파일 "+url.getFile());
		LOG.debug("쿼리"+url.getQuery());
		LOG.debug("URI=>"+url.toURI());
	}

}
//2021-10-27 14:33:17,923 DEBUG [main] cmn.Common        (URLEx01Main.java:12)     - 호스트명:포트 www.learningmen.com:80
//2021-10-27 14:33:17,942 DEBUG [main] cmn.Common        (URLEx01Main.java:13)     - 프로토콜 http
//2021-10-27 14:33:17,943 DEBUG [main] cmn.Common        (URLEx01Main.java:14)     - 파일 /ins/5000200458270?site_=normal
//2021-10-27 14:33:17,944 DEBUG [main] cmn.Common        (URLEx01Main.java:15)     - 쿼리site_=normal
//2021-10-27 14:33:17,955 DEBUG [main] cmn.Common        (URLEx01Main.java:16)     - URI=>http://www.learningmen.com:80/ins/5000200458270?site_=normal
