package com.pcwk.ex01.file;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileEx01Main {
	public static final Logger LOG = Logger.getLogger(FileEx01Main.class);

	public static void main(String[] args) throws IOException {
		String filePath = "D:\\RPA_20210928\\01_JAVA\\workspace\\J19\\src\\com\\pcwk\\ex01\\file\\newFile.txt";

		File file = new File(filePath);
		file.createNewFile();

		LOG.debug("파일 여부: " + file.isFile());
		LOG.debug("디렉토리 여부: " + file.isDirectory());
		LOG.debug("경로를 제외한 파일이름: " + file.getName());
		LOG.debug("파일이 속해 있는 디렉토리: " + file.getParent());

		LOG.debug("경로를 포함한 파일이름: " + file.getPath());

		LOG.debug("파일 절대 경로: " + file.getAbsolutePath());
		LOG.debug("읽을수 있는지 여부: " + file.canRead());
		LOG.debug("쓸수 있는지 여부: " + file.canWrite());
		LOG.debug("실행할수 있는지 여부: " + file.canExecute());

		LOG.debug("file.pathSeparator: " + file.pathSeparator);
		LOG.debug("file.pathSeparatorChar: " + file.pathSeparatorChar);

		LOG.debug("file.separator: " + file.separator);
		LOG.debug("file.separatorChar: " + file.separatorChar);
		file.delete();
	}

}
//2021-10-27 09:39:17,623 DEBUG [main] file.FileEx01Main (FileEx01Main.java:16)     - 파일 여부: true
//2021-10-27 09:39:17,634 DEBUG [main] file.FileEx01Main (FileEx01Main.java:17)     - 디렉토리 여부: false
//2021-10-27 09:39:17,634 DEBUG [main] file.FileEx01Main (FileEx01Main.java:18)     - 경로를 제외한 파일이름: newFile.txt
//2021-10-27 09:39:17,634 DEBUG [main] file.FileEx01Main (FileEx01Main.java:19)     - 파일이 속해 있는 디렉토리: D:\RPA_20210928\01_JAVA\workspace\J19\src\com\pcwk\ex01\file
//2021-10-27 09:39:17,635 DEBUG [main] file.FileEx01Main (FileEx01Main.java:21)     - 경로를 포함한 파일이름: D:\RPA_20210928\01_JAVA\workspace\J19\src\com\pcwk\ex01\file\newFile.txt
//2021-10-27 09:39:17,635 DEBUG [main] file.FileEx01Main (FileEx01Main.java:23)     - 파일 절대 경로: D:\RPA_20210928\01_JAVA\workspace\J19\src\com\pcwk\ex01\file\newFile.txt
//2021-10-27 09:39:17,636 DEBUG [main] file.FileEx01Main (FileEx01Main.java:24)     - 읽을수 있는지 여부: true
//2021-10-27 09:39:17,636 DEBUG [main] file.FileEx01Main (FileEx01Main.java:25)     - 쓸수 있는지 여부: true
//2021-10-27 09:39:17,641 DEBUG [main] file.FileEx01Main (FileEx01Main.java:26)     - 실행할수 있는지 여부: true
//2021-10-27 09:39:17,641 DEBUG [main] file.FileEx01Main (FileEx01Main.java:28)     - file.pathSeparator: ;
//2021-10-27 09:39:17,641 DEBUG [main] file.FileEx01Main (FileEx01Main.java:29)     - file.pathSeparatorChar: ;
//2021-10-27 09:39:17,642 DEBUG [main] file.FileEx01Main (FileEx01Main.java:31)     - file.separator: \
//2021-10-27 09:39:17,642 DEBUG [main] file.FileEx01Main (FileEx01Main.java:32)     - file.separatorChar: \