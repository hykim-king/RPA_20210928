package com.pcwk.ex01.file;
import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileEx02Main {
	public static final Logger LOG = Logger.getLogger(FileEx02Main.class);
	
	public static void main(String[] args) {

		// 파일/디렉토리 구분
		String dirPath = "C:\\Program Files\\Java\\jdk1.8.0_291";
		if(args.length !=1) {
			LOG.debug("USAGE: Directory를 입력 하세요.");
			System.exit(0);//jvm정상 종료
		}
		String directory =  args[0];
		LOG.debug("directory: "+directory);
		LOG.debug("============================");
		
		File  f=new File(directory);
		
		if(!f.exists() || !f.isDirectory()) {
			LOG.debug("유효하지 않은 디렉토리 입니다.");
			System.exit(0);
		}
		
		
		File[] files = f.listFiles();
		
		for(int i=0;i<files.length;i++) {
			String fileName = files[i].getName();
			LOG.debug(files[i].isDirectory()?"["+fileName+"]":fileName);
		}

	}
}
//2021-10-27 10:12:12,041 DEBUG [main] file.FileEx02Main (FileEx02Main.java:19)     - directory: C:\\Program Files\\Java\\jdk1.8.0_291
//2021-10-27 10:12:12,047 DEBUG [main] file.FileEx02Main (FileEx02Main.java:20)     - ============================
//2021-10-27 10:12:12,056 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - [bin]
//2021-10-27 10:12:12,057 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - COPYRIGHT
//2021-10-27 10:12:12,058 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - [include]
//2021-10-27 10:12:12,059 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - javafx-src.zip
//2021-10-27 10:12:12,060 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - jmc.txt
//2021-10-27 10:12:12,064 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - [jre]
//2021-10-27 10:12:12,086 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - [legal]
//2021-10-27 10:12:12,087 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - [lib]
//2021-10-27 10:12:12,088 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - LICENSE
//2021-10-27 10:12:12,089 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - README.html
//2021-10-27 10:12:12,090 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - release
//2021-10-27 10:12:12,091 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - src.zip
//2021-10-27 10:12:12,092 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - THIRDPARTYLICENSEREADME-JAVAFX.txt
//2021-10-27 10:12:12,093 DEBUG [main] file.FileEx02Main (FileEx02Main.java:34)     - THIRDPARTYLICENSEREADME.txt

