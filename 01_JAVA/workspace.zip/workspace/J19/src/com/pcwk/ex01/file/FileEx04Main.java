package com.pcwk.ex01.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileEx04Main {
	public static final Logger LOG = Logger.getLogger(FileEx04Main.class);
	static int found = 0;// KEYWORD count

	public static void main(String[] args) {
		// String dirPath = "D:\\RPA_20210928\\01_JAVA\\workspace\\J19";
		// String keyword = "String";
		if (args.length != 2) {
			LOG.debug("USAGE: java FileEx04Main DIRECTORY KEYWORD");
			System.exit(0);
		}
		for (String param : args) {
			LOG.debug("param:" + param);
		}

		File dir = new File(args[0]);// 디렉토리 정보
		String keyword = args[1];// 파일정보

		if (!dir.exists() || !dir.isDirectory()) {
			LOG.debug("유효하지 않은 디렉토리 입니다.");
			System.exit(0);
		}

		try {
			findInFiles(dir, keyword);
		} catch (IOException e) {
			e.printStackTrace();
			LOG.debug("=====================");
			LOG.debug(e);
			LOG.debug("=====================");
		}

		LOG.debug("==============================");
		LOG.debug("총 " + found + "개의 라인에서 " + keyword + "를 발견하였습니다.");

	}

	/**
	 * 해당파일에서 keyword가 몇게 있는지 count
	 * 
	 * @param dir
	 * @param keyword
	 * @throws IOException
	 */
	public static void findInFiles(File dir, String keyword) throws IOException {

		File[] files = dir.listFiles();

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory() == true) {
				findInFiles(files[i], keyword);// 디렉토리 이면 재귀 호출
			} else {
				// 확장자가 *.java이면 읽어
				// FileEx04Main.java
				String fileName = files[i].getName();
				int piriodIdx = fileName.lastIndexOf(".");

				String extension = fileName.substring(piriodIdx + 1);
				// LOG.debug(fileName+",: "+extension);
				if (fileName.indexOf("java") == -1)
					continue;
				LOG.debug(fileName);

				FileReader fr = new FileReader(files[i]);
				BufferedReader br = new BufferedReader(fr);

				String data = "";// 한줄 데이터 저장
				int lineNum = 0;

				while ((data = br.readLine()) != null) {
					lineNum++;
					if (data.indexOf(keyword) != -1) {
						LOG.debug(lineNum + "\t" + data);
						found++;
					}
				}

				LOG.debug("");
				br.close();

			} // --else end

		} // --for end

	}// --findInFiles end

}
