package com.pcwk.ex04.api.naversearch;

import java.io.*;
import java.net.*;

import com.pcwk.cmn.Common;

public class NaverBlogSearchMain implements Common {

	public static void main(String[] args) {
		String clientId = "PF2hZcj7_cmVHc8unUOn";//클라이언트 아이디
		String clientSecret = "Z2F9wQ0NVO";//클라이언트 시크릿
		String text;//검색어
		BufferedReader br=null;
		
		try {
			text = URLEncoder.encode("자바", "UTF-8");//%ED%95%9C%EA%B0%95
			//System.out.println(text);
			//Blog
			//String apiURL ="https://openapi.naver.com/v1/search/blog?query="+text;
			
			//책
			String apiURL ="https://openapi.naver.com/v1/search/book.json?query="+text;
			
			URL  url =new URL(apiURL);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("GET");//GET방식으로 접근
			con.setRequestProperty("X-Naver-Client-Id", clientId);
			con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
			
			int responseCode = con.getResponseCode();
			// HTTP/1.0 200 OK
			// HTTP/1.0 401 Unauthorized
			LOG.debug("responseCode:"+responseCode);
			
			if(200==responseCode) {//로그인 성공
				br=new BufferedReader (new InputStreamReader(con.getInputStream()));
			}else {
				LOG.debug("클라이언트 아이디,클라이언트 시크릿을 확인하세요");
				return;
			}
			
			String inputLine;
			while( (inputLine = br.readLine())!=null ) {
				LOG.debug(inputLine);
			}
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
			
		}
		
		
		
	}

}
