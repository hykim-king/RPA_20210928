package com.pcwk.ex02.inetaddress;


import java.net.*;
import java.util.*;
import org.apache.log4j.*;

public class InetAddRessEx01Main {

	public static final Logger LOG = Logger.getLogger(InetAddRessEx01Main.class);
	
	
	public static void main(String[] args) {
		
		InetAddress    ip = null;
		InetAddress[]  ipAddrArray = null;
		
		try {
			ip = InetAddress.getByName("www.naver.com");
			LOG.debug("HostName:"+ip.getHostName());
			LOG.debug("ip Address: "+ip.getHostAddress());
			//LOG.debug(ip.toString());
			
			//www.naver.com하나에 여러 ip 연결
			//
			ipAddrArray = InetAddress.getAllByName("www.naver.com");
			for(int i=0;i<ipAddrArray.length;i++) {
				LOG.debug(ipAddrArray[i].toString());
			}
			
			
			//client주소 남기기
			ip = InetAddress.getLocalHost();
			LOG.debug("hostName:"+ip.getHostName());//컴퓨터 이름
			LOG.debug("getHostAddress:"+ip.getHostAddress());//컴퓨터 ip
			
			
			
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

}
//2021-10-27 13:37:11,508 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:20)     - HostName:www.naver.com
//2021-10-27 13:37:11,511 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:21)     - ip Address: 223.130.195.95
//2021-10-27 13:37:11,512 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:28)     - www.naver.com/223.130.195.95
//2021-10-27 13:37:11,513 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:28)     - www.naver.com/223.130.200.104
//2021-10-27 13:37:11,518 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:34)     - hostName:DESKTOP-501IEKB
//2021-10-27 13:37:11,518 DEBUG [main] inetaddress.InetAddRessEx01Main (InetAddRessEx01Main.java:35)     - getHostAddress:192.168.0.166

