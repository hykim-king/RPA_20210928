package com.pcwk.cmn;
import org.apache.log4j.Logger;



public interface Common {
	public static final Logger LOG = Logger.getLogger(Common.class);
}
   