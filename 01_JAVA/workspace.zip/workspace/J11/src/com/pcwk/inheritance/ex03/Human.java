package com.pcwk.inheritance.ex03;

public class Human extends Animal {

	@Override
	public void move() {
		System.out.println("사람이 두 발로 걷습니다.");
	}

	
	public void readBook() {
		System.out.println("사람이 책을 읽는다.");
	}
	
}
