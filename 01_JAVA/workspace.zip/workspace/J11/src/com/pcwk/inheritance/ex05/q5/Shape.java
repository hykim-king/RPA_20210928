package com.pcwk.inheritance.ex05.q5;

public class Shape {

	
	public void draw() {
		System.out.println("Shape");
	}
}
