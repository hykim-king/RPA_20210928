package com.pcwk.inheritance.ex14.q6;

public class Grandeur extends Car {

	public Grandeur() {
		super.productName = "Grandeur";
	}
}
