package com.pcwk.inheritance.ex05.q5;

public class Circle extends Shape {

	@Override
	public void draw() {
		System.out.println("Circle");
	}

}
