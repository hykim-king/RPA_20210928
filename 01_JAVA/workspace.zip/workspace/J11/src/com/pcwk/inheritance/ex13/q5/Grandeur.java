package com.pcwk.inheritance.ex13.q5;

public class Grandeur extends Car {

	public Grandeur() {
		super.productName = "Grandeur";
	}
}
