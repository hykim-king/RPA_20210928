package com.pcwk.inheritance.ex03;

public class Tiger extends Animal {

	public Tiger() {
	
	}

	@Override
	public void move() {
		System.out.println("호랑이가 네 발로 뜁니다.");
	}
	
	public void hunting() {
		System.out.println("호랑이가 사냥을 합니다.");
	}
	
}
