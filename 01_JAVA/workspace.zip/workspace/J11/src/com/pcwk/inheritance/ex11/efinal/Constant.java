package com.pcwk.inheritance.ex11.efinal;

public class Constant {
	int num = 10;
	final int MAX_NUM ;//상수
	
	public Constant() {
		MAX_NUM = 100;//상수를 생성자에서 초기화 가능
	}
	
	public static void main(String[] args) {
		Constant cons=new Constant();
		cons.num = 20;
		//cons.MAX_NUM = 99;//상수에 값을 할당 하면 오류
		
		System.out.println(cons.num);
		System.out.println(cons.MAX_NUM);
	}

}
