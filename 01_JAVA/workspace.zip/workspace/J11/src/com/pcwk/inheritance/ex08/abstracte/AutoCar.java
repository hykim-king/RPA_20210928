package com.pcwk.inheritance.ex08.abstracte;

public class AutoCar extends Car {

	@Override
	public void refuell() {
		System.out.println("휘발류를 주유합니다."); 

	}
	
	public void load() {
		System.out.println("짐을 싣습니다.");
	}

}
