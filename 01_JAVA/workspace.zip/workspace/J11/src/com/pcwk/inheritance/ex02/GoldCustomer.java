package com.pcwk.inheritance.ex02;

public class GoldCustomer extends Customer {
    double saleRatio;//할인율
    
    //생성자
    public GoldCustomer(int customerID,String customerName) {
    	super(customerID,customerName);//부모생성자 호출
    	super.customerGrade = "Gold";
    	super.bonusRatio    = 0.02;
    	this.saleRatio      = 0.1;
    }
    //calcPrice(int price)
    public int calcPrice(int price) {
    	super.bonusPoint += price * super.bonusRatio;
    	return price - (int)(price * saleRatio);
    }
}
