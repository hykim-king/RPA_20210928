package com.pcwk.inheritance.ex07.abstracte;

public abstract class AbstractTV {

	public void turnOn() {
		System.out.println("전원을 켭니다.");
	}
	
	
	public void turnOff() {
		System.out.println("전원을 끕니다.");
	}	
	
}
