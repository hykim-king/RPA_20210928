package com.pcwk.inheritance.ex06.abstracte;

public class ComputerMain {

	public static void main(String[] args) {
		//Cannot instantiate the type Computer
		//추상 클래스는 스스로 객체를 만들수 없다.
		//Computer c=new Computer(); 
		//NoteBook   n=new NoteBook();
		
		
		//
		Computer desk=new DeskTop();
		desk.turnOn();
		desk.display();
		desk.typing();
		desk.turnOff();
		System.out.println("======================");
		Computer myNoteBook=new MyNoteBook();
		myNoteBook.turnOn();
		myNoteBook.display();
		myNoteBook.typing();
		myNoteBook.turnOff();
	}

}
//전원을 켭니다.
//DeskTop display()
//DeskTop typing()
//전원을 끕니다.
//======================
//전원을 켭니다.
//NoteBook display()
//MyNoteBook typing()
//전원을 끕니다.