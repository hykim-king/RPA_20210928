package com.pcwk.inheritance.ex06.abstracte;

public class MyNoteBook extends NoteBook {

	@Override
	public void typing() {
		System.out.println("MyNoteBook typing()");
		
	}

}
