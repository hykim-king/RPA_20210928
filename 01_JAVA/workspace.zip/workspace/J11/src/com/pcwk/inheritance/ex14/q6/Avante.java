package com.pcwk.inheritance.ex14.q6;

public class Avante extends Car {

	public Avante() {
		super.productName ="Avante";
	}
}
