package com.pcwk.inheritance.ex14.q6;

public class Genesis extends Car {

	public Genesis() {
		super.productName ="Genesis";
	}
}
