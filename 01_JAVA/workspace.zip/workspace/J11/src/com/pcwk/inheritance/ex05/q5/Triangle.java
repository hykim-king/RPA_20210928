package com.pcwk.inheritance.ex05.q5;

public class Triangle extends Shape {

	@Override
	public void draw() {
		System.out.println("Triangle");
	}

	
}
