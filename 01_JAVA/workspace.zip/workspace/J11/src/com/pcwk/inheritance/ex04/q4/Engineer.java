package com.pcwk.inheritance.ex04.q4;

public class Engineer extends Employee {
	private String skillset;
	//parent에 default생성자가 없어
	//직접 명기해 인자있는 생성자 호출 해야함.
	public Engineer(String name) {
		super(name);
	
	}

}
