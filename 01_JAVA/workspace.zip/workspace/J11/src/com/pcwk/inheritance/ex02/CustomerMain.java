package com.pcwk.inheritance.ex02;

import java.util.*;

public class CustomerMain {

	public static void main(String[] args) {
		//고객 5명, VIP 1명, GOLD 2명, Silver 2명 : ArrayList
		//10010 이순신 Silver
		//10020 신사임당 Silver
		//10030 홍길동 GOLD
		//10040 이율곡 GOLD
		//10050 김유신 VIP ,agentID 12345
		
		ArrayList<Customer> customerList=new ArrayList<>();
		
		Customer cust01=new Customer(10010, "이순신");
		Customer cust02=new Customer(10020, "신사임당");
		
		Customer cust03=new GoldCustomer(10030, "홍길동");
		Customer cust04=new GoldCustomer(10040, "이율곡");
		
		Customer cust05=new VIPCustomer(10050, "김유신", 12345);
		
		customerList.add(cust01);
		customerList.add(cust02);
		
		customerList.add(cust03);
		customerList.add(cust04);
		
		customerList.add(cust05);
		
		//고객정보 출력
		System.out.println("================고객정보 출력================");
		for(Customer customer :customerList) {
			System.out.println(customer.showCustomerInfo());
		}
		
		
		System.out.println("================할인율 보너스 포인트 계산================");
		int price = 10_000_000;
		for(Customer customer   :customerList) {
			int cost = customer.calcPrice(price);
			System.out.println(customer.getCustomerName()+" 님이 "+cost+"원 지블하셨습니다.");
			System.out.println(customer.getCustomerName()+" 님의 현재 보너스 포인트는 "+customer.bonusPoint+" 입니다.");
		}

	}

}
//================고객정보 출력================
//이순신님의 등급은 Silver이며, 보너스 포인트는 0입니다.
//신사임당님의 등급은 Silver이며, 보너스 포인트는 0입니다.
//홍길동님의 등급은 Gold이며, 보너스 포인트는 0입니다.
//이율곡님의 등급은 Gold이며, 보너스 포인트는 0입니다.
//김유신님의 등급은 VIP이며, 보너스 포인트는 0입니다.
//================할인율 보너스 포인트 계산================
//이순신 님이 10000000원 지블하셨습니다.
//이순신 님의 현재 보너스 포인트는 100000 입니다.
//신사임당 님이 10000000원 지블하셨습니다.
//신사임당 님의 현재 보너스 포인트는 100000 입니다.
//홍길동 님이 9000000원 지블하셨습니다.
//홍길동 님의 현재 보너스 포인트는 200000 입니다.
//이율곡 님이 9000000원 지블하셨습니다.
//이율곡 님의 현재 보너스 포인트는 200000 입니다.
//김유신 님이 9000000원 지블하셨습니다.
//김유신 님의 현재 보너스 포인트는 500000 입니다.
