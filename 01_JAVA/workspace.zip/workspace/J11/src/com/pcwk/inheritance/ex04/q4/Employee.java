package com.pcwk.inheritance.ex04.q4;

public class Employee {
	public String name;
	public String grade;
	
	public Employee(String name) {
		this.name = name;
	}
}
