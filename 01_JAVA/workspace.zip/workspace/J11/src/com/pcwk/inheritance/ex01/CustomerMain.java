package com.pcwk.inheritance.ex01;

import java.util.Date;

public class CustomerMain {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.setCustomerID(10010);
		customer.setCustomerName("이순신");
		customer.bonusPoint = 1000;
		//이순신님의 등급은 Silver이며, 보너스 포인트는 1000입니다.
		System.out.println(customer.showCustomerInfo());
		
		Customer customerKim = new VIPCustomer(10020, "김유신", 12345);
		customerKim.bonusPoint = 1000;
		//김유신님의 등급은 VIP이며, 보너스 포인트는 1000입니다.
		System.out.println(customerKim.showCustomerInfo());
		
		System.out.println("=========할인율 보너스 포인트 계산=================");
		
		int price = 10_000;
		
		int leePrice = customer.calcPrice(price);
		int kimPrice = customerKim.calcPrice(price);
		
		System.out.println(customer.getCustomerName()+" 님이 "+leePrice+"원 지불 하셨습니다.");
		System.out.println(customer.showCustomerInfo());
		
		System.out.println(customerKim.getCustomerName()+" 님이 "+kimPrice+"원 지불 하셨습니다.");
		System.out.println(customerKim.showCustomerInfo());

	}

}
//이순신님의 등급은 Silver이며, 보너스 포인트는 1000입니다.
//김유신님의 등급은 VIP이며, 보너스 포인트는 1000입니다.
//=========할인율 보너스 포인트 계산=================
//이순신 님이 10000원 지불 하셨습니다.
//이순신님의 등급은 Silver이며, 보너스 포인트는 1100입니다.
//김유신 님이 9000원 지불 하셨습니다.
//김유신님의 등급은 VIP이며, 보너스 포인트는 1500입니다.
