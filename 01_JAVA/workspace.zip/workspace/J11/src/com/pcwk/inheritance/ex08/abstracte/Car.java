package com.pcwk.inheritance.ex08.abstracte;

public abstract class Car {

	public void run() {
		System.out.println("차가 달립니다.");
	}
	
	public abstract void refuell();
	
	public void stop() {
		System.out.println("차가 멈춤니다.");
	}
}
