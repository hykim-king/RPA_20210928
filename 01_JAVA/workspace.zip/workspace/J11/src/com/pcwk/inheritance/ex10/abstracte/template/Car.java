package com.pcwk.inheritance.ex10.abstracte.template;

public abstract class Car {

	public abstract void wipe();
	public abstract void drive();
	public abstract void stop();
	
	public void startCar() {
		System.out.println("시동을 켭니다.");
	}
	
	public void trunOff() {
		System.out.println("시동을 끕니다.");
	}
	
	
	//순서를 바꾸지 못하게
	//하위 클래스에서 재정의 금지!
	final public void run() {
		startCar();
		drive();
		wipe();
		stop();
		trunOff();
	}
	
}
