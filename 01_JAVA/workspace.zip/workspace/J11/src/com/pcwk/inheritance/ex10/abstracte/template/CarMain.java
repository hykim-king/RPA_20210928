package com.pcwk.inheritance.ex10.abstracte.template;

public class CarMain {

	public static void main(String[] args) {
		Car hisCar = new ManualCar();
		hisCar.run();
		System.out.println("==================");
		
		Car aiCar = new AICar();
		aiCar.run();
		
		
	}

}
//시동을 켭니다.
//사람이 운전 합니다.
//사람이 핸들을 조작 합니다.
//사람이 빠르기를 조절 합니다.
//브레이크로 정지 합니다.
//시동을 끕니다.
//==================
//시동을 켭니다.
//자율 주행을 합니다.
//자동차가 알아서 방향을 전환 합니다.
//비나 눈에 양에 따라 빠르기가 자동으로 조절됩니다.
//스스로 멈춥니다.
//시동을 끕니다.