package com.pcwk.inheritance.ex03;
import java.util.ArrayList;
//ctrl+shift+o :  import정리
//ctrl+shift+f :  소스정열
public class AnimalMain {
	//순서가 보장 된다.
	//
	ArrayList<Animal>  aniList=new ArrayList<>();
	
	public static void main(String[] args) {
		AnimalMain  aniMain=new AnimalMain();
		aniMain.addAnimal();
		System.out.println("=======================");
		aniMain.testCastring();
	}
	
	public void addAnimal() {
		aniList.add(new Human());
		aniList.add(new Eagle());
		aniList.add(new Tiger());
		
		for(Animal ani   :aniList) {
			ani.move();
		}
		
	}
	
	
	public void testCastring() {
		
		for(int i=0;i<aniList.size();i++) {
			Animal animal = aniList.get(i);
			
			//System.out.println(animal instanceof Human);
			if(animal instanceof Human) {
			
				Human h = (Human) animal;
				h.readBook();
			}else if(animal instanceof Eagle) {
				Eagle e = (Eagle)animal;
				e.flying();
			}else if(animal instanceof Tiger) {
				Tiger t = (Tiger) animal;
				t.hunting();
			}
			
		}
		
	}
	

}

//사람이 두 발로 걷습니다.
//독수리가 하늘을 납니다.
//호랑이가 네 발로 뜁니다.
//=======================
//사람이 책을 읽는다.
//독수리가 날개를 쭉 펴고 날아 갑니다.
//호랑이가 사냥을 합니다.







