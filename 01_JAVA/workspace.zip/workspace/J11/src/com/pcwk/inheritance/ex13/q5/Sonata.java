package com.pcwk.inheritance.ex13.q5;

public class Sonata extends Car {

	public Sonata() {
		super.productName ="Sonata";
	}
}
