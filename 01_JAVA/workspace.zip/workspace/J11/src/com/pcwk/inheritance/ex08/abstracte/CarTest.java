package com.pcwk.inheritance.ex08.abstracte;

public class CarTest {

	public static void main(String[] args) {
		Bus bus=new Bus();
		AutoCar  autoCar=new AutoCar();
		
		bus.run();
		autoCar.run();
		
		
		bus.refuell();
		autoCar.refuell();
		
		bus.takePassenger();
		autoCar.load();
		
		bus.stop();
		autoCar.stop();
	}

}
//버스가 달립니다.
//차가 달립니다.
//천연 가스를 주유 합니다.
//휘발류를 주유합니다.
//승객을 버스에 태웁니다.
//짐을 싣습니다.
//차가 멈춤니다.
//차가 멈춤니다.