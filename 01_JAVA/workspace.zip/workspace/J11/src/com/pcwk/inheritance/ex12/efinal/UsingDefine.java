package com.pcwk.inheritance.ex12.efinal;

public class UsingDefine {

	public static void main(String[] args) {
		System.out.println("Define.MAX:"+Define.MAX);
		
		System.out.println("Define.MIN:"+Define.MIN);
		System.out.println("Define.PI:"+Define.PI);
		System.out.println("Define.GOOD_MORNING:"+Define.GOOD_MORNING);
		
		//String
		
	}

}
