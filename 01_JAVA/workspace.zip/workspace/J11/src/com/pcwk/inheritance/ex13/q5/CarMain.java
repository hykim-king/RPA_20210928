package com.pcwk.inheritance.ex13.q5;

import java.util.ArrayList;

public class CarMain {

	public static void main(String[] args) {
		ArrayList<Car> carList=new ArrayList<>();
		carList.add(new Sonata());
		carList.add(new Grandeur());
		for(Car c :carList) {
			c.run();
			System.out.println("============================");
		}

	}

}
