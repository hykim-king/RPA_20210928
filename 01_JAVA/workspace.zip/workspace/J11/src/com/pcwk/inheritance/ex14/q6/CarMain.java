package com.pcwk.inheritance.ex14.q6;

import java.util.ArrayList;

public class CarMain {

	public static void main(String[] args) {
		ArrayList<Car> carList=new ArrayList<>();
		carList.add(new Sonata());
		carList.add(new Grandeur());
		carList.add(new Avante());
		carList.add(new Genesis());
		for(Car c :carList) {
			c.run();
			System.out.println("============================");
		}

	}

}
//Sonata 시동을 켭니다.
//Sonata 달립 니다.
//Sonata 멈춤니다.
//Sonata 시동을 끕니다.
//세차를 합니다.
//============================
//Grandeur 시동을 켭니다.
//Grandeur 달립 니다.
//Grandeur 멈춤니다.
//Grandeur 시동을 끕니다.
//세차를 합니다.
//============================
//Avante 시동을 켭니다.
//Avante 달립 니다.
//Avante 멈춤니다.
//Avante 시동을 끕니다.
//세차를 합니다.
//============================
//Genesis 시동을 켭니다.
//Genesis 달립 니다.
//Genesis 멈춤니다.
//Genesis 시동을 끕니다.
//세차를 합니다.
//============================