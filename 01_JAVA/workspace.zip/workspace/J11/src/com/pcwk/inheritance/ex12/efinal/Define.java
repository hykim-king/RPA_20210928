package com.pcwk.inheritance.ex12.efinal;

public class Define {
	//공유 상수.
	
	public static final int MIN = 1;
	public static final int MAX = 99999;
	
	public static final double PI = 3.14;
	public static final String GOOD_MORNING = "Good Morning";
}
