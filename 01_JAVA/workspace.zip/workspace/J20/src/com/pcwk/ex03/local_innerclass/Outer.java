package com.pcwk.ex03.local_innerclass;

import com.pcwk.cmn.Common;

public class Outer implements Common {

	int outNum = 100;
	static int sNum = 200;
	
	/**
	 * 메서드 내에 클래스가 있음.
	 * @param i
	 * @return Runnable
	 */
	Runnable  getRunnable(int i) {
		int num = 100;  //지역변수
		
		class MyRunnable implements Runnable{
            int localNum = 10;//로컬 내부 인스턴스 변수
            
			@Override
			public void run() {
				//Local variable num defined in an enclosing scope must be final or effectively final
				//num = 200; 상수로 변경되어 값을 변경할수 없음.
				//i = 99;    상수로 변경되어 값을 변경할수 없음.
				LOG.debug("i="+i);
				LOG.debug("num="+num);
				LOG.debug("localNum="+localNum);
				LOG.debug("outNum="+outNum+" (외부 클래스의 인스턴스 변수 변수)");
				LOG.debug("sNum="+sNum+" (외부 클래스의 정적 변수)");
			}
			
		}
		
		
		return new MyRunnable();
	}
	
}
