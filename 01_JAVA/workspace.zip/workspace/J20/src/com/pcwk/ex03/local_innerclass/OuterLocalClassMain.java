package com.pcwk.ex03.local_innerclass;

import com.pcwk.cmn.Common;

public class OuterLocalClassMain implements Common {

	public static void main(String[] args) {
		Outer outer=new Outer();
		
		Runnable runner = outer.getRunnable(10);
		runner.run();
	}

}
//2021-10-28 10:24:43,826 DEBUG [main] cmn.Common        (   Outer.java:26)     - i=10
//2021-10-28 10:24:43,832 DEBUG [main] cmn.Common        (   Outer.java:27)     - num=100
//2021-10-28 10:24:43,832 DEBUG [main] cmn.Common        (   Outer.java:28)     - localNum=10
//2021-10-28 10:24:43,832 DEBUG [main] cmn.Common        (   Outer.java:29)     - outNum=100 (외부 클래스의 인스턴스 변수 변수)
//2021-10-28 10:24:43,832 DEBUG [main] cmn.Common        (   Outer.java:30)     - sNum=200 (외부 클래스의 정적 변수)