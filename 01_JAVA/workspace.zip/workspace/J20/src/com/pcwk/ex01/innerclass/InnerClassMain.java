package com.pcwk.ex01.innerclass;

import com.pcwk.cmn.Common;

public class InnerClassMain implements Common {

	public static void main(String[] args) {
		OuterClass outerClass=new OuterClass();

		LOG.debug("외부 클래스를 이용하여 내부 클래스 기능 호출");
		outerClass.usingClass();
		//인스턴스 내부클래스 생성.
		LOG.debug("=============================");
		OuterClass outerClass02=new OuterClass();
		
		OuterClass.InClass inClass= outerClass02.new InClass();
		inClass.inTest();
	}

}
