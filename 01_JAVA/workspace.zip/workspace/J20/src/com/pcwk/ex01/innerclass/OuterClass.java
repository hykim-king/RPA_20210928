package com.pcwk.ex01.innerclass;

import com.pcwk.cmn.Common;

public class OuterClass implements Common {

	private int num = 10; // 외부클래스 멤버변수
	private static int sNum = 20;// 외부클래스 정적변수
	private InClass inClass; // 내부클래스 자료형 변수 선언

	public OuterClass() {
		inClass = new InClass();// 외부 클래스 디폴트 생성자,
								// 외부 클래스가 생성된 후 내부 클래스 생성가능
	}

	class InClass { // 인스턴스 내부 클래스
		int inNum = 100;
		// static int sInNum = 200;//인스턴스 내부 클래스에 정적 변수 선언 불가.

		void inTest() {
			LOG.debug("OutClass num " + num + " (외부 클래스의 인스턴스 변수)");
			LOG.debug("OutClass sNum " + sNum + " (외부 클래스의 정적 변수)");
		}
	}

	public void usingClass() {
		inClass.inTest();
	}

}
