package com.pcwk.ex05.lambda;

@FunctionalInterface
public interface MyNumber {

	int getMax(int num1, int num2);
	//Invalid '@FunctionalInterface' annotation; MyNumber is not a functional interface
	//int add(int num1, int num2);
}
