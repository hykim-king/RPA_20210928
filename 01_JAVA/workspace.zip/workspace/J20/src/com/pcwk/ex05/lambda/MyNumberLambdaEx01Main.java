package com.pcwk.ex05.lambda;

import com.pcwk.cmn.Common;

public class MyNumberLambdaEx01Main implements Common {

	public static void main(String[] args) {
		
		MyNumber max = (x,y)->(x>=y)?x:y;//람다식을 인터페이스형 max변수에 대입
		
		LOG.debug(max.getMax(10, 20));//인터페이스형 변수로 메서드 호출

	}

}
//2021-10-28 11:28:06,387 DEBUG [main] cmn.Common        (MyNumberLambdaEx01Main.java:11)     - 20
