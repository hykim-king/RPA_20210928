package com.pcwk.ex07.lambda;

public interface PrintString {
	void showString(String str);
}
