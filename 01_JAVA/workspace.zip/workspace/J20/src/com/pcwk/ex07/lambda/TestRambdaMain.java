package com.pcwk.ex07.lambda;

import com.pcwk.cmn.Common;

public class TestRambdaMain implements Common {

	public static void main(String[] args) {
		//람다식을 인터페이스형 변수에 대입
		PrintString lambda = s -> System.out.println(s);
		//변수를 사용해 람다식 호출
		lambda.showString("hello lambda-1");
		
		showMyString(lambda);
		System.out.println("반환 값으로 쓰이는 람다식");
		System.out.println("====================");
		PrintString  strString = returnString();
		strString.showString("즐거운 목요일 ");
	}

	
	//매개변수를 인터페이스형으로 받음
	public static void showMyString(PrintString p) {
		p.showString("hello lambda-2");
	}
	
	
	//반환 값으로 쓰이는 람다식
	public static PrintString returnString() {
		//PrintString lam=s -> System.out.println(s);
		
		return s -> System.out.println(s);
	}
}
//hello lambda-1
//hello lambda-2
//반환 값으로 쓰이는 람다식
//====================
//즐거운 목요일 