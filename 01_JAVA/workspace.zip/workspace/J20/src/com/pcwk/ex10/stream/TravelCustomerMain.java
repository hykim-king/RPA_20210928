package com.pcwk.ex10.stream;

import java.util.ArrayList;
import java.util.List;

import com.pcwk.cmn.Common;

public class TravelCustomerMain implements Common {

	public static void main(String[] args) {
		TravelCustomer t01=new TravelCustomer("이순신", 40, 100);
		TravelCustomer t02=new TravelCustomer("김유신", 20, 100);
		TravelCustomer t03=new TravelCustomer("홍길동", 13,  50);
		
		List<TravelCustomer> cusList=new ArrayList<>();
		cusList.add(t01);
		cusList.add(t02);
		cusList.add(t03);
		
		LOG.debug("고객명단");
		LOG.debug("========================");
		cusList.stream().map(c->c.getName()).forEach(s->LOG.debug(s));
		LOG.debug("------------------------");
		
		
		int total = cusList.stream().mapToInt(c->c.getPrice()).sum();
		LOG.debug("총여행 비용: "+total);
		
		LOG.debug("20이상 고객명단을 정렬 출력");
		LOG.debug("========================");
		cusList.stream().filter(c->c.getAge()>=20).map(c->c.getName()).sorted().forEach(s->LOG.debug(s));
		LOG.debug("------------------------");
	}

}
//2021-10-28 15:22:02,637 DEBUG [main] cmn.Common        (TravelCustomerMain.java:20)     - 고객명단
//2021-10-28 15:22:02,644 DEBUG [main] cmn.Common        (TravelCustomerMain.java:21)     - ========================
//2021-10-28 15:22:02,840 DEBUG [main] cmn.Common        (TravelCustomerMain.java:22)     - 이순신
//2021-10-28 15:22:02,847 DEBUG [main] cmn.Common        (TravelCustomerMain.java:22)     - 김유신
//2021-10-28 15:22:02,848 DEBUG [main] cmn.Common        (TravelCustomerMain.java:22)     - 홍길동
//2021-10-28 15:22:02,848 DEBUG [main] cmn.Common        (TravelCustomerMain.java:23)     - ------------------------
//2021-10-28 15:22:02,854 DEBUG [main] cmn.Common        (TravelCustomerMain.java:27)     - 총여행 비용: 250
//2021-10-28 15:22:02,854 DEBUG [main] cmn.Common        (TravelCustomerMain.java:29)     - 20이상 고객명단을 정렬 출력
//2021-10-28 15:22:02,854 DEBUG [main] cmn.Common        (TravelCustomerMain.java:30)     - ========================
//2021-10-28 15:22:02,877 DEBUG [main] cmn.Common        (TravelCustomerMain.java:31)     - 김유신
//2021-10-28 15:22:02,877 DEBUG [main] cmn.Common        (TravelCustomerMain.java:31)     - 이순신
//2021-10-28 15:22:02,877 DEBUG [main] cmn.Common        (TravelCustomerMain.java:32)     - ------------------------