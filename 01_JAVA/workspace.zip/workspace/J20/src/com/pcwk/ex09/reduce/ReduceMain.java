package com.pcwk.ex09.reduce;

import com.pcwk.cmn.Common;
import java.util.*;

public class ReduceMain implements Common {

	public static void main(String[] args) {
		String [] greeting= { "안녕하세요. 오~오~", "hello","Good Morning","반값습니다."  };																							

		String str = Arrays.stream(greeting).reduce(new CompareString()).get();
		LOG.debug("문자열이 가장긴 스트링:"+str);
		
		//람다식을 직접 구현하는 방법
		
		String str02 = Arrays.stream(greeting).reduce("",(s1,s2)->{
			if(s1.getBytes().length >= s2.getBytes().length)return s1;
			else return s2;
		});
		
		LOG.debug("문자열이 가장긴 스트링:"+str02);
	}

}
//2021-10-28 14:47:25,421 DEBUG [main] cmn.Common        (ReduceMain.java:12)     - 문자열이 가장긴 스트링:안녕하세요. 오~오~
//2021-10-28 14:47:25,626 DEBUG [main] cmn.Common        (ReduceMain.java:21)     - 문자열이 가장긴 스트링:안녕하세요. 오~오~