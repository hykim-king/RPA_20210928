package com.pcwk.ex04.anony_innerclass;

import com.pcwk.cmn.Common;

public class OuterAnoniClassMain implements Common {

	public static void main(String[] args) {
		Outer outer=new Outer();
		
		Runnable runnable = outer.getRunnable(10);
		runnable.run();
	}

}
//2021-10-28 10:42:33,193 DEBUG [main] cmn.Common        (   Outer.java:25)     - i=10
//2021-10-28 10:42:33,198 DEBUG [main] cmn.Common        (   Outer.java:26)     - num=100
//2021-10-28 10:42:33,198 DEBUG [main] cmn.Common        (   Outer.java:27)     - localNum=10
//2021-10-28 10:42:33,199 DEBUG [main] cmn.Common        (   Outer.java:28)     - outNum=100 (외부 클래스의 인스턴스 변수 변수)
//2021-10-28 10:42:33,199 DEBUG [main] cmn.Common        (   Outer.java:29)     - sNum=200 (외부 클래스의 정적 변수)
