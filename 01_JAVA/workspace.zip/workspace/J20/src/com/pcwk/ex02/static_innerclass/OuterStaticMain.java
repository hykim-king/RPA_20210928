package com.pcwk.ex02.static_innerclass;

import com.pcwk.cmn.Common;

public class OuterStaticMain implements Common {

	public static void main(String[] args) {
		//정적 내부 클래스 일반메서드
		LOG.debug("정적 내부 클래스 일반메서 call");
		OuterClass.InStaticClass  sInClass=new OuterClass.InStaticClass();
		sInClass.inTest();
		LOG.debug("정적 내부 클래스 정적 메서드 call");
		//정적 내부 클래스 정적 메서드 call
		OuterClass.InStaticClass.sTest();
	}

}
