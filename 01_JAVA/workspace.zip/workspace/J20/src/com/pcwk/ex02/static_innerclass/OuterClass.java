package com.pcwk.ex02.static_innerclass;

import com.pcwk.cmn.Common;

public class OuterClass implements Common {

	
	private int num =10;         //외부 인스턴스 변수
	private static int sNum = 20;//외부 정적 변수
	
	
	static class InStaticClass{ //정적 내부 클래스
		int inNum = 100;         //정적 내부 클래스에 인스턴스 변수
		static int sInNum = 200; //정적 내부 클래스에 정적 변수
		
		//일반 메서드
		void inTest() {
			//Cannot make a static reference to the non-static field num
			//num +=10;
			
			LOG.debug("InStaticClass inNUm "+inNum+" (내부 클래스의 인스턴스 변수)");
			LOG.debug("InStaticClass sInNum "+sInNum+" (내부 클래스의 정적 변수)");
			LOG.debug("OuterClass sNum "+sNum+" (외부 클래스의 정적 변수)");
		}
		
		//정적 메서드
		static void sTest() {
			//Cannot make a static reference to the non-static field num
			//num +=10;
			//Cannot make a static reference to the non-static field inNum
			//inNum +=20;
			
			LOG.debug("InStaticClass sInNum "+sInNum+" (내부 클래스의 정적 변수)");
			LOG.debug("OuterClass sNum "+sNum+" (외부 클래스의 정적 변수)");			
			
		}
		
	}
}
