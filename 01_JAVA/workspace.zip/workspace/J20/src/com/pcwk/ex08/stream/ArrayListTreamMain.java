package com.pcwk.ex08.stream;

import com.pcwk.cmn.Common;
import java.util.*;
import java.util.stream.Stream;


public class ArrayListTreamMain implements Common {

	public static void main(String[] args) {
		List<String> sList=new ArrayList<>();
		
		sList.add("Tomas");
		sList.add("Edward");
		sList.add("Jack");
		
		Stream<String> listStream =sList.stream();
		
		//List내용 모두 출력
		listStream.forEach(s->LOG.debug(s));

		LOG.debug("=============================");
		sList.stream().sorted().forEach(s->LOG.debug(s));
	}

}
//2021-10-28 14:29:09,354 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:20)     - Tomas
//2021-10-28 14:29:09,358 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:20)     - Edward
//2021-10-28 14:29:09,359 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:20)     - Jack
//2021-10-28 14:29:09,359 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:22)     - =============================
//2021-10-28 14:29:09,378 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:23)     - Edward
//2021-10-28 14:29:09,378 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:23)     - Jack
//2021-10-28 14:29:09,378 DEBUG [main] cmn.Common        (ArrayListTreamMain.java:23)     - Tomas
