package com.pcwk.ex08.stream;

import com.pcwk.cmn.Common;
import java.util.Arrays;


public class InArraysMain implements Common {

	public static void main(String[] args) {
		
		int [] arr = {1,2,3,4,5};
		
		long count = Arrays.stream(arr).count();
		
		int  sum   = Arrays.stream(arr).sum();
		
		LOG.debug("배열 건수:"+count);
		LOG.debug("배열 함:"+sum);
		
		
	}

}
//2021-10-28 14:19:17,899 DEBUG [main] cmn.Common        (InArraysMain.java:17)     - 배열 건수:5
//2021-10-28 14:19:17,904 DEBUG [main] cmn.Common        (InArraysMain.java:18)     - 배열 함:15
