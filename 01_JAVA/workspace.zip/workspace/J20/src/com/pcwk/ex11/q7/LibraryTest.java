package com.pcwk.ex11.q7;

import java.util.ArrayList;
import java.util.List;

import com.pcwk.cmn.Common;

public class LibraryTest  implements Common{

	public static void main(String[] args) {
		List<Book>  bookList=new ArrayList<>();
		
		
		bookList.add(new Book("자바",25_000));
		bookList.add(new Book("파이썬",15_000));
		bookList.add(new Book("안드로이드",30_000));

		
		//모든 책의 가격의 합
		int total = bookList.stream().mapToInt(b->b.getPrice()).sum();
		LOG.debug("모든 책의 가격의 합: "+total);
		
		//책의 가격이 20,000이상인 책의 이름을 정렬하여 출력
		LOG.debug("책의 가격이 20,000이상인 책의 이름을 정렬하여 출력: ");
		LOG.debug("=========================================");
		bookList.stream().filter(b->b.getPrice()>=20_000).map(bk->bk.getName()).sorted().forEach(s->LOG.debug(s));
	}

}
//2021-10-28 16:17:08,896 DEBUG [main] cmn.Common        (LibraryTest.java:21)     - 모든 책의 가격의 합: 70000
//2021-10-28 16:17:08,901 DEBUG [main] cmn.Common        (LibraryTest.java:24)     - 책의 가격이 20,000이상인 책의 이름을 정렬하여 출력: 
//2021-10-28 16:17:08,901 DEBUG [main] cmn.Common        (LibraryTest.java:25)     - =========================================
//2021-10-28 16:17:08,934 DEBUG [main] cmn.Common        (LibraryTest.java:26)     - 안드로이드
//2021-10-28 16:17:08,938 DEBUG [main] cmn.Common        (LibraryTest.java:26)     - 자바