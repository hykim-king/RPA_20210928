package com.pcwk.ex11.q5;

import com.pcwk.cmn.Common;

public class CalcMain implements Common {

	public static void main(String[] args) {
		Calc cal = (n1,n2)-> n1+n2;
		
		LOG.debug(cal.add(10, 12));

	}

}
//2021-10-28 15:36:13,608 DEBUG [main] cmn.Common        (CalcMain.java:10)     - 22