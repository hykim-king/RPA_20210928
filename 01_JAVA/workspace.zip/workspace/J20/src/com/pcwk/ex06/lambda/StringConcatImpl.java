package com.pcwk.ex06.lambda;

import com.pcwk.cmn.Common;

public class StringConcatImpl implements StringConcat, Common {

	@Override
	public void makeString(String s1, String s2) {
		LOG.debug(s1+","+s2);
	}

}
