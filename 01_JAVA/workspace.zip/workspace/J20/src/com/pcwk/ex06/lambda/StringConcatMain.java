package com.pcwk.ex06.lambda;

public class StringConcatMain {

	public static void main(String[] args) {
		StringConcat concat=new StringConcatImpl();
		concat.makeString("즐거운", " 점심 시간입니다.");		

	}

}
