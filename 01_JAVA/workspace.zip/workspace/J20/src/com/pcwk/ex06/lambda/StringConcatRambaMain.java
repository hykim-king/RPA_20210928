package com.pcwk.ex06.lambda;

import com.pcwk.cmn.Common;

public class StringConcatRambaMain implements Common {

	public static void main(String[] args) {
		String s1= "점심 ";
		String s2= "맛나게 드세요.";
		StringConcat  concat2= (s,v) -> LOG.debug(s+","+v);
		
		concat2.makeString(s1, s2);
		
		

	}

}
