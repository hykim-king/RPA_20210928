package com.pcwk.ex05;

public class Member {
	private int memberId;     // 회원ID
	private String memberName;// 회원이름
	
	
	public Member(int memberId, String memberName) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
	}


	public int getMemberId() {
		return memberId;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + "]";
	}
	
	
	
	
	

}
