package com.pcwk.ex03.generics;

public abstract class Material {

	//추상 메서드
	public abstract void doPrinting();
}
