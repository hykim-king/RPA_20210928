package com.pcwk.ex03.generics;

//T 자료형은 Material을 상속받은 클래스만 올수 있음.
public class GenericPrinter<T extends Material> {

	private T material;

	public T getMaterial() {
		return material;
	}

	public void setMaterial(T material) {
		this.material = material;
	}
	
	@Override
	public String toString() {
		return material.toString();
	}
}
