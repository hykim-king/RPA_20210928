package com.pcwk.ex03.generics;

public class GenericPrinterMain {

	public static void main(String[] args) {
		//Powder type으로 GenericPrinter 생성
		GenericPrinter<Powder>  powderPrinter=new GenericPrinter<Powder>();		

		//setMaterial(T) Powder로 대처
		powderPrinter.setMaterial(new Powder());		
		Powder powder = powderPrinter.getMaterial();
		
		System.out.println(powderPrinter);
		
		
		GenericPrinter<Plastic>  plasticPrinter=new GenericPrinter<>();
		plasticPrinter.setMaterial(new Plastic());
		
		Plastic plastic = plasticPrinter.getMaterial();
		System.out.println(plasticPrinter);
	}

}
//재료는 Powder입니다.
//재료는 Plastic 입니다.