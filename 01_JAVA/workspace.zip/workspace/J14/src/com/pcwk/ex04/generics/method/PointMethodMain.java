package com.pcwk.ex04.generics.method;

import java.util.ArrayList;
import java.util.Collection;

public class PointMethodMain {

	//public <자료형 매개변수> 리턴형  메서드이름(자료형 매개변수,…){																		
	public static <T,V> double makeRectangle(Point<T,V> p1, Point<T,V> p2) {
		double result =0.0;
		//width(p2.x - p1.x  )
		
		//height(p2.y - p1.y)
		double width = ((Number)p2.getX()).doubleValue() - ((Number)p1.getX()).doubleValue();
		double height= ((Number)p2.getY()).doubleValue() - ((Number)p1.getY()).doubleValue();
		
		result = width * height;
		
		return result;
	}
	
	public static void main(String[] args) {
		Point<Integer,Double>  p1=new Point<Integer, Double>(0, 0.0);
		Point<Integer,Double>  p2=new Point<Integer, Double>(10, 10.0);
		
		double rect = PointMethodMain.makeRectangle(p1, p2);
		System.out.println("두 점으로 만들어진 사각형의 넓이는 "+rect+" 입니다.");
		
		ArrayList<String>  list=new ArrayList<>();
		String str=new String("abc");
		list.add(str);
		
		String s = list.get(0);
		

	}

}
//두 점으로 만들어진 사각형의 넓이는 100.0 입니다.