package com.pcwk.ex06.alone;
import java.util.ArrayList;
import com.pcwk.ex05.Member;

public class MemberArrayList {

	private ArrayList<Member>  arrayList;
	
	public MemberArrayList() {
		arrayList = new ArrayList<>();
	}
	
	/**
	 * 특정 위치에 추가 
	 * @param member
	 * @param index
	 */
	public void insertMember(Member member, int index) {
		this.arrayList.add(index, member);
	}
	
	
	/**
	 * 학생 추가
	 * @param member
	 */
	public void addMember(Member member) {
		boolean flag = this.arrayList.add(member);
		System.out.println("addMember : falg="+flag);
	}

	/**
	 * 학생정보 삭제
	 * @param memberId
	 * @return boolean
	 */
	public boolean removeMember(int memberId) {
		boolean flag = false;

		for(int i=0;i<arrayList.size();i++) {
			Member mem=arrayList.get(i);
			
			//동일한 memberId가 있으면
			if(memberId == mem.getMemberId()) {
				arrayList.remove(i);
				flag = true;
			}
		}
		
		if(flag==true) {
			System.out.println(memberId+" 회원이 삭제되었습니다.");
		}else {
			System.out.println(memberId+" 회원이 없습니다..");
		}
		
		
		return flag;
	}
	
	/**
	 * 회원정보 출력
	 */
	public void showAllMember() {
		//배열에 담을수 있는 크기

		//향상된 for
		for(Member m :arrayList) {
			System.out.println(m.toString());
		}
		System.out.println("----------------------");
		
	}
	
	
}












