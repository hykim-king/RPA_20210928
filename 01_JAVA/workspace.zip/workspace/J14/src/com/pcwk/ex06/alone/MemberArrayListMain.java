package com.pcwk.ex06.alone;

import com.pcwk.ex05.Member;

public class MemberArrayListMain {

	public static void main(String[] args) {
		MemberArrayList  memberArrayList=new MemberArrayList();
		
		Member member01 =new Member(1,"오일남");
		Member member02 =new Member(67,"강새벽");
		
		Member member03 =new Member(218,"조상후");
		Member member04 =new Member(456,"성기훈");
		
		memberArrayList.addMember(member01);
		memberArrayList.addMember(member02);
		memberArrayList.addMember(member03);
		memberArrayList.addMember(member04);
		
		Member member05 =new Member(101,"장덕수");
		memberArrayList.insertMember(member05, 2);
		
		//인원 전체 출력
		memberArrayList.showAllMember();	
	}

}
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=101, memberName=장덕수]
//Member [memberId=218, memberName=조상후]
//Member [memberId=456, memberName=성기훈]