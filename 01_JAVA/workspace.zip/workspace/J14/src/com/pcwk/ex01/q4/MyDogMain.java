package com.pcwk.ex01.q4;

public class MyDogMain {

	public static void main(String[] args) {
		MyDog dog=new MyDog("멍멍이","진돗개");
		
		System.out.println(dog);
		//진돗개 멍멍이

	}

}
