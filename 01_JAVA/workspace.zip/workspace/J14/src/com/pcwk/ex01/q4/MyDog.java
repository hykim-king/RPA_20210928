package com.pcwk.ex01.q4;

public class MyDog {
	String name;//이름
	String type;//종
	
	public MyDog(String name, String type) {
		super();
		this.name = name;
		this.type = type;
	}
	
	@Override
	public String toString() {
		return type + " " + name ;
	}
	
	
}
