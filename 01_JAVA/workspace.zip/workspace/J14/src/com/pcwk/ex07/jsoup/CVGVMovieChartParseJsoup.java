package com.pcwk.ex07.jsoup;

import java.io.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class CVGVMovieChartParseJsoup {

	public static void main(String[] args) {
		String url = "http://www.cgv.co.kr/movies/";
		
		try {
			//cgv 선택 webpage
			Document  doc = Jsoup.connect(url).get();
			
			//System.out.println(doc);
			//html tag 구분자는 space
			//html css 구분자는 .
			
			//제목
			Elements titles = doc.select("div.box-contents strong.title");			
			
			//예매율
			Elements reservRations = doc.select("div.score strong.percent span");
			
			//개봉일
			Elements openDays = doc.select("span.txt-info strong");
			
			//포스터
			Elements posters = doc.select("span.thumb-image img");
			
			
			for(int i=0;i<7;i++) {
				Element titleElement = titles.get(i);//html 태크중 한게
				Element reservElement =  reservRations.get(i);
				Element openDayElement = openDays.get(i);
				
				//속성읽기
				String posterImg = posters.get(i).attr("src");
				
				
				System.out.println((i+1)+". "+titleElement.text()
				+", 예매율:"+reservElement.text()
				+", 개봉일:"+openDayElement.text()
				+", 포스터:"+posterImg
						);
			}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
//1. 듄, 예매율:67.0%, 개봉일:2021.10.20 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84945/84945_320.jpg
//2. 베놈 2-렛 데어 비 카니지, 예매율:15.4%, 개봉일:2021.10.13 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84690/84690_320.jpg
//3. 라스트 듀얼-최후의 결투, 예매율:9.2%, 개봉일:2021.10.20 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84838/84838_320.jpg
//4. 007 노 타임 투 다이, 예매율:1.1%, 개봉일:2021.09.29 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000083/83003/83003_320.jpg
//5. 십개월의 미래, 예매율:0.6%, 개봉일:2021.10.14 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85001/85001_320.jpg
//6. 보이스, 예매율:0.5%, 개봉일:2021.09.15 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84872/84872_320.jpg
//7. 첫눈이 사라졌다, 예매율:0.4%, 개봉일:2021.10.20 개봉, 포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84908/84908_320.jpg