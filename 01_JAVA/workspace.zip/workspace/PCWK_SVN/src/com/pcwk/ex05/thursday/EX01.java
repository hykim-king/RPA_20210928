package com.pcwk.ex05.thursday;

public class EX01 {

	public static void main(String[] args) {
		
		System.out.println("오늘은 10월 28일 목요일 입니다");

		System.out.println("지금은 1시 4분 입니다");
		
		System.out.println("ㅇㅇ");
		
		System.out.println("김도형 제작");
		
	}

}
