package com.pcwk.ex02;

public class Abc {

	public static void main(String[] args) {
		System.out.println("백슉먹자해짜나!");

	}

}
