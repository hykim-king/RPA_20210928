package com.pcwk.ex02;

public class HelloWorld3 {

	public static void main(String[] args) {
		System.out.println("지수씨 비밀번호 : jisu229");
		System.out.println("불조심 해킹조심");//by.승우
		System.out.println("네트워크 연결");
	}

}
