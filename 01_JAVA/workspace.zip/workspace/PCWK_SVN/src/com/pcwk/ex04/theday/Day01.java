package com.pcwk.ex04.theday;

public class Day01 {

		public static void main(String[] args) {
			
			String fnt = "Tuesday";
			String bck = "Alone";
			
			System.out.println(fnt+' '+bck);

			String friend ="You are not alone.";
			System.out.println(friend);
			System.out.println(friend);
			
			String frnd2 = "다들 책 가지러 나오세요";
			System.out.println(frnd2);
			
		}

	}