package com.pcwk.kdhEX01;

public class Test01 {

	
	
	public int add(int num01, int num02) {
		return num01 + num02;
	}
}
