package com.pcwk.kdhEX01;

public class TestMain {
	static int num01 = (int) (Math.random()*10);
	static int num02 = (int) (Math.random()*10);
	static int num03 = (int) (Math.random()*10);
	static int num04 = (int) (Math.random()*10);
	
	public static void main(String[] args) {
		Test01 test01 = new Test01();
		System.out.println(num01);
		System.out.println(num02);
		System.out.println(test01.add(num01, num02));
	}
	


}
