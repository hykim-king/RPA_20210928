package com.pcwk.ex03.date1025;

public class DoYouLikeMintChoco {

	public static void main(String[] args) {
		System.out.println("Hell No");
		
		System.out.println("I Luv MintChoco"); //sj

	}

}
