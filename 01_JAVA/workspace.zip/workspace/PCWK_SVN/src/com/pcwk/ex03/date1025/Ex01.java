package com.pcwk.ex03.date1025;

public class Ex01 {

	public static void main(String[] args) {
		System.out.println("Hi");

	}

}
