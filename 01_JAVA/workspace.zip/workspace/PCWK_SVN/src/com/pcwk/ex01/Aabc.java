package com.pcwk.ex01;

public class Aabc {

	public static void main(String[] args) {
		System.out.println("Hey");

	}

}
