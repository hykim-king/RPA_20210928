package com.pcwk.ex01;

public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello, world!");//강사 작성
		System.out.println("Hello, world!");//지수씨 자리
		System.out.println("Hello, New world!");//승우씨 자리
		System.out.println("Bye!");
		System.out.println("Hello, world!");//강사 작성2

	}

}
