package com.pcwk.ex01;

public class FirstFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
