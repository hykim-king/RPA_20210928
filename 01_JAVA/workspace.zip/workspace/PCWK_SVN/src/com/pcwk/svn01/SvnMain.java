package com.pcwk.svn01;

public class SvnMain {

	public static void main(String[] args) {
		System.out.println("dfsjlkfds;f");
		
		//알겠습ㄴ니다
		//힘내세요
		//식사맛나게 하세요
		//저녁말씀하시는건가요? - gyu
		//네 저녁으로 민트초코 드세요
	}

}
