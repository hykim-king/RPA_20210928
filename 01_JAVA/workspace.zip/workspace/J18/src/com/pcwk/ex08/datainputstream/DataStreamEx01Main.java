package com.pcwk.ex08.datainputstream;

import java.io.*;
import org.apache.log4j.*;

public class DataStreamEx01Main {

	public final static Logger LOG = Logger.getLogger(DataStreamEx01Main.class);

	public static void main(String[] args) {
        //데이터 기록
		try (FileOutputStream fos = new FileOutputStream("data.txt");
				DataOutputStream dos = new DataOutputStream(fos);) {
			dos.writeByte(100);
			dos.writeChar('A');
			dos.writeInt(10);
			dos.writeFloat(3.14f);
			dos.writeUTF("Test");
			
		} catch (IOException e) {
			LOG.debug("===================");
			LOG.debug(e);
			LOG.debug("===================");
		}

		//데이터 읽기
		try (FileInputStream fis = new FileInputStream("data.txt");
				DataInputStream dis = new DataInputStream(fis);) {
			LOG.debug(dis.readByte());
			LOG.debug(dis.readChar());
			LOG.debug(dis.readInt());
			LOG.debug(dis.readFloat());
			LOG.debug(dis.readUTF());

			
		} catch (IOException e) {
			LOG.debug("===================");
			LOG.debug(e);
			LOG.debug("===================");
		}		
		
		
		
		LOG.debug("완료");
	}

}
//2021-10-26 15:34:29,283 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:29)     - 100
//2021-10-26 15:34:29,289 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:30)     - A
//2021-10-26 15:34:29,289 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:31)     - 10
//2021-10-26 15:34:29,289 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:32)     - 3.14
//2021-10-26 15:34:29,294 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:33)     - Test
//2021-10-26 15:34:29,294 DEBUG [main] datainputstream.DataStreamEx01Main (DataStreamEx01Main.java:44)     - 완료