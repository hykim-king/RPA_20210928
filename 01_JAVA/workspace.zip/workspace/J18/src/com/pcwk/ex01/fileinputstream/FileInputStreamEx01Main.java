package com.pcwk.ex01.fileinputstream;
import java.io.*;

import org.apache.log4j.Logger;

public class FileInputStreamEx01Main {

	public final static Logger LOG = Logger.getLogger(FileInputStreamEx01Main.class);
	
	public static void main(String[] args) {
		//String filePath ="D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex01\\fileinputstream\\input.txt";
        //String fileP ="D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex01\\fileinputstream\\FileInputStreamEx01Main.java";
		String filePath = args[0];
		String filePath01 = args[1];
		LOG.debug("String filePath ="+filePath);
		LOG.debug("String filePath01 ="+filePath01);
		//try~with~resource: finally에서 자원반납 필요 없음.
		try(FileInputStream fis=new FileInputStream(filePath)) {
			byte[] bs=new byte[10];
			int i = 0;
			while( (i=fis.read(bs)) !=-1) {
				for(byte b :bs) {
					System.out.print((char)b);
				}
				System.out.println(": "+i+"바이트 읽음");
			}
			
		}catch(IOException e) {
			LOG.debug(e);
		}
		
		System.out.println("end");

	}

}
//ABCDEFGHIJ: 10바이트 읽음
//KLMNOPQRST: 10바이트 읽음
//UVWXYZQRST: 6바이트 읽음
//end