package com.pcwk.ex01.fileinputstream;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

//ctrl+shift+o : import정리
//ctrl+shift+f : source정렬
public class FileOutputStreamEx01Main {
	final static Logger LOG = Logger.getLogger(FileOutputStreamEx01Main.class);

	public static void main(String[] args) {
		// try~with~resource: finally에서 자원반납 필요 없음.
		// try(FileOutputStream fos=new FileOutputStream("output.txt")) {

		// 파일에 내용 붙여가기
		try (FileOutputStream fos = new FileOutputStream("output.txt", true)) {
			// 아스키코드로 기록을 하면 아스크문자로 변환되어 기록
			fos.write(97);
			fos.write(98);
			fos.write(99);

		} catch (IOException e) {
			LOG.debug("===============================");
			LOG.debug(e.getMessage());
			LOG.debug("===============================");
		}

		LOG.debug("종료");

	}

}
