package com.pcwk.ex09.serialization;

import java.io.*;
import org.apache.log4j.*;

public class PersonSerializationMain {

	public static void main(String[] args) {

		Person person01 = new Person("홍길동", "대빵");
		Person person02 = new Person("이상무", "상무");
		// 객체 직열화
		try (FileOutputStream fos = new FileOutputStream("serial.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);) {

			oos.writeObject(person01);
			oos.writeObject(person02);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// 객체 역직열화

		try (FileInputStream fis = new FileInputStream("serial.ser");
				ObjectInputStream ois = new ObjectInputStream(fis);) {
			Person p01 = (Person) ois.readObject();
			Person p02 = (Person) ois.readObject();
			System.out.println(p01);
			System.out.println(p02);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		System.out.println("완료");
	}

}
//Person [name=홍길동, job=대빵]
//Person [name=이상무, job=상무]
//완료