package com.pcwk.ex09.serialization;

import java.io.Serializable;

public class Person implements Serializable {

	/**
	 * 객체의 동일성 체크를 위해 사용. 
	 */
	private static final long serialVersionUID = 2458674610896675082L;
	
	String name;
	//객체 직렬화 대상에서 제외.
	transient String job;
	
	public Person() {}

	public Person(String name, String job) {
		super();
		this.name = name;
		this.job = job;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", job=" + job + "]";
	}

}
