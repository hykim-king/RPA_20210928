package com.pcwk.ex04.reader;

import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileReaderEx01Main {
	public static final Logger LOG = Logger.getLogger(FileReaderEx01Main.class);
	
	public static void main(String[] args) {
		
		String filePath = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex04\\reader\\reader.txt";
		//안녕하세요.오우 오오
		//한글 깨짐
	    // try(FileInputStream fis=new FileInputStream(filePath)){
		
		//2byte단위로 읽어서 한글,한자등 깨어지지 않음.
		 try(FileReader fis=new FileReader(filePath)){

	    	int i;
	    	while(  (i=fis.read()) !=-1) {
	    		System.out.print((char)i);
	    	}
	    	
	    	
	    }catch(IOException e) {
	    	LOG.debug(e);
	    }

	    LOG.debug("종료");
	}

}
//안녕하세요.오우 오오
//2021-10-26 13:14:57,296 DEBUG [main] reader.FileReaderEx01Main (FileReaderEx01Main.java:26)     - 종료