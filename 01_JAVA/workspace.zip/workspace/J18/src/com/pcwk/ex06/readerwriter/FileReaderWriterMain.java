package com.pcwk.ex06.readerwriter;

import java.io.*;
import org.apache.log4j.*;

public class FileReaderWriterMain {
	public final static Logger LOG = Logger.getLogger(FileReaderWriterMain.class);

	public static void main(String[] args) {
		// 특수 문자
		// '\n' : 라인스킵
		// '\r' : 케리지 return
		// '\t' : tab문자
		// ' ': space문자
		String readFile = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex06\\readerwriter\\FileReaderWriterMain.java";

		try (FileReader fr = new FileReader(readFile); FileWriter fw = new FileWriter("convert.txt");) {

			int data = 0;
			while ((data = fr.read()) != -1) {
				if (data != ' ' && data !='\n' && data !='\r' && data !='\t') {
					fw.write(data);
				}
			}  

		} catch (IOException e) {
			e.printStackTrace();
		}
		LOG.debug("종료");

	}

}
