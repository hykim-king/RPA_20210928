package com.pcwk.ex02.fileoutputstream;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileOutputStreamEx01Main {
	final static Logger LOG = Logger.getLogger(FileOutputStreamEx01Main.class);

	public static void main(String[] args) {

		try (FileOutputStream fos = new FileOutputStream("output02.txt", true);) {

			byte[] bs = new byte[26];
			byte data = 65;// 'A' 아스키 코드

			for (int i = 0; i < bs.length; i++) {
				bs[i] = data;
				data++;
			}
			fos.write(bs);
		} catch (IOException e) {
			LOG.debug("===========================");
			LOG.debug(e);
			LOG.debug("===========================");
		}

		LOG.debug("종료");
	}

}
