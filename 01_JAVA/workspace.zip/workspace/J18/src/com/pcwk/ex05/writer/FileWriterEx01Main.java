package com.pcwk.ex05.writer;

import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileWriterEx01Main {
	public static final Logger LOG = Logger.getLogger(FileWriterEx01Main.class);

	public static void main(String[] args) {
		// 특수 문자
		// \n : 라인스킵
		// \r : 케리지 return
		// \t : tab문자
		// ' ': space문자
		try (FileWriter fw = new FileWriter("writer.txt")) {

			fw.write('B');
			char[] buf = { ' ', 'R', 'P', 'A', ' ', 'C', 'L', 'A', 'S', 'S' };
			fw.write(buf);// 문자 배열

			String msg = "\n점심 맛나게 드셨나요?";
			fw.write(msg);// 문자열
			fw.write("\n");

			fw.write(buf, 1, 7);

		} catch (IOException e) {
			LOG.debug("=====================");
			LOG.debug(e);
			LOG.debug("=====================");
		}

		LOG.debug("완료");
	}

}
