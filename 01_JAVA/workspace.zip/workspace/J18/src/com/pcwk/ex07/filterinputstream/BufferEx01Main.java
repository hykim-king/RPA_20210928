package com.pcwk.ex07.filterinputstream;

import java.io.*;
import org.apache.log4j.*;

public class BufferEx01Main {
	public static final Logger LOG = Logger.getLogger(BufferEx01Main.class);

	public static void main(String[] args) {

		String fileName = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex07\\filterinputstream\\big_file.txt";
        long startTime = 0;
        long endTime   = 0;
		try (FileInputStream fis = new FileInputStream(fileName);
			 FileOutputStream fos = new FileOutputStream("copy_big_file.txt");) {
			//시작시간
			startTime = System.currentTimeMillis();
			
			//1byte읽어서 기록
			int i = 0;
			while(  ( i=fis.read())!=-1 ) {
				fos.write(i);
			}
			
			//종료시간
			endTime = System.currentTimeMillis();

		} catch (IOException e) {
			LOG.debug("=================");
			LOG.debug(e);
			LOG.debug("=================");
		}
		LOG.debug("경과시간:"+(endTime - startTime)+"밀리세컨");
	}

}
//- 경과시간:54277밀리세컨
