package com.pcwk.ex07.filterinputstream;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

public class FileReaderEx01Main {
	public static final Logger LOG = Logger.getLogger(FileReaderEx01Main.class);

	public static void main(String[] args) {

		String filePath = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex04\\reader\\reader.txt";
		// 안녕하세요.오우 오오
		// 한글 깨짐
		// -바이트 단위로 읽거나 쓰는 자료를 문자로 변환해주는 보조 스트림

		try (FileInputStream fis = new FileInputStream(filePath); 
			 InputStreamReader isr = new InputStreamReader(fis);) {
			int i;
			while ((i = isr.read()) != -1) {
				System.out.print((char) i);
			}

		} catch (IOException e) {
			LOG.debug(e);
		}

		LOG.debug("종료");
	}

}
//안녕하세요.오우 오오
//2021-10-26 14:27:12,575 DEBUG [main] filterinputstream.FileReaderEx01Main (FileReaderEx01Main.java:32)     - 종료
