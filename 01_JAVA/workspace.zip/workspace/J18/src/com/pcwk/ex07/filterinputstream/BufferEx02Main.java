package com.pcwk.ex07.filterinputstream;

import java.io.*;
import org.apache.log4j.*;

public class BufferEx02Main {
	public static final Logger LOG = Logger.getLogger(BufferEx02Main.class);

	public static void main(String[] args) {

		String fileName = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex07\\filterinputstream\\big_file.txt";
        long startTime = 0;
        long endTime   = 0;
		try (FileInputStream fis = new FileInputStream(fileName);
			 BufferedInputStream  bis=new BufferedInputStream(fis);	
			 FileOutputStream fos = new FileOutputStream("copy_big_file.txt");
			 BufferedOutputStream bos=new BufferedOutputStream(fos); 	
				) {
			//readbuffer
			
			//writebuffer
			
			
			//시작시간
			startTime = System.currentTimeMillis();
			
			//1byte읽어서 기록
			int i = 0;
			while(  ( i=bis.read())!=-1 ) {
				bos.write(i);
			}
			
			//종료시간
			endTime = System.currentTimeMillis();

		} catch (IOException e) {
			LOG.debug("=================");
			LOG.debug(e);
			LOG.debug("=================");
		}
		LOG.debug("경과시간:"+(endTime - startTime)+"밀리세컨");
	}

}
//- 2021-10-26 15:05:18,539 DEBUG [main] filterinputstream.BufferEx02Main (BufferEx02Main.java:41)     - 경과시간:371밀리세컨

