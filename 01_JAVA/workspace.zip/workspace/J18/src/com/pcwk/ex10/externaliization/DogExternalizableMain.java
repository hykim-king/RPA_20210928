package com.pcwk.ex10.externaliization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DogExternalizableMain {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.name = "멍멍이";

		//직열화
		try (FileOutputStream fos = new FileOutputStream("external.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);) {
			oos.writeObject(dog);
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		//역직열화
		try (FileInputStream fis = new FileInputStream("external.ser");
				ObjectInputStream ois = new ObjectInputStream(fis);) {
			Dog dogR = (Dog) ois.readObject();
			System.out.println(dogR);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {  
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
		System.out.println("완료");
	}

}
//Dog [name=멍멍이]
//완료
