package com.pcwk.ex03.readwrite;

import java.io.*;
import org.apache.log4j.*;

public class FileCopyEx01Main {
	final static Logger LOG = Logger.getLogger(FileCopyEx01Main.class);
	
	public static void main(String[] args) {
		//FileCopyEx01Main.java -> FileCopyEx01Main.bak
		String readFilePath = "D:\\RPA_20210928\\01_JAVA\\workspace\\J18\\src\\com\\pcwk\\ex03\\readwrite\\FileCopyEx01Main.java";
		String saveFile     = "FileCopyEx01Main.bak";

		try(FileInputStream  fis=new FileInputStream(readFilePath);
			FileOutputStream fos=new FileOutputStream(saveFile);) {
			
			int data ;
			while( (data=fis.read()) !=-1) {
				fos.write(data);
			}
			
			
		}catch(IOException e) {
			LOG.debug("===============================");
			LOG.debug(e.toString());
			LOG.debug("===============================");
		}
		
		LOG.debug("copy완료");
	}

}
