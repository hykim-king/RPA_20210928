package com.pcwk.ex04.properties;
import java.util.*;


public class PropertiesMain {
    //애플리케이션의 환경설정과 관련된 속성을 저장
	public static void main(String[] args) {
		Properties  prop=new Properties();
		
		//key,value(String,String) 추가
		prop.setProperty("timeout", "30");
		prop.setProperty("language", "kr");
		prop.setProperty("size", "10");
		prop.setProperty("capacity", "10");
		
		//저장된 요소 가지고 오기
		//? 모든 클래스
		Enumeration<String> e = (Enumeration<String>) prop.propertyNames();
		
		while(e.hasMoreElements() == true) {
			String element =  e.nextElement();
			//value가지고 오기
			System.out.println(element+","+prop.getProperty(element));
			
		}
		System.out.println("=================================");
		
		//수정 
		prop.setProperty("size", "20");
		System.out.println("size:"+prop.getProperty("size"));
	}

}
