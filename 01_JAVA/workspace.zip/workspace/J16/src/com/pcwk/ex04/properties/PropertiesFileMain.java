package com.pcwk.ex04.properties;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

//ctrl+shift+o
public class PropertiesFileMain {
    //애플리케이션의 환경설정과 관련된 속성을 저장
	public static void main(String[] args) {
		Properties  prop=new Properties();
		
		//key,value(String,String) 추가
		prop.setProperty("timeout", "30");
		prop.setProperty("language", "한글");
		prop.setProperty("size", "10");
		prop.setProperty("capacity", "10");
		
		//파일에 기록
		try {
			prop.store(new FileOutputStream("pcwk.properties"), "PCWK Properties");
			
			//xml로 기록
			prop.storeToXML(new FileOutputStream("pcwk_properties.xml"), "PCWK Properties");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("생성 성공!");
	}

}
