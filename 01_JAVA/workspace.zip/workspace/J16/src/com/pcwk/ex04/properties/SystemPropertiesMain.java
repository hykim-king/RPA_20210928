package com.pcwk.ex04.properties;
import java.util.*;
public class SystemPropertiesMain {

	public static void main(String[] args) {
		
		Properties sysProp = System.getProperties();
		System.out.println("java.version:"+sysProp.getProperty("java.version"));
		//console에 모든 Properties출력
		sysProp.list(System.out);
		

	}

}
//java.version:1.8.0_291
//-- listing properties --
//java.runtime.name=Java(TM) SE Runtime Environment
//sun.boot.library.path=C:\Program Files\Java\jdk1.8.0_291\jr...
//java.vm.version=25.291-b10
//java.vm.vendor=Oracle Corporation
//java.vendor.url=http://java.oracle.com/
//path.separator=;
//java.vm.name=Java HotSpot(TM) 64-Bit Server VM
//file.encoding.pkg=sun.io
//user.script=
//user.country=KR
//sun.java.launcher=SUN_STANDARD
//sun.os.patch.level=
//java.vm.specification.name=Java Virtual Machine Specification
//user.dir=D:\RPA_20210928\01_JAVA\workspace\J16
//java.runtime.version=1.8.0_291-b10
//java.awt.graphicsenv=sun.awt.Win32GraphicsEnvironment
//java.endorsed.dirs=C:\Program Files\Java\jdk1.8.0_291\jr...
//os.arch=amd64
//java.io.tmpdir=C:\Users\HKEDU\AppData\Local\Temp\
//line.separator=
//
//java.vm.specification.vendor=Oracle Corporation
//user.variant=
//os.name=Windows 10
//sun.jnu.encoding=MS949
//java.library.path=C:\Program Files\Java\jdk1.8.0_291\bi...
//java.specification.name=Java Platform API Specification
//java.class.version=52.0
//sun.management.compiler=HotSpot 64-Bit Tiered Compilers
//os.version=10.0
//user.home=C:\Users\HKEDU
//user.timezone=
//java.awt.printerjob=sun.awt.windows.WPrinterJob
//file.encoding=UTF-8
//java.specification.version=1.8
//user.name=HKEDU
//java.class.path=D:\RPA_20210928\01_JAVA\workspace\J16...
//java.vm.specification.version=1.8
//sun.arch.data.model=64
//java.home=C:\Program Files\Java\jdk1.8.0_291\jre
//sun.java.command=com.pcwk.ex04.properties.SystemProper...
//java.specification.vendor=Oracle Corporation
//user.language=ko
//awt.toolkit=sun.awt.windows.WToolkit
//java.vm.info=mixed mode
//java.version=1.8.0_291
//java.ext.dirs=C:\Program Files\Java\jdk1.8.0_291\jr...
//sun.boot.class.path=C:\Program Files\Java\jdk1.8.0_291\jr...
//java.vendor=Oracle Corporation
//file.separator=\
//java.vendor.url.bug=http://bugreport.sun.com/bugreport/
//sun.cpu.endian=little
//sun.io.unicode.encoding=UnicodeLittle
//sun.desktop=windows
//sun.cpu.isalist=amd64
