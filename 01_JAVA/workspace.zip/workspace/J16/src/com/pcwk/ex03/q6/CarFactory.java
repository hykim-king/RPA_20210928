package com.pcwk.ex03.q6;

import java.util.HashMap;

public class CarFactory {

	
	private static CarFactory  instance=new CarFactory();
	private HashMap<String, Car> hashMap=new HashMap<>();
	
	private CarFactory() {
		
	}
	
	public static CarFactory getInstance() {
		if(null == instance) {
			instance=new CarFactory();
		}
		
		
		return instance;
	}
	
	public Car createCar(String name) {
		if(hashMap.containsKey(name)) {
			return hashMap.get(name);
		}
		Car car=new Car(name);
		hashMap.put(name, car);
		return car;
	}

}
