package com.pcwk.ex03.q6;

public class CarMain {

	public static void main(String[] args) {
		CarFactory  factory=CarFactory.getInstance();
		
		Car  sonata01 = factory.createCar("연수 차");
		Car  sonata02 = factory.createCar("연수 차");

		System.out.println(sonata01==sonata02);//true
		
		Car  avante01 = factory.createCar("승연 차");
		Car  avante02 = factory.createCar("승연 차");
		
		System.out.println(avante01==avante02);//true
		
		System.out.println(sonata01==avante01);//false
	}

}
