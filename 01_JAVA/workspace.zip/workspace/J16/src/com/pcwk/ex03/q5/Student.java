package com.pcwk.ex03.q5;

public class Student implements Comparable<Student> {
	private String studentId;
	private String studentName;
	
	public Student(String studentId, String studentName) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
	}
	

	@Override
	public int compareTo(Student o) {
		return this.studentId.compareTo(o.studentId);
	}
	
	//데이터 : 100:홍길동 으로 출력하기 위해 
	@Override
	public String toString() {
		return studentId+":"+studentName;
	}
	
	//객체 유일성 보장
	@Override
	public int hashCode() {
		return studentId.hashCode();
	}
	
	//객체 유일성 보장
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		Student other = (Student) obj;
		if (studentId == null) {
			if (other.studentId != null)
				return false;
		} else if (!studentId.equals(other.studentId))
			return false;

		return true;
	}
	
	
}
