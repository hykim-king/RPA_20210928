package com.pcwk.ex03.q6;

public class Car {
	private String name;
	
	public Car() {}
	public Car(String name) {
		this.name = name;
	}

}
