package com.pcwk.ex02.treemap;

import com.pcwk.ex01.map.Member;

public class MemberTreeMapMain {

	public static void main(String[] args) {
		MemberTreeMap memberTreeMap=new MemberTreeMap();

		Member member01=new Member(1,"오일남");
		Member member02=new Member(67,"강새벽");
		Member member03=new Member(101,"장덕수");
		Member member04=new Member(199,"알리 압둘");
		Member member05=new Member(212,"한미녀");
		
		memberTreeMap.addMember(member05);
		memberTreeMap.addMember(member04);
		memberTreeMap.addMember(member03);
		memberTreeMap.addMember(member01);
		memberTreeMap.addMember(member02);
		
		memberTreeMap.showAllMember();
		memberTreeMap.removeMember(199);
		
		memberTreeMap.showAllMember();
	}

}
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=101, memberName=장덕수]
//Member [memberId=199, memberName=알리 압둘]
//Member [memberId=212, memberName=한미녀]
//=============================
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=101, memberName=장덕수]
//Member [memberId=212, memberName=한미녀]
//=============================