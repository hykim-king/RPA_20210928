package com.pcwk.ex02.treemap;
import java.util.Iterator;
import java.util.TreeMap;

import com.pcwk.ex01.map.Member;
//ctrl+alt+o

public class MemberTreeMap {
	private TreeMap<Integer, Member> treeMap;
	
	public MemberTreeMap() {
		treeMap = new TreeMap<>();
	}
	
	
	/**
	 * 멤버추가
	 * @param member
	 */
	public void addMember(Member member) {
		treeMap.put(member.getMemberId(), member);
	}
	
	/**
	 * 멤버삭제
	 * @param memberId
	 * @return
	 */
	public boolean removeMember(int memberId) {
		if(treeMap.containsKey(memberId)) {
			treeMap.remove(memberId);
			
			return true;
		}
		
		System.out.println(memberId+"가 존재하지 않습니다.");
		return false;
	}
	
	/**
	 * 모든 멤버의 내용 출력.
	 */
	public void showAllMember() {
		Iterator<Integer> iter = treeMap.keySet().iterator();
		
		while(iter.hasNext()) {
			int key = iter.next();
			
			Member member = treeMap.get(key);
			System.out.println(member);
		}
		
		System.out.println("=============================");
	}
	
}




















