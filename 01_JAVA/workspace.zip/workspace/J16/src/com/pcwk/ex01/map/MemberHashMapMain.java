package com.pcwk.ex01.map;

public class MemberHashMapMain {

	public static void main(String[] args) {
		MemberHashMap memberHashMap=new MemberHashMap();
		
		Member member01=new Member(1,"오일남");
		Member member02=new Member(67,"강새벽");
		Member member03=new Member(101,"장덕수");
		Member member04=new Member(199,"알리 압둘");
		Member member05=new Member(212,"한미녀");
		
		
		memberHashMap.addMember(member01);
		memberHashMap.addMember(member02);
		memberHashMap.addMember(member03);
		memberHashMap.addMember(member04);
		memberHashMap.addMember(member05);
		
		memberHashMap.showAllMember();
		
		memberHashMap.removeMember(101);
		memberHashMap.showAllMember();
		
	}

}
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=212, memberName=한미녀]
//Member [memberId=101, memberName=장덕수]
//Member [memberId=199, memberName=알리 압둘]
//
//Member [memberId=1, memberName=오일남]
//Member [memberId=67, memberName=강새벽]
//Member [memberId=212, memberName=한미녀]
//Member [memberId=199, memberName=알리 압둘]