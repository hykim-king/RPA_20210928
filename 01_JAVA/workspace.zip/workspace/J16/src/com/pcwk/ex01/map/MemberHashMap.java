package com.pcwk.ex01.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class MemberHashMap {

	private HashMap<Integer, Member>  hashMap;
	
	public MemberHashMap() {
		hashMap = new HashMap<>();
	}
	
	/**
	 * hashMap에 추가
	 * @param member
	 */
	public void addMember(Member member) {
		hashMap.put(member.getMemberId(), member);
	}
	
	/**
	 * hashMap에 삭제
	 * @param memberId
	 * @return 삭제(true)/false
	 */
	public boolean removeMember(int memberId) {
		if(hashMap.containsKey(memberId) == true) {
			hashMap.remove(memberId);
			return true;
		}
		
		System.out.println(memberId+"가 존재하지 않습니다.");
		
		return false;
	}
	
	/**
	 * hashMap내용을 모두 출력
	 */
	public void showAllMember() {
		
		Set<Integer> keys=hashMap.keySet();
		Iterator<Integer> iter =keys.iterator();
		
		while(iter.hasNext()) {
			int key =iter.next();//unboxing
			
			Member  member= hashMap.get(key);
			System.out.println(member.toString());
		}
		
		System.out.println();
		
	}
	
	
	
	
	
	
	
	
	
	
}
