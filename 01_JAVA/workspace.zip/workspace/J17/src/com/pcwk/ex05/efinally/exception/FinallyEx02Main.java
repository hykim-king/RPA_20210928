package com.pcwk.ex05.efinally.exception;

import org.apache.log4j.*;
import java.io.*;

public class FinallyEx02Main {
	final static Logger LOG = Logger.getLogger(FinallyEx02Main.class);
	
	public static void main(String[] args) {
		//File읽기
		FileInputStream fis = null;
		
		LOG.debug("시작");
		try {
			fis = new FileInputStream("output.log");
		} catch (FileNotFoundException e) {
			LOG.debug(e.getMessage());
			//e.printStackTrace();
			
		}finally {
			try {
				LOG.debug("항상 수행");
				fis.close();
			} catch (IOException e) {
				LOG.debug(e.getMessage());
				//e.printStackTrace();
			}
		}
		
		LOG.debug("여기도 수행");
		

	}

}
