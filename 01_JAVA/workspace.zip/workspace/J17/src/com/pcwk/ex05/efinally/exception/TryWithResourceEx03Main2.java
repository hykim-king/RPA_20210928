package com.pcwk.ex05.efinally.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;
//ctrl+shift+o
public class TryWithResourceEx03Main2 {
	final static Logger LOG = Logger.getLogger(TryWithResourceEx03Main2.class);
	
	public static void main(String[] args) {
		
		LOG.debug("시작");
		try(FileInputStream fis =new FileInputStream("output.log");) {
			
		} catch (FileNotFoundException e) {
			LOG.debug(e.getMessage());
		} catch (IOException e1) {
			LOG.debug(e1.getMessage());
		}  
		
		LOG.debug("여기도 수행");
		

	}

}
