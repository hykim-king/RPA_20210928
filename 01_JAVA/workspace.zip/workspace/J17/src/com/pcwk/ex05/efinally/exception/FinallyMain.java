package com.pcwk.ex05.efinally.exception;

import org.apache.log4j.Logger;

public class FinallyMain {
	final static Logger LOG = Logger.getLogger(FinallyMain.class);
	
	public static void main(String[] args) {
		//프로그램 설치에 필요한 준비를 한다.													
		//파일을 복사한다.													
		//프로그램 설치에 사용된 임시파일을 삭제한다.													

		try {
			startInstall();
			copyFiles();
			//deleteTempFiles();
		}catch(Exception e) {
			e.printStackTrace();
			//deleteTempFiles();
		}finally {
			deleteTempFiles();
		}
		

	}

	static void startInstall() {
		//프로그램 설치에 필요한 준비를 한다.		
	}
	
	
	static void copyFiles() {
		//파일을 복사한다.		
	}
	
	static void deleteTempFiles() {
		//프로그램 설치에 사용된 임시파일을 삭제한다.			
	}
	
}
