package com.pcwk.ex06.ethrows.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.Logger;

public class ThrowsExceptionMain {

	final static Logger LOG = Logger.getLogger(ThrowsExceptionMain.class);
	
	/**
	 * 메서드를 호출한 곳에서 예외 처리
	 * @param fileName
	 * @param className
	 * @return
	 * @throws ClassNotFoundException
	 * @throws FileNotFoundException
	 */
	public Class loadClass(String fileName,String className) 
			throws ClassNotFoundException, FileNotFoundException {
		
		FileInputStream fis=new FileInputStream("b.txt");
		Class c = Class.forName(className);
		
		return c;
	}
	
	public static void main(String[] args)  {
		ThrowsExceptionMain throwExcep=new ThrowsExceptionMain();
		try {
			throwExcep.loadClass("a.txt", "java.lang.String99");
		} catch (ClassNotFoundException e) {
			LOG.debug("=ClassNotFoundException==========================");
			LOG.debug(e.getMessage());
			LOG.debug("=ClassNotFoundException==========================");
		} catch (FileNotFoundException e) {
			LOG.debug("=FileNotFoundException==========================");
			LOG.debug(e.getMessage());
			LOG.debug("=FileNotFoundException==========================");
		}

	}

}
//2021-10-25 13:46:05,102 DEBUG [main] exception.ThrowsExceptionMain (ThrowsExceptionMain.java:38)     - =FileNotFoundException==========================
//2021-10-25 13:46:05,106 DEBUG [main] exception.ThrowsExceptionMain (ThrowsExceptionMain.java:39)     - b.txt (지정된 파일을 찾을 수 없습니다)
//2021-10-25 13:46:05,106 DEBUG [main] exception.ThrowsExceptionMain (ThrowsExceptionMain.java:40)     - =FileNotFoundException==========================
