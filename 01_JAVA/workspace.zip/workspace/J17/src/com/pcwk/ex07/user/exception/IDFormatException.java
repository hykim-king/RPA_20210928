package com.pcwk.ex07.user.exception;

public class IDFormatException extends Exception {

	public IDFormatException(String message) {
		super(message);
	}
}
