package com.pcwk.ex07.user.exception;

import org.apache.log4j.Logger;

public class IDFormatExceptionMain {
	final static Logger  LOG = Logger.getLogger(IDFormatExceptionMain.class);
	private String userID;
	
	public String getUserID() {
		return userID;
	}


	public void setUserID(String userID) throws IDFormatException {
		if(null == userID) {
			//강제로 예외 발생
			throw new IDFormatException("아이디는 Null일수 없습니다.");
		}//8<=userID<=20
		else if(userID.length()<8 || userID.length() >20) {
			//강제로 예외 발생
			throw new IDFormatException("아이디는 8자이상 20자 이하로 사용하세요.");			
		}
		
		
		this.userID = userID;
	}


  

	public static void main(String[] args) {
		
		IDFormatExceptionMain  idFormat=new IDFormatExceptionMain();
		String userID = null;
		
		//userID==null인 경우 예외 처리
		try {
			idFormat.setUserID(userID);
		} catch (IDFormatException e) {
			LOG.debug(e.getMessage());
		}
		
		userID ="1234567";
		try {
			idFormat.setUserID(userID);
		} catch (IDFormatException e) {
			LOG.debug(e.getMessage());
		}
		
		LOG.debug("프로그램 종료");
		
	}

}
//2021-10-25 14:18:08,664 DEBUG [main] exception.IDFormatExceptionMain (IDFormatExceptionMain.java:40)     - 아이디는 Null일수 없습니다.
//2021-10-25 14:18:08,668 DEBUG [main] exception.IDFormatExceptionMain (IDFormatExceptionMain.java:47)     - 아이디는 8자이상 20자 이하로 사용하세요.
//2021-10-25 14:18:08,668 DEBUG [main] exception.IDFormatExceptionMain (IDFormatExceptionMain.java:50)     - 프로그램 종료
