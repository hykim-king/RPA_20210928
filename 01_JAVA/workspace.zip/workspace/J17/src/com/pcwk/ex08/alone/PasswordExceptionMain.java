package com.pcwk.ex08.alone;

import org.apache.log4j.Logger;

import com.pcwk.ex07.user.exception.IDFormatException;
import com.pcwk.ex07.user.exception.IDFormatExceptionMain;


public class PasswordExceptionMain {
	final static Logger  LOG = Logger.getLogger(PasswordExceptionMain.class);
	
	private String pass;
	
	
	public String getPass() {
		return pass;
	}


	public void setPass(String pass) throws PasswordException {
		if(null == pass) {
			//강제로 예외 발생
			throw new PasswordException("비밀번호는 Null일수 없습니다.");
		}//
		else if(pass.length()<5 ) {
			//강제로 예외 발생
			throw new PasswordException("비밀번호는 5자 이상으로 사용하세요.");	
		//영문대소문자가 1개 이상	
		}else if(pass.matches("[a-zA-Z]+")==true ) {
			throw new PasswordException("비밀번호는 문자열 만으로 사용할 수 없습니다.");		
		}
		this.pass = pass;
	}


	public static void main(String[] args) {
		PasswordExceptionMain  passwordExceptionMain=new PasswordExceptionMain();
		String passwd = null;
		

		try {
			passwordExceptionMain.setPass(passwd);
		} catch (PasswordException e) {
			LOG.debug(e.getMessage());
		}
		
		passwd ="1234";
		try {
			passwordExceptionMain.setPass(passwd);
		} catch (PasswordException e) {
			LOG.debug(e.getMessage());
		}
//		//앞 문자가 1개 이상의 개수가 존재할 수 있습니다.
//      //[]문자의 집합이나 범위를 표현합니다. -기호를 통해 범위를 나타낼 수 있습니다. 
		passwd ="aqswdefrgt";
		//passwd ="aqswdefrgt1";
		try {
			passwordExceptionMain.setPass(passwd);
		} catch (PasswordException e) {
			LOG.debug(e.getMessage());
		}		
		LOG.debug("프로그램 종료");

	}

}
//2021-10-25 15:00:45,200 DEBUG [main] alone.PasswordExceptionMain (PasswordExceptionMain.java:44)     - 비밀번호는 Null일수 없습니다.
//2021-10-25 15:00:45,204 DEBUG [main] alone.PasswordExceptionMain (PasswordExceptionMain.java:51)     - 비밀번호는 5자 이상으로 사용하세요.
//2021-10-25 15:00:45,208 DEBUG [main] alone.PasswordExceptionMain (PasswordExceptionMain.java:60)     - 비밀번호는 문자열 만으로 사용할 수 없습니다.
//2021-10-25 15:00:45,208 DEBUG [main] alone.PasswordExceptionMain (PasswordExceptionMain.java:62)     - 프로그램 종료