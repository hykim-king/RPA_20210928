package com.pcwk.ex09.inputoutput;

import java.io.IOException;

import org.apache.log4j.Logger;

public class SystemWordMain {
	final static Logger LOG = Logger.getLogger(SystemWordMain.class);
	
	
	public static void main(String[] args) {
		System.out.println("알파벳 여러 게를 쓰고 [Enter]를 누르세요.");
		int ch;
		
		try {
			while((ch = System.in.read()) !=-1) {
				System.out.print((char)ch);
			}
			System.out.println();
		} catch (IOException e) {
			LOG.debug("=======================");
			LOG.debug(e.getMessage());
			LOG.debug("=======================");
		}

	}

}
//알파벳 여러 게를 쓰고 [Enter]를 누르세요.
//asdfghjkl
//asdfghjkl
