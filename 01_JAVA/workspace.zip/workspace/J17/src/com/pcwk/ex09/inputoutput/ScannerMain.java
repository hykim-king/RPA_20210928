package com.pcwk.ex09.inputoutput;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class ScannerMain {

	final static Logger LOG = Logger.getLogger(ScannerMain.class);
	
	public static void main(String[] args) {
	
      Scanner scanner =new Scanner(System.in);
      
      System.out.println("이름:");
      String name = scanner.nextLine();
      
      System.out.println("직업:");
      String job = scanner.nextLine();
      
      
      System.out.println("사번:");
      int num = scanner.nextInt();
      
      System.out.println(name);
      System.out.println(job);
      System.out.println(num);
       
      
	}

}
