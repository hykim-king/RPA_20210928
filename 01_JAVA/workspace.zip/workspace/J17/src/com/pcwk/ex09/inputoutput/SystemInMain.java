package com.pcwk.ex09.inputoutput;

import java.io.IOException;

import org.apache.log4j.Logger;

public class SystemInMain {

	final static Logger LOG = Logger.getLogger(SystemInMain.class);
	
	public static void main(String[] args) {
		//System.in으로 문자 입력 받기
		System.out.println("알파벳 하나를 쓰고 [Enter]를 누르세요.");
		System.err.println("System.err.println()");
		int ch ;
		
		try {
			ch = System.in.read();
			
			System.out.println("code:"+ch);
			System.out.println("알파벳:"+(char)ch);
		} catch (IOException e) {
			LOG.debug(e);
		}

	}

}
