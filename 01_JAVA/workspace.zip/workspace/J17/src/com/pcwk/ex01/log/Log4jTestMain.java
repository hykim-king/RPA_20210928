package com.pcwk.ex01.log;

import org.apache.log4j.Logger;

public class Log4jTestMain {
	final static Logger  LOG = Logger.getLogger(Log4jTestMain.class);
	public static void main(String[] args) {
		LOG.debug("Log4j");

	}

}
