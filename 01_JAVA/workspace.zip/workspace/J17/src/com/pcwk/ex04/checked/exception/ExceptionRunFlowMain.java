package com.pcwk.ex04.checked.exception;

import org.apache.log4j.Logger;

public class ExceptionRunFlowMain {

	final static Logger  LOG = Logger.getLogger(ExceptionRunFlowMain.class);
	
	public static void main(String[] args) {
		LOG.debug("1");
		LOG.debug("2");
		try {
			LOG.debug("3");
			LOG.debug(0/0);
			LOG.debug("4");
		}catch(ArithmeticException e) {
			LOG.debug("5");
			e.printStackTrace();//예외 발생 당시의 호출스택에 있었던 메서드의 정보와 예외 메시지를 화면에 출력
			LOG.debug(e.getMessage());//발생한 예외클래스의 인스턴스에 저장된 메시지
		}
		
		LOG.debug("6");

	} 

}
//정상적인 수행
//2021-10-25 10:40:47,500 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:10)     - 1
//2021-10-25 10:40:47,503 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:11)     - 2
//2021-10-25 10:40:47,503 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:13)     - 3
//2021-10-25 10:40:47,504 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:14)     - 4
//2021-10-25 10:40:47,504 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:19)     - 6

//예외발생
//2021-10-25 10:41:51,382 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:10)     - 1
//2021-10-25 10:41:51,389 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:11)     - 2
//2021-10-25 10:41:51,389 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:13)     - 3
//2021-10-25 10:41:51,389 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:17)     - 5
//2021-10-25 10:41:51,389 DEBUG [main] exception.ExceptionRunFlowMain (ExceptionRunFlowMain.java:20)     - 6