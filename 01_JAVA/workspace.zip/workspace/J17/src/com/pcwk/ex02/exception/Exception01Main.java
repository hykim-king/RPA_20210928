package com.pcwk.ex02.exception;

import org.apache.log4j.Logger;

public class Exception01Main {

	final static Logger LOG = Logger.getLogger(Exception01Main.class);
	public static void main(String[] args) {
		
		int number = 100;
		int result = 0;
		for(int i=0;i<10;i++) {
			
			try {
				
					result = number / (int)(Math.random()*10);
					LOG.debug("result:"+result);
				
			}catch(ArithmeticException e) {
				LOG.debug("0 발생");
				LOG.debug(e);
			}catch(Exception e) {
				LOG.debug("0 발생");
				LOG.debug(e);				
			}
			
		}

	}

}
//정상적으로 종료
//2021-10-25 10:23:36,825 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:100
//2021-10-25 10:23:36,837 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:25
//2021-10-25 10:23:36,837 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:33
//2021-10-25 10:23:36,838 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:100
//2021-10-25 10:23:36,838 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:12
//2021-10-25 10:23:36,838 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:16
//2021-10-25 10:23:36,839 DEBUG [main] exception.Exception01Main (Exception01Main.java:20)     - 0 발생
//2021-10-25 10:23:36,839 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:20
//2021-10-25 10:23:36,846 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:11
//2021-10-25 10:23:36,846 DEBUG [main] exception.Exception01Main (Exception01Main.java:17)     - result:20