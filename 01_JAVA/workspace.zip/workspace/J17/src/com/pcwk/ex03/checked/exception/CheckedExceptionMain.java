package com.pcwk.ex03.checked.exception;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.*;

import com.pcwk.ex02.exception.Exception01Main;

public class CheckedExceptionMain {

	final static Logger LOG = Logger.getLogger(CheckedExceptionMain.class);
	
	public static void main(String[] args) {
		//LOG.debug("================");
		LOG.debug("Start");
		try {
			FileInputStream  fis=new FileInputStream("output99.log");
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			LOG.debug("fileNotFound");
			LOG.debug(e.toString());
		}
		
		LOG.debug("End");
		
	}

}
//2021-10-25 10:35:41,755 DEBUG [main] exception.CheckedExceptionMain (CheckedExceptionMain.java:15)     - Start
//2021-10-25 10:35:41,762 DEBUG [main] exception.CheckedExceptionMain (CheckedExceptionMain.java:20)     - fileNotFound
//2021-10-25 10:35:41,762 DEBUG [main] exception.CheckedExceptionMain (CheckedExceptionMain.java:21)     - java.io.FileNotFoundException: output99.log (지정된 파일을 찾을 수 없습니다)
//2021-10-25 10:35:41,763 DEBUG [main] exception.CheckedExceptionMain (CheckedExceptionMain.java:24)     - End
