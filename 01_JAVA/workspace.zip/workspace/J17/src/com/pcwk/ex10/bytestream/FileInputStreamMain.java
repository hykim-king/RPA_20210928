package com.pcwk.ex10.bytestream;

import java.io.*;

import org.apache.log4j.Logger;

public class FileInputStreamMain {
	final static Logger  LOG = Logger.getLogger(FileInputStreamMain.class);
	
	public static void main(String[] args) {
		//존재하지 않는 파일 read
		FileInputStream fis = null;
		
		LOG.debug("시작");
		try {
			fis = new FileInputStream("a.txt");//존재 하지 않는 파일
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());
		}catch(IOException e) {
			LOG.debug("======================");
			LOG.debug("=IOException:="+e.getMessage());
			LOG.debug("======================");
		}finally {
			if(null !=fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		LOG.debug("끝");
	}

}
