package com.pcwk.ex10.bytestream;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileInputStream02Main {
	final static Logger  LOG = Logger.getLogger(FileInputStream02Main.class);
	
	public static void main(String[] args) {
		//존재하지 않는 파일 read
		
		
		LOG.debug("시작");
		try(FileInputStream fis =new FileInputStream("a.txt");) {
			
			int ch =0;
			while( (ch=fis.read()) !=-1 ) {
				System.out.print((char)ch);
			}
			System.out.println();
			
		}catch(IOException e) {
			LOG.debug("======================");
			LOG.debug("=IOException:="+e.getMessage());
			LOG.debug("======================");
		}

		LOG.debug("끝");
	}

}
//2021-10-25 16:43:33,164 DEBUG [main] bytestream.FileInputStream02Main (FileInputStream02Main.java:15)     - 시작
//abc
//2021-10-25 16:43:33,169 DEBUG [main] bytestream.FileInputStream02Main (FileInputStream02Main.java:30)     - 끝