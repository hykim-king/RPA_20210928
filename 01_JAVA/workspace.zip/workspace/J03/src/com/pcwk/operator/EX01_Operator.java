/**
 * 
 */
package com.pcwk.operator;

/**
 * @author HKEDU
 *
 */
public class EX01_Operator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num = 10;
		System.out.println("num="+num);
		System.out.println(+num);
		System.out.println(-num);
		System.out.println(num);
		
		num = -num;
		System.out.println(num);//-10
		
	}

}
