package com.pcwk.einterface.ex09;

import java.sql.Connection;
import java.util.ArrayList;

public class BookShelfMain {

	public static void main(String[] args) {
		//List  list=new ArrayList();
		Queue shelfQueue=new BookShelf();
		//queue에 추가
		shelfQueue.enQueue("태백산맥 1");
		shelfQueue.enQueue("태백산맥 2");
		shelfQueue.enQueue("태백산맥 3");
		
		System.out.println("queue size:"+shelfQueue.getSize());
		
		//queue 꺼내기
		System.out.println(shelfQueue.deQuey());
		System.out.println(shelfQueue.deQuey());
		System.out.println(shelfQueue.deQuey());
		System.out.println("queue size:"+shelfQueue.getSize());
		
		
	}

}
//queue size:3
//태백산맥 1
//태백산맥 2
//태백산맥 3
//queue size:0