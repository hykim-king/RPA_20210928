package com.pcwk.einterface.ex10.q7;

public class BubbleSort implements Sort {

	@Override
	public void ascending(int[] numArr) {
		System.out.println("BubbleSort ascending");
		//버블 sort
		for(int i=0;i<numArr.length-1;i++) {
			for(int j=0;j<numArr.length-1-i;j++) {
				if(numArr[j]>numArr[j+1]) {//앞의 값이 크면 자리를 교환(오름차순)
				//if(numArr[j]<numArr[j+1]) {//앞의 값이 크면 자리를 교환(내림차순)
					int tmp     = numArr[j];
					numArr[j]   = numArr[j+1];
					numArr[j+1] = tmp;
				}
			}
		}	
		
		//sort이후 
		for(int i=0;i<numArr.length;i++) {
			System.out.print(numArr[i]+",");
		}		
		System.out.println();
		
	}

	@Override
	public void decending(int[] numArray) {
		System.out.println("BubbleSort decending");
		
	}

	@Override
	public void description() {
		Sort.super.description();
		System.out.println("BubbleSort 입니다.");
	}
	
	

}
