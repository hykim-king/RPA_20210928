package com.pcwk.einterface.ex09;

/**
 * FIFO(First In First Out) 구조
 * @author HKEDU
 *
 */
public interface Queue {

	int getSize();
	String deQuey();
	void enQueue(String title);
}
