package com.pcwk.einterface.ex06;

public class CustomerMain {

	public static void main(String[] args) {
		Customer customer=new Customer();
		
		Buy   buyer = customer;
		buyer.buy();
		
		Sell  seller = customer;
		seller.sell();
		
		System.out.println("============================");
		
		if(seller instanceof Customer) {
			Customer customer02= (Customer) seller;
			
			customer02.buy();
			customer02.sell();
		}

	}

}
//판매하기
//구매하기
//============================
//판매하기
//구매하기
