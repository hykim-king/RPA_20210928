package com.pcwk.einterface.ex10.q7;

public class QuickSort implements Sort {

	@Override
	public void ascending(int[] numArray) {
		System.out.println("QuickSort ascending");
		
	}

	@Override
	public void decending(int[] numArray) {
		System.out.println("QuickSort decending");
		
	}

	@Override
	public void description() {
		Sort.super.description();
		System.out.println("QuickSort 입니다.");
	}
	
	

}
