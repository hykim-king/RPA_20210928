package com.pcwk.einterface.ex05;

public interface Calc {

//	인터페이스(interface)																					
//	모든 메서드가 추상메서드(abstract method), 모든 변수 상수(public final)																				
//	변수에 public final 생략가능
//  메서드 public abstract 생략가능	
	double PI = 3.14f;//public final 생략
	
	int ERROR =-99999999;
	
	int add(int num1,int num2);//public abstract 생략가능
	int substract(int num1,int num2);
	int times(int num1,int num2);
	int divided(int num1,int num2);
	
	//jdk 1.8이후 가능: default method
	default void description() {
		System.out.println("정수 계산기를 구현합니다.");
	}
	
	
	//jdk 1.8이후 가능: static method
	static int total(int[] arr) {
		int total = 0;
		
		//향상된 for
		for(int i :arr) {
			total+=i;
		}
		
		return total;
	}
	
}
