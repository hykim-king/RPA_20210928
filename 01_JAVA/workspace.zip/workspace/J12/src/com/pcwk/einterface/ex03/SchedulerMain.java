package com.pcwk.einterface.ex03;

import java.io.IOException;

public class SchedulerMain {

	public static void main(String[] args) throws IOException {
		//R: RoundRobin방식으로 
		//L: LeastJob방식으로 실행
		//P: PriorityAllocation방식으로 실행
		
		System.out.println("상담 할당 방식을 선택하세요.");
		System.out.println("R: RoundRobin방식으로             ");
		System.out.println("L: LeastJob방식으로 실행           ");
		System.out.println("P: PriorityAllocation방식으로 실행 ");		
		
		//char 입력 
		int ch = System.in.read();
		//System.out.println((char)ch);
		
		//다형성
		Scheduler  scheduler = null;
		
		if(ch=='R' || ch=='r') {
			//RoundRobin방식
			scheduler = new RoundRobin();
		}else if(ch=='L' || ch =='l') {
			//LeastJob방식
			scheduler = new LeastJob();
		}else if(ch=='P' || ch =='p') {
			//PriorityAllocation
			scheduler = new PriorityAllocation();
		}else {
			System.out.println("지원되지 않는 기능 입니다.");
		}
		
		//해당 정개에 해당되는 기능 call
		scheduler.getNextCall();
		scheduler.sendCallToAgent();
		
		
		
		
	}

}
