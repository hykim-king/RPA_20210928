package com.pcwk.einterface.ex08;

public interface Y {
	void y();
}
