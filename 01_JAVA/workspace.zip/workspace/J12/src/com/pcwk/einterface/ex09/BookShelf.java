package com.pcwk.einterface.ex09;

public class BookShelf extends Shelf implements Queue {

	@Override
	public int getSize() {
		return shelf.size();
	}

	/**
	 * 맨처음 요소를 arrayList에서 삭제하고 반환
	 */
	@Override
	public String deQuey() {
		return shelf.remove(0);
	}

	/**
	 * arrayList에 추가
	 */
	@Override
	public void enQueue(String title) {
		shelf.add(title);
		
	}

}
