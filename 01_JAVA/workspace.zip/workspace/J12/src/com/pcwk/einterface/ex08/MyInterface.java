package com.pcwk.einterface.ex08;

public interface MyInterface extends X, Y {
	void myMethod();
}
