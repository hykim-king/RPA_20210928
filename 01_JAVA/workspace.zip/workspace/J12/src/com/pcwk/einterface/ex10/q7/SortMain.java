package com.pcwk.einterface.ex10.q7;

import java.io.IOException;

public class SortMain {

	public static void main(String[] args) throws IOException {
		System.out.println("정렬 방식을 선택하세요. ");
		System.out.println("B : BubbleSort    ");
		System.out.println("H : HeapSort      ");
		System.out.println("Q : QuickSort     ");

		int ch = System.in.read();
		
		Sort sort = null;
		
		if(ch=='B' || ch == 'b') {
			sort = new BubbleSort();
		}else if(ch=='H' || ch == 'h') {
			sort = new HeapSort();
		}else if(ch=='Q' || ch == 'q') {
			sort = new QuickSort();
		}else {
			System.out.println("정렬 방식을 선택 하세요.");
			return;
		}
		
		
		int []arr = {70,60,90,100,80};
		sort.ascending(arr);
		sort.decending(arr);
		sort.description();
		
		SortMain sortMain=new SortMain();


		
	}

}
//정렬 방식을 선택하세요. 
//B : BubbleSort    
//H : HeapSort      
//Q : QuickSort     
//q
//QuickSort ascending
//QuickSort decending
//숫자를 정렬하는 알고리즘입니다.
//QuickSort 입니다.