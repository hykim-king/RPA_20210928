package com.pcwk.einterface.ex04.alone;

public interface Scheduler {
	/**
	 * 다음 콜
	 */
	public abstract void getNextCall();
	
	/**
	 * 콜을 Agent에 배분
	 */
	public void sendCallToAgent();
}
