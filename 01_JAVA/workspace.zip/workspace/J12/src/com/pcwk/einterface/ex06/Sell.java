package com.pcwk.einterface.ex06;

public interface Sell {
	void sell();

}
