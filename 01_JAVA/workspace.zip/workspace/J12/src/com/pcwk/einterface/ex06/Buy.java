package com.pcwk.einterface.ex06;

public interface Buy {

	void buy();
}
