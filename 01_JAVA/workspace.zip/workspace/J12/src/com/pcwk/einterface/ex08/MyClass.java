package com.pcwk.einterface.ex08;

public class MyClass implements MyInterface {

	@Override
	public void x() {
		System.out.println("MyClass x()");
		
	}

	@Override
	public void y() {
		System.out.println("MyClass y()");
		
	}

	@Override
	public void myMethod() {
		System.out.println("MyClass myMethod()");
		
	}

}
