package com.pcwk.einterface.ex08;

public class MyInterfaceMain {

	public static void main(String[] args) {
		MyClass myClass=new MyClass();
		
		X xClass= myClass;
		
		xClass.x();
		
		Y yClass= myClass;
		
		yClass.y();
		
		System.out.println("===================");
		MyInterface myInterface=myClass;
		myInterface.myMethod();
		myInterface.x();
		myInterface.y();
	}

}
//MyClass x()
//MyClass y()
//===================
//MyClass myMethod()
//MyClass x()
//MyClass y()
