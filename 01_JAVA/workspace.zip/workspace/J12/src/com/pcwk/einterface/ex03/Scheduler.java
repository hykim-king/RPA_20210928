package com.pcwk.einterface.ex03;

public interface Scheduler {
	/**
	 * 다음 콜
	 */
	public abstract void getNextCall();
	
	/**
	 * 콜을 Agent에 배분
	 */
	public void sendCallToAgent();
}
