package com.pcwk.einterface.ex08;

public interface X {
	void x();
}
