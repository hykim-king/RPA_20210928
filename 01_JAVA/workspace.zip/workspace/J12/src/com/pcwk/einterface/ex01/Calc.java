package com.pcwk.einterface.ex01;

public interface Calc {

//	인터페이스(interface)																					
//	모든 메서드가 추상메서드(abstract method), 모든 변수 상수(public final)																				
//	변수에 public final 생략가능
//  메서드 public abstract 생략가능	
	double PI = 3.14f;//public final 생략
	
	int ERROR =-99999999;
	
	int add(int num1,int num2);//public abstract 생략가능
	int substract(int num1,int num2);
	int times(int num1,int num2);
	int divided(int num1,int num2);
	
}
