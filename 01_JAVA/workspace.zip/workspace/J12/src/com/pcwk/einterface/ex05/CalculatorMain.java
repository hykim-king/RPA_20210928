package com.pcwk.einterface.ex05;

public class CalculatorMain {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 5;
		
		Calculator  calc=new Calculator();
		
		System.out.println("add:"+calc.add(num1, num2));
		System.out.println("substract:"+calc.substract(num1, num2));
		System.out.println("times:"+calc.times(num1, num2));
		System.out.println("divide:"+calc.divided(num1, num2));
		calc.showInfo();
		
		//default method call
		calc.description();
		
		//static method call
		int [] arr= {1,2,3,4,5};
		System.out.println(Calc.total(arr));
	}
}
//정수 계산기를 구현합니다.
//default 메소드 overriding
//15