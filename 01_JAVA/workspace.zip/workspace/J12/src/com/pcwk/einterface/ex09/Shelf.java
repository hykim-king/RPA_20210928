package com.pcwk.einterface.ex09;

import java.util.ArrayList;
public class Shelf {
	protected ArrayList<String> shelf;
	
	public Shelf() {
		shelf = new ArrayList<>();
	}

	public ArrayList<String> getShelf() {
		return shelf;
	}
	
	/**
	 * shelf에 있는 element 수.
	 * @return
	 */
	public int getCount() {
		return shelf.size();
	}
}
