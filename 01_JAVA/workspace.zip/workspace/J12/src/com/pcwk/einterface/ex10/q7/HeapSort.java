package com.pcwk.einterface.ex10.q7;

public class HeapSort implements Sort {

	@Override
	public void ascending(int[] numArray) {
		System.out.println("HeapSort ascending");
		
	}

	@Override
	public void decending(int[] numArray) {
		System.out.println("HeapSort decending");
		
	}

	@Override
	public void description() {
		Sort.super.description();
		System.out.println("HeapSort 입니다.");
	}
	
	

}
