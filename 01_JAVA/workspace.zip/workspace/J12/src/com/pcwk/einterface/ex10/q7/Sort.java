package com.pcwk.einterface.ex10.q7;

public interface Sort {
	/**
	 * 오름차순 정열
	 * @param numArray
	 */
  public void ascending(int[] numArray);
  
  /**
   * 내림차순 정열
   * @param numArray
   */
  public void decending(int[] numArray);
  
  /**
   * 알고리즘 설명
   */
  public default void  description() {
	  System.out.println("숫자를 정렬하는 알고리즘입니다.");
  }
  
}
