package com.pcwk.lang.ex11.object;

public class BookMain {

	public static void main(String[] args) {
		Book book=new Book(200,"개미");
		//book.toString():com.pcwk.lang.ex11.object.Book@15db9742
		System.out.println("book.toString():"+book.toString());
		
		//book:com.pcwk.lang.ex11.object.Book@15db9742
		System.out.println("book:"+book);
	}

}
//book.toString():Book [bookNumber=200, bookTitle=개미]
//book:Book [bookNumber=200, bookTitle=개미]