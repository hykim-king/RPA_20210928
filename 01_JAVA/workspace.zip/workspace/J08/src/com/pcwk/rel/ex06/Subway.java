/**
 * package: com.pcwk.rel.ex06
 * file name: Subway.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.rel.ex06;

/**
 * @author HKEDU
 *
 */
public class Subway {
	String lineNumber;//노선번호
    int passengetCount;//승객수
    int money;//수입액
    
    //생성자:lineNumber
    public Subway(String lineNumber) {
    	//Subway 멤버    = param
    	this.lineNumber = lineNumber;
    }
    
    public void take(int money) {
    	this.money += money;//subway 금액 증가
    	passengetCount++;
    }
    
    //5호선 승객은 1명 수입은 1000입니다.
    public void showInfo() {
    	System.out.println(lineNumber+" 승객은 "+passengetCount+"명 수입은 "+money+"입니다.");
    }
    
    
}
