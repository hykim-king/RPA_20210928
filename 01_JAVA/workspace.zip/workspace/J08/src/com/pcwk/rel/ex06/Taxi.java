/**
 * package: com.pcwk.rel.ex06
 * file name: Taxi.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.rel.ex06;

/**
 * @author HKEDU
 *
 */
public class Taxi {
	String companyName;//택시회사
	int passengetCount;//승객수
	int money;//수입액
	/**
	 * @param companyName
	 */
	public Taxi(String companyName) {
		this.companyName = companyName;
	}
	
	/**
	 * 승객이 지불하는 요금
	 * @param money
	 */
	public void take(int money) {
		this.money+=money;
		passengetCount++;
	}
	/**
	 * 택시 정보
	 */
    public void showInfo() {
    	System.out.println(companyName+" 승객은 "+passengetCount+"명 수입은 "+money+"입니다.");
    }	
}
