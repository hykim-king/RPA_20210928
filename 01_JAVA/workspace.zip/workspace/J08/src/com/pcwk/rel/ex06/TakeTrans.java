/**
 * package: com.pcwk.rel.ex06
 * file name: TakeTrans.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.rel.ex06;

/**
 * @author HKEDU
 *
 */
public class TakeTrans {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student student01=new Student("이상무", 5_000);
		Student student02=new Student("james",10_000);
		
		Student student03=new Student("Edward",20_000);
		
//		//버스요금 : 1000
//		//버스번호로 생성.
//		Bus bus01=new Bus(6);
//		student01.takeBus(bus01);
//		//버스탄 학생 정보
//		student01.showInfo();
//		//버스정보
//		bus01.showInfo();
//		
//		//지하철
//		Subway  subway01=new Subway("5호선");
//		student02.takeSubway(subway01);
//		//학생02 정보
//		student02.showInfo();
//		//지하철 정보
//		subway01.showInfo();
		
		Taxi  taxi=new Taxi("보람");
		student03.takeTaxi(taxi);
		
		student03.showInfo();
		taxi.showInfo();
	}

}
