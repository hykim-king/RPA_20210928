/**
 * package: com.pcwk.rel.ex06
 * file name: Bus.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.rel.ex06;

/**
 * @author HKEDU
 *
 */
public class Bus {
	int busNumber;//버스 번호
	int passengerCount;//승객 수
    int money;
    
    public Bus(int busNumber) {
    	this.busNumber = busNumber;
    }
    
    public void take(int money) {
    	this.money += money;
    	passengerCount++;
    }
    
    public void showInfo() {
    	System.out.println("버스 "+busNumber+"번의 승객은 "+passengerCount +"명이고 수입은 "+money+"입니다.");
    }
}
