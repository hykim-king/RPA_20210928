/**
 * package: com.pcwk.rel.ex06
 * file name: Student.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.rel.ex06;

/**
 * @author HKEDU
 *
 */
public class Student {
	String name;//이름
    int    grade;//학년
    int    money;//가진 돈

    public Student(String name,int money) {
    	this.name = name;
    	this.money= money;
    }
    
    
    public void takeBus(Bus bus) {
    	bus.take(1000);//버스에 지불
    	this.money -= 1_000;//본인 지갑에서 1000원 차감
    }
    
    public void takeSubway(Subway subway) {
    	subway.take(1100);//지하철 공사에 지급
    	this.money -=1100;//본인 지갑에서 1100원 차감
    }
    
    public void takeTaxi(Taxi taxi) {
    	taxi.take(10_000);//택시에 지급
    	this.money -=10_000;//본인 지갑에서 10000원 차감
    }    
    
    //학생 이름과 남은 돈
    public void showInfo() {
    	System.out.println(name+"님의 남은 돈은 "+money+"입니다.");
    }
    
    
    
    
}
