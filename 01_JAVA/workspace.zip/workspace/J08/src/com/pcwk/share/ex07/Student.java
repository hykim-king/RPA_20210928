/**
 * package: com.pcwk.share.ex07
 * file name: Student.java
 * description: 공유변수
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.share.ex07;

/**
 * @author HKEDU
 *
 */
public class Student {

	//static변수는 인스턴스 생성과 상관 없이 먼저 생성됨.
	static int serialNum = 1000;
	int studentID;//학번
	String studentName;//이름
	int grade;//학년
	String address;//주소
	
	public Student() {
		serialNum++;//학생이 생성 될때 마다 증가
		studentID = serialNum;//학번에 시리얼 번호 할당
		
	}
	
	/**
	 * @return the studentName
	 */
	public String getStudentName() {
		return studentName;
	}
	/**
	 * @param studentName the studentName to set
	 */
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	
	
	
}
