/**
 * package: com.pcwk.share.ex07
 * file name: StudentMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.share.ex08;

/**
 * @author HKEDU
 *
 */
public class StudentMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student student01=new Student();

		student01.setStudentName("박지수");
		System.out.println(Student.serialNum);//1001
		
		//시리얼 번호 증가
		student01.serialNum++;
		
		Student student02=new Student();
		student02.setStudentName("전승우");
		System.out.println(student02.serialNum);//1003
	}

}
//1000
//1001
