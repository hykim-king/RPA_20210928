/**
 * package: com.pcwk.access.ex01
 * file name: MyDate.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access.ex03;

/**
 * @author HKEDU
 *
 */
public class MyDate {

	private int day;  //일
	private int month;//월	
	private int year; //년
	
	
	public MyDate() {
		
	}
	
	
	/**
	 * @param day
	 * @param month
	 * @param year
	 */
	public MyDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	public boolean isValid() {
		boolean flag= true;
		//년도는 0보다 크면 유효
		if(year< 0){
			flag = false; 
		}
		
		//월은 1~12월 사이
		if(!(month>=1 && month<=12)){
			flag = false; 
		}
		
		//월에 따른 일수
		if(month==2) {
			if(day<1 || day>28) {
				System.out.println("2월은 1~29사이 입니다.");
				flag = false; 
			}
		}else if(month ==4 || month ==6 || month ==9|| month ==11) {
			if(day<1 || day>30) {
				System.out.println(month+"월은 1~30사이 입니다.");
				flag = false;	
			}
		}else {
			if(day<1 || day>31) {
				System.out.println(month+"월은 1~31사이 입니다.");
				flag = false;	
			}			
		}
		
		if(flag==true) {
			System.out.println("유효한 날자 입니다.");
		}else {
			System.out.println("유효하지 않은 날자 입니다.");	
		}
		
		
		
		return flag;
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}
	/**
	 * @param day the day to set
	 */
	public void setDay(int day) {
		if(month==2) {
			if(day<1 || day>28) {
				System.out.println("오류 입니다.");
				return;
			}
		}
		
		this.day = day;
	}
	/**
	 * @return the month
	 */
	public int getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(int month) {
		this.month = month;
	}
	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	
	
}
