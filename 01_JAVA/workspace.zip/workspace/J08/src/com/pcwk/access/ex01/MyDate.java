/**
 * package: com.pcwk.access.ex01
 * file name: MyDate.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access.ex01;

/**
 * @author HKEDU
 *
 */
public class MyDate {

	private int day;  //일
	private int month;//월	
	private int year; //년
	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}
	/**
	 * @param day the day to set
	 */
	public void setDay(int day) {
		if(month==2) {
			if(day<1 || day>28) {
				System.out.println("오류 입니다.");
				return;
			}
		}
		
		this.day = day;
	}
	/**
	 * @return the month
	 */
	public int getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(int month) {
		this.month = month;
	}
	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	
	
}
