/**
 * package: com.pcwk.access
 * file name: StudentMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access.ex02;

import com.pcwk.access.Student;

/**
 * @author HKEDU
 *
 */
public class StudentMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student student=new Student();
		
		//student.studentName = "이상무";
		student.setStudentName("이상무");
		student.setGrade(1);
		
		System.out.println("학생이름:"+student.getStudentName());
		System.out.println("학년은:"+student.getGrade());
	}

}
