/**
 * package: com.pcwk.access.ex01
 * file name: MyDateMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access.ex03;

/**
 * @author HKEDU
 *
 */
public class MyDateMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyDate myDate=new MyDate(30,2,2021);

		System.out.println(myDate.isValid());
		
		MyDate myDate02=new MyDate(30,3,2021);
		System.out.println(myDate02.isValid());
	}

}
