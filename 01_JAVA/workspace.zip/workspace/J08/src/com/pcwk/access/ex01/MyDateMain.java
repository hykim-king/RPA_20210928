/**
 * package: com.pcwk.access.ex01
 * file name: MyDateMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access.ex01;

/**
 * @author HKEDU
 *
 */
public class MyDateMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyDate myDate=new MyDate();
		
//		myDate.year  = 2021;
//		myDate.month = 2;
//		myDate.day   = 31;

		myDate.setYear(2021);
		myDate.setMonth(2);
		myDate.setDay(31);
		
		
		System.out.println(myDate.getYear() +"/"+myDate.getMonth()+"/"+myDate.getDay());
		
	}

}
