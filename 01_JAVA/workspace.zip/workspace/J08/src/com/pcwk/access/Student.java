/**
 * package: com.pcwk.access
 * file name: Student.java
 * description: 접근지정자
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.access;

/**
 * @author HKEDU
 *
 */
public class Student {
	int studentID;
	private String studentName;
	private int grade;
	String address;
	
	//setXXX : setter
	public void setStudentName(String studentNm) {
		studentName = studentNm;
	}
	
	//getXXX : getter
	public String getStudentName() {
		return studentName;
	}

	/**
	 * @return the grade
	 */
	public int getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(int grade) {
		if(grade<0) {
			System.out.println("학년은 1보다 같거나 커야 합니다.");
			return;
		}
		this.grade = grade;
	}
	
	
	
	
	
	
	
	
	
	
}
