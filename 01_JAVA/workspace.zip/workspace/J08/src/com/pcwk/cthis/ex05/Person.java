/**
 * package: com.pcwk.cthis.ex05
 * file name: Person.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.cthis.ex05;

/**
 * @author HKEDU
 *
 */
public class Person {
	String name;  //이름
	int age;      //나
	
	public Person() {
		this("이름 없음",1);//인자 2개 생성자 호출
		this.age = 1;//this는 생성자의 첫 줄에 위치 해야 한다.
		
	}
	/**
	 * @param name
	 * @param age
	 */
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	
	Person returnItSelf() {
		return this;
	}
	
}
