/**
 * package: com.pcwk.cthis.ex04
 * file name: ThisMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.cthis.ex04;

/**
 * @author HKEDU
 *
 */

class BirthDay{
	int day;
	int month;
	int year;
	
	public BirthDay() {
		
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	
	
	public void printThis() {
		System.out.println(this);
	}
	
}


public class ThisMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BirthDay birth=new BirthDay();
		birth.setYear(2021);
		
		System.out.println(birth.year);
		
		birth.printThis();
		System.out.println(birth);
		

	}

}
//com.pcwk.cthis.ex04.BirthDay@123a439b
//com.pcwk.cthis.ex04.BirthDay@123a439b













