/**
 * package: com.pcwk.cthis.ex05
 * file name: PersonMain.java
 * description:
 * user: HKEDU
 * create date: 2021-10-12
 * version: 0.3
 *
 */
package com.pcwk.cthis.ex05;

/**
 * @author HKEDU
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person=new Person();
		System.out.println(person.age);
		System.out.println(person.name);
		System.out.println("person:"+person);
		
		
		Person person02 = person.returnItSelf();
		System.out.println(person02.age);
		System.out.println(person02.name);
		System.out.println("person02:"+person02);

	}

}
//1
//이름 없음
//person:com.pcwk.cthis.ex05.Person@123a439b
//1
//이름 없음
//person02:com.pcwk.cthis.ex05.Person@123a439b