package com.pcwk.estatic.ex05.q5;

public class BeanCoffee {
	int money;
	
	public BeanCoffee() {
		
	}
	
	public String brewing(int money) {
		this.money +=money;
		
		if(money==Menu.BEAN_LATTE) {
			return "콩 다방 라테를 구입 했습니다.";
		}else if(money==Menu.BEAN_AMERICANO) {
			return "콩 다방 아메리카노를 구입 했습니다.";
		}else {
			return null;
		}
	}
	
}
