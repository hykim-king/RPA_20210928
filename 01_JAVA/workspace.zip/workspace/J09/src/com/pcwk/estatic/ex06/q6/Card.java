package com.pcwk.estatic.ex06.q6;

public class Card {

	private static int serialNum = 10_000;//시리얼 번호
	private int cardNum ;//카드번호

	public Card() {
		serialNum++;
		cardNum = serialNum;
	}

	public int getCardNum() {
		return cardNum;
	}

	public void setCardNum(int cardNum) {
		this.cardNum = cardNum;
	}
	
	
	
}
