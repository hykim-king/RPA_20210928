package com.pcwk.estatic.ex01;

public class Student {

	private static int serialNum = 1000;

	int studentID; // 학번
	String studentName;// 이름
	int grade;// 학년
	String address;// 주소
	
	public Student() {
		serialNum++;
		studentID = serialNum;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	//static 메서드는 인스턴스 변수(멤버변수)
	public static int getSerialNum() {
		//Cannot make a static reference to the non-static field grade
		//grade = 1;
		int age =1;
		
		return serialNum;
	}

	public static void setSerialNum(int serialNum) {
		Student.serialNum = serialNum;
	}

	
}
