package com.pcwk.estatic.ex03.singleton;

public class Company {
    
	//유일한 인스턴스 생성
	private static Company instance=new Company();
	
	//생성자는 private으로 
	private Company() {
		
	}
	
	//외부에서 참조 할수 있도록 static메소드 생성.
	public static Company getInstance() {
		if(null == instance) {
			instance=new Company();
		}
		
		return instance;
	}
}
