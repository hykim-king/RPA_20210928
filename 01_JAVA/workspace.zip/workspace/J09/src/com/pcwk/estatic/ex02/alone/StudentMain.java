package com.pcwk.estatic.ex02.alone;

public class StudentMain {

	public static void main(String[] args) {
		Student student01=new Student();
		student01.setStudentName("이유빈");
		
		System.out.println(Student.getSerialNum());
		System.out.println(Student.getStudentCard());
		System.out.println(student01.getStudentName()+
				"\t학번:"+student01.studentID+
				"\t학생카드 번호:"+Student.getStudentCard());

		System.out.println("================================");
		Student student02=new Student();
		student02.setStudentName("김희련");
		
		System.out.println(Student.getSerialNum());
		System.out.println(Student.getStudentCard());
		System.out.println(student02.getStudentName()+
				"\t학번:"+student02.studentID+
				"\t학생카드 번호:"+Student.getStudentCard());		
	}

}
