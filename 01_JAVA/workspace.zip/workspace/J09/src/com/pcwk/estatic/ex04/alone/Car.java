package com.pcwk.estatic.ex04.alone;

public class Car {

	private static int carSerialNum = 10_000;//시리얼 번호
	private int carNum;//자동차 번호
	
	public Car() {
		carSerialNum++;//시리얼 번호 증가
		carNum = carSerialNum;
	}

	public int getCarNum() {
		return carNum;
	}

	public void setCarNum(int carNum) {
		this.carNum = carNum;
	}
	
	
	
}
