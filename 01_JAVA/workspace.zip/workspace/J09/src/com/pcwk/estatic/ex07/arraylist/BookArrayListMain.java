package com.pcwk.estatic.ex07.arraylist;
import java.util.ArrayList;

public class BookArrayListMain {

	public static void main(String[] args) {
		
		ArrayList<Book> libary=new ArrayList();
		
		
		libary.add(new Book("태백산맥","조정래"));
		libary.add(new Book("데미안","헤르만 헤세"));
		libary.add(new Book("토지","박경리"));
		libary.add(new Book("어린왕자","생텍쥐페리"));

		//추가되면 10 -> 자
		System.out.println("============================");
		System.out.println("libary.size()="+libary.size());
		
		System.out.println("============================");
		
		//전체 내용 출력
		for(int i=0;i<libary.size();i++) {
			Book  book = libary.get(i);
			book.showBookInfo();
		}
		
		System.out.println("============================");
		
		//향상되 for
		for(Book book : libary) {
			book.showBookInfo();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
