package com.pcwk.estatic.ex06.q6;

public class CardCompanyMain {

	public static void main(String[] args) {
		CardCompany cardCompany = CardCompany.getInstance();
		CardCompany cardCompany02 = CardCompany.getInstance();
		
		Card card01 = cardCompany.createCard();
		Card card02 = cardCompany.createCard();
		
		System.out.println(card01.getCardNum());
		System.out.println(card02.getCardNum());
		System.out.println("cardCompany:"+cardCompany);
		System.out.println("cardCompany02:"+cardCompany02);
		System.out.println(cardCompany==cardCompany02);

	}

}
//10001
//10002
//cardCompany:com.pcwk.estatic.ex06.q6.CardCompany@15db9742
//cardCompany02:com.pcwk.estatic.ex06.q6.CardCompany@15db9742
//true