package com.pcwk.estatic.ex05.q5;

public class CoffeeMain {

	public static void main(String[] args) {
		Person person01 = new Person("김씨", 10_000);
		StarCoffee starCoffee = new StarCoffee();
		person01.buyStarCoffee(starCoffee, Menu.STAR_AMERICANO);
		
		System.out.println("==================================");
		
		Person person02 = new Person("이씨", 100_000_000);
		BeanCoffee  beanCoffee=new BeanCoffee();
		person02.buyBeanCoffee(beanCoffee,Menu.BEAN_LATTE);
	}

}
