package com.pcwk.estatic.ex01;

public class StudentMain {

	public static void main(String[] args) {
		Student student01=new Student();
		student01.setStudentName("김도형");
		//1001
		System.out.println(Student.getSerialNum());
		
		System.out.println(student01.getStudentName()+" 학번:"+student01.studentID);

		Student student02=new Student();
		student02.setStudentName("홍승주");
		System.out.println(Student.getSerialNum());
		System.out.println(student02.getStudentName()+" 학번:"+student02.studentID);
	}

}
//1001
//김도형 학번:1001
//1002
//홍승주 학번:1002