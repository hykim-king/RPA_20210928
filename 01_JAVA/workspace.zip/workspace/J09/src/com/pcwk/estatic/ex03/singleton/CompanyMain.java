package com.pcwk.estatic.ex03.singleton;

public class CompanyMain {

	public static void main(String[] args) {
		//The constructor Company() is not visible
		//Company company=new Company();

		Company instance01 = Company.getInstance();
		Company instance02 = Company.getInstance();
		
		System.out.println("(instance01==instance02)"+(instance01==instance02));
		System.out.println("instance01:"+instance01);
		System.out.println("instance02:"+instance02);
		
		
	}

}
