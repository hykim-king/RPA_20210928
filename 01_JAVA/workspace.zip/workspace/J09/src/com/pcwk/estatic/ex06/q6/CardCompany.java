package com.pcwk.estatic.ex06.q6;

public class CardCompany {
//	singleton 패턴																
//	인스턴스를 단 하나만 생성하는 디자인 패턴														
//	1. 생성자를 private만든다.														
//	2. static으로 유일한 인스턴스 생성														
//	3. 외부에서 참조할 수 있는 public 메서드 필요.
	
	private static CardCompany instance=new CardCompany();
	
	private CardCompany() {
		
	}
	
	public static CardCompany getInstance() {
		//null처리
		if(null == instance) {
			instance=new CardCompany();
		}	
		return instance;
	}

	
	public Card createCard() {
		return new Card();
	}
	
}
