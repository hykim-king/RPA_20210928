package com.pcwk.estatic.ex04.alone;

public class CarFactory {
//	인스턴스를 단 하나만 생성하는 디자인 패턴													
//	1. 생성자를 private만든다.													
//	2. static으로 유일한 인스턴스 생성													
//	3. 외부에서 참조할 수 있는 public 메서드 필요.													

	private static CarFactory instance=new CarFactory();
	
	private CarFactory() {
		
	}
	
	public static CarFactory getInstance() {
		if(null == instance) {
			instance = new CarFactory();
		}
		
		return instance;
	}
	
	public Car createCar(){
		return new Car();
	}
	
}
