package com.pcwk.estatic.ex05.q5;

public class Menu {

	public final static int STAR_AMERICANO = 4_000;
	public final static int STAR_LATTE = 5_000;

	public final static int BEAN_AMERICANO = 4_000;
	public final static int BEAN_LATTE = 4_500;	
}
