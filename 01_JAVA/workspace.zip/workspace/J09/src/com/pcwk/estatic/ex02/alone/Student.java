package com.pcwk.estatic.ex02.alone;

public class Student {
	private static int serialNum = 1000;

	int studentID; // 학번
	String studentName;// 이름
	int grade;// 학년
	String address;// 주소
	
 	private static int studentCard;//학생카드
 	
 	public Student() {
 		serialNum++;
 		studentID = serialNum;
 		studentCard = studentID + 100;
 	}

	public static int getSerialNum() {
		return serialNum;
	}

	public static void setSerialNum(int serialNum) {
		Student.serialNum = serialNum;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public static int getStudentCard() {
		return studentCard;
	}

	public static void setStudentCard(int studentCard) {
		Student.studentCard = studentCard;
	}
 	
 	
 	
 	
}
