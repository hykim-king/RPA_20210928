package com.pcwk.estatic.ex06.q6;

public class CardMain {

	public static void main(String[] args) {
		Card card01=new Card();
		Card card02=new Card();
		System.out.println(card01.getCardNum());
		System.out.println(card02.getCardNum());

	}

}
//10001
//10002