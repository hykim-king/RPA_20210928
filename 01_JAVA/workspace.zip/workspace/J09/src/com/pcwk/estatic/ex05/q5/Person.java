package com.pcwk.estatic.ex05.q5;

public class Person {
	String name; //이름
	int    money;//가진 돈
	
	public Person(String name, int money) {
		this.name = name;
		this.money = money;
	}
	/**
	 * 별다방에서 커피 주문!
	 * @param starCoffee
	 * @param money
	 */
	public void buyStarCoffee(StarCoffee starCoffee,int money) {
		String message = starCoffee.brewing(money);
		
		if(null !=message) {
			this.money -= money;//사람이 가지고 있는 돈에서 빼기
			System.out.println(name + "은 "+ money+"원 "+ message);
		}
		
	}	
	
	public void buyBeanCoffee(BeanCoffee beanCoffee,int money) {
		String message = beanCoffee.brewing(money);
		
		if(null !=message) {
			this.money -= money;//사람이 가지고 있는 돈에서 빼기
			System.out.println(name + "은 "+ money+"원 "+ message);
		}
		
	}	
}
