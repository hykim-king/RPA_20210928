package com.pcwk.tostring.ex02.alone;

public class StudentMain {

	public static void main(String[] args) {
		Student st01=new Student(100, "자바");
		System.out.println(st01);//str01.toString()호출

	}

}
