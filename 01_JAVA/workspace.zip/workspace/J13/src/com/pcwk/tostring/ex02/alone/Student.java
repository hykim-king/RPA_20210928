package com.pcwk.tostring.ex02.alone;


public class Student {

	int studentID;//학번
	String studentName;//이름

	
	public Student() {
		
	}
	
	public Student(int studentID,String studentName) {
		this.studentID = studentID;
		this.studentName = studentName;

	}

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studentName=" + studentName + ", toString()=" + super.toString()
				+ "]";
	}



}
