package com.pcwk.tostring.ex01;

public class ToStringMain {

	public static void main(String[] args) {
		//객체를 출력
		//toString()이 오버라이딩되어 값으로 출력됨!
		String str=new String("abc");
		System.out.println("str:"+str.toString());

		
		Integer  i01=new Integer(13);
		System.out.println(i01.toString());
	}

}
