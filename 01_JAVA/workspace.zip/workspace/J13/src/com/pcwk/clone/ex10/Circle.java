package com.pcwk.clone.ex10;
//Cloneable 객체 복사허용.
//Cloneable 내용이 없는  maker interface
public class Circle implements Cloneable {

	Point point;//원점
	int radius;//반지름
	
	public Circle(int x, int y, int radius) {
		this.radius = radius;
		point = new Point(x,y);
	}

	@Override
	public String toString() {
		return "Circle [point=" + point + ", radius=" + radius + "]";
	}
//  Object clone call	
//  얕은 복사	
//	@Override
//	public Object clone() throws CloneNotSupportedException {
//		return super.clone();
//	}
	
//  깊은 복사	
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		Object obj = null;
		
		obj = super.clone();
		//point 레퍼런스를 별도로 생성: copy
		Circle circle=(Circle) obj;
		circle.point = new Point(this.point.x,this.point.y);
		
		return circle;
	}
}

















