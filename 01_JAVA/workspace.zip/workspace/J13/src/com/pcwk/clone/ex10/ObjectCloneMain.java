package com.pcwk.clone.ex10;

public class ObjectCloneMain {

	public static void main(String[] args) throws CloneNotSupportedException {
		Circle  circle=new Circle(10, 20, 30);
		Circle  circleClone = (Circle) circle.clone();
		
		
		System.out.println("circle:"+circle);
		System.out.println("circleClone:"+circleClone);
		
		System.out.println(System.identityHashCode(circle));
		System.out.println(System.identityHashCode(circleClone));
	}

}
//circle:Circle [point=Point [x=10, y=20], radius=30]
//circleClone:Circle [point=Point [x=10, y=20], radius=30]
//366712642
//1829164700