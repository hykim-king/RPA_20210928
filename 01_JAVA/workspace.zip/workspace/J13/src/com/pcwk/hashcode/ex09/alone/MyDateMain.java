package com.pcwk.hashcode.ex09.alone;

public class MyDateMain {

	public static void main(String[] args) {
		MyDate  date01=new MyDate(19, 10, 2021);
		MyDate  date02=new MyDate(19, 10, 2021);
		
		System.out.println(date01.equals(date02));

		System.out.println("hashCode date01:"+date01.hashCode());
		System.out.println("hashCode date02:"+date02.hashCode());
	}

}
//true
//hashCode date01:50381
//hashCode date02:50381