package com.pcwk.hashcode.ex08;

public class StudentHashMain {

	public static void main(String[] args) {
		//클래스의 동일성을 비교하는 경우 equals뿐만 아니고 hashCode도 오버라이딩 해야 한다.															

		Student std01=new Student(12345);
		Student std02=new Student(12345);
		
		
		System.out.println(std01.hashCode());
		System.out.println(std02.hashCode());
		
		//Object에 있는 hash로 출력
		System.out.println("std01:"+System.identityHashCode(std01));
		System.out.println("std02:"+System.identityHashCode(std02));
	}

}
//Object.hashCode(): 주소번지로 hash생성 따라서 hash코드가 다르게 나온다.
//366712642
//1829164700

//12376
//12376