package com.pcwk.hashcode.ex07;

public class HashCodeMain {

	public static void main(String[] args) {
		String str01=new String("abc");
		String str02=new String("abc");
		
		System.out.println(str01.hashCode());
		System.out.println(str02.hashCode());

		Integer  int01=new Integer(23);
		Integer  int02=new Integer(23);
		
		System.out.println(int01.hashCode());
		System.out.println(int02.hashCode());
	}

}
//96354
//96354
//23
//23