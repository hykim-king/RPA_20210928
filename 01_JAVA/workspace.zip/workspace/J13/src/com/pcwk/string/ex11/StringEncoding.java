package com.pcwk.string.ex11;

import java.io.UnsupportedEncodingException;

public class StringEncoding {
	/**
	 * 인코딩: 서로 다른 문자 인코딩을 사용하는 컴퓨터간 데이터를 주고 받을때 필요.
	 * getBytes()를 사용하면 문자열의 인코딩을 다른 인코딩으로 변경
	 * 할수 있다.
	 * @param args
	 * @throws UnsupportedEncodingException 
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {
		String str = "가";
		//encode
		byte[]  bArr01 = str.getBytes("CP949");
		byte[]  bArr02 = str.getBytes("UTF-8");
		
		
		//가-> byte[] param으로 인코딩
		//CP949 : 2byte로 표현 (B0A1)
		System.out.println("CP949 bArr01:"+printByte(bArr01));//CP949 bArr01:-80-95

		//UTF-8 : 3byte로 표현 EA:B0:80
		System.out.println("bArr01 bArr02:"+printByte(bArr02));
		
		//decoding
		//byte[] -> 가
		System.out.println("CP949 byte[] ->"+new String(bArr01, "CP949"));
		System.out.println("UTF-8 byte[] ->"+new String(bArr02, "UTF-8"));
		
	}
	
	static String printByte(byte[] bArr) {
		StringBuilder sb=new StringBuilder();
		for(Byte b: bArr) {
			
			sb.append(String.format("%02X", b)+":");
		}
		
		
		return sb.toString();
	}

}
//CP949 bArr01:B0:A1:
//bArr01 bArr02:EA:B0:80:
//CP949 byte[] ->가
//UTF-8 byte[] ->가