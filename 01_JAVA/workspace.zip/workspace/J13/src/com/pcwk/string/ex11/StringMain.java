package com.pcwk.string.ex11;

public class StringMain {

	public static void main(String[] args) {
		String str01=new String("청춘");
		String str02=new String("청춘");
		
		System.out.println(str01==str02);//주소로 비교 false
		System.out.println(str01.equals(str02));//equals가 오버라이딩 되어 있어 문자열 데이터로 비교 true
		
		String str03= "청춘";
		String str04= "청춘";
		
		System.out.println(str03==str04);//주소로 비교 true
		System.out.println(str03.equals(str04));//equals가 오버라이딩 되어 있어 문자열 데이터로 비교 true
		//내부적 으로 
		//문자열은 private final char value[]; 이므로
		//데이터를 변경할수 없다.
		
		//새로운 배열을 만들고 데이터를 할당한다.
		//문자열이 자주 변경되는 곳에는 맞지 않다.
		String str05= "청춘";
		str05 = "청춘2";
		System.out.println(str05);
	}

}
//문자열 비교는 : equals()메서드를 사용해서 비교 할것.										

//false
//true
//true
//true