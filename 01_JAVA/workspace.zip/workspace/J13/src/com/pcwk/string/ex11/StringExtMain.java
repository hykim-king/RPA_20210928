package com.pcwk.string.ex11;

public class StringExtMain {

	public static void main(String[] args) {
		//java
		String fullName = "Hello.java";
		
		//fullName에서 '.' index필요 : indexOf
		int index = fullName.indexOf('.');
		System.out.println(". index:"+index);
		
		
		// '.' index기준으로 뒤부분 자르기: substring
		String ext = fullName.substring(index+1);
		System.out.println("ext:"+ext);
		
		//파일 이름:index 미포함
		String fileName = fullName.substring(0, index);
		System.out.println("fileName:"+fileName);

		//Hello.java -> hello.java
		//replace(old,new)
		String replaceName = fullName.replace('H', 'h');
		//hello.java
		System.out.println(replaceName);
		
		
	}

}
//. index:5
//ext:java
//fileName:Hello
//hello.java
