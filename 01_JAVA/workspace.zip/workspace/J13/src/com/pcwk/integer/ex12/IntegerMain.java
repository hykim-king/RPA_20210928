package com.pcwk.integer.ex12;

public class IntegerMain {
	/**
	 * Integer class 이용
	 * @param args
	 */
	public static void main(String[] args) {
		Integer num1 = new Integer(100);
		int num2 = 200;
		
		//Integer -> int
		System.out.println("num1.intValue()+num2="+(num1.intValue()+num2));
			
		Integer num3 = new Integer("100");
		int sum = num2 + num3;//컴파일러가 언박싱 처리함.
		System.out.println("num2 + num3="+sum);
		
		System.out.println("Integer.MAX_VALUE:"+Integer.MAX_VALUE);
		System.out.println("Integer.MIN_VALUE:"+Integer.MIN_VALUE);
		System.out.println("Integer.SIZE: "+Integer.SIZE+" bit");
		System.out.println("Integer.BYTES: "+Integer.BYTES +" bytes");
		
		

	}
}
//num1.intValue()+num2=300
//num2 + num3=300
//Integer.MAX_VALUE:2147483647
//Integer.MIN_VALUE:-2147483648
//Integer.SIZE: 32 bit
//Integer.BYTES: 4 bytes