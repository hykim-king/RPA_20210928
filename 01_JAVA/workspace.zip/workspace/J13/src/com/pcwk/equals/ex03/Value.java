package com.pcwk.equals.ex03;

public class Value {

	int value;
	
	public Value(int value) {
		this.value = value;
	}
	
	
}
