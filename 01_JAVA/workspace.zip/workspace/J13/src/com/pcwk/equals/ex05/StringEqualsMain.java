package com.pcwk.equals.ex05;

public class StringEqualsMain {

	public static void main(String[] args) {
		String str01=new String("청춘");
		String str02=new String("청춘");
		
		System.out.println("str01:"+str01);
		System.out.println("str02:"+str02);
		
		System.out.println(str01==str02);
		System.out.println(str01.equals(str02));
		
		System.out.println("==================================");
		Integer   int01=new Integer(20);
		Integer   int02=new Integer(20);
		
		System.out.println(int01==int02);
		System.out.println(int01.equals(int02));

	}

}
//str01:청춘
//str02:청춘
//false
//true
//==================================
//false
//true
