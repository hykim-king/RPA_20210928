package com.pcwk.equals.ex04;

public class Student  {
	long studentId;
	
	public Student(long studentId) {
		this.studentId = studentId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (studentId != other.studentId)
			return false;
		return true;
	}

	
//	@Override
//	public boolean equals(Object obj) {
//
//		//주소값으로 비교 하지 않고,Student에 멤버 값으로 비교 
//		if(null != obj && obj instanceof Student) {
//			Student objStudent = (Student) obj;
//			return this.studentId == objStudent.studentId;
//		}else {
//			return false;
//		}
//		
//	}
	
}
