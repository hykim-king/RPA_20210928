package com.pcwk.equals.ex03;

public class ValueMain {

	public static void main(String[] args) {
		// 두 인스턴스의 주소 값을 비교하여 true/false를 반환												

		Value v01=new Value(10);
		Value v02=new Value(10);
		/* Object 클래스에 equals원형
		 * 
		 * public boolean equals(Object obj) {
        	return (this == obj);
    		}
    	 *	
		 */
		System.out.println("v01"+v01);
		System.out.println("v02"+v02);

		if(v01.equals(v02)) {
			System.out.println("v01과 v02는 같다.");
		}else {
			System.out.println("v01과 v02는 다르다.");
		}
		
		//주소를 동일 하게 처리
		v01 =v02;
		System.out.println("v01"+v01);
		System.out.println("v02"+v02);		

		if(v01.equals(v02)) {
			System.out.println("v01과 v02는 같다.");
		}else {
			System.out.println("v01과 v02는 다르다.");
		}		
	}

}
//v01com.pcwk.equals.ex03.Value@15db9742
//v02com.pcwk.equals.ex03.Value@6d06d69c
//v01과 v02는 다르다.
//v01com.pcwk.equals.ex03.Value@6d06d69c
//v02com.pcwk.equals.ex03.Value@6d06d69c
//v01과 v02는 같다.