package com.pcwk.equals.ex06.alone;

public class MyDateMain {

	public static void main(String[] args) {
		MyDate  date01=new MyDate(19, 10, 2021);
		MyDate  date02=new MyDate(19, 10, 2021);
		
		System.out.println(date01.equals(date02));

	}

}
