package com.pcwk.equals.ex04;

public class StudentMain {

	public static void main(String[] args) {
		Student std01=new Student(123456789L);
		Student std02=new Student(123456789L);
		
		if( std01==std02) {//주소로 비교
			System.out.println("주소가 같다.");
		}else {
			System.out.println("주소가 다르다.");
		}
		
		
		if( std01.equals(std02)) {//주소로 비교
			System.out.println("같다.");
		}else {
			System.out.println("다르다.");
		}
	}

}
