package com.pcwk.eclass.ex13;

public class ClassMain {

	public static void main(String[] args) throws ClassNotFoundException {
		Person person = new Person();
		
        //1. Object클래스의 getClass()							
		Class pClass01 = person.getClass();
		//com.pcwk.eclass.ex13.Person
		System.out.println(pClass01.getName());
		
		//2. 클래스 파일 이름을 Class변수에 직접 대입하기													
		Class pClass02 = Person.class;
		System.out.println(pClass02.getName());
		
		//3. Class.forName("클래스 이름")메서드 사용
		Class pClass03 = Class.forName("com.pcwk.eclass.ex13.Person");
		System.out.println(pClass03.getName());
	}

}
//com.pcwk.eclass.ex13.Person
//com.pcwk.eclass.ex13.Person
//com.pcwk.eclass.ex13.Person