package com.pcwk.eclass.ex14.alone;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PersonClassMain {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Class strClass = Class.forName("com.pcwk.eclass.ex14.alone.Person");
		
		//Object Person으로 casting
		//Class클래스의 newInstance() 메서드로 생성하기
		Person person = (Person) strClass.newInstance();
		//
		System.out.println("Person.age:"+person.getAge());
		//com.pcwk.eclass.ex14.alone.Person@15db9742
		System.out.println(person);
		
		//모든 생성자 가져 오기
		Constructor[] conArray = strClass.getConstructors();
		System.out.println(conArray.length);
		for(Constructor c :conArray) {
			System.out.println(c);
		}
		
		System.out.println("==================================");
		//모든 멤버변수
		Field[]  memberArray = strClass.getFields();
		for(Field f   :memberArray) {
			System.out.println(f);
		}
		System.out.println("==================================");
		
		//모든 메서드
		Method[] methodArray = strClass.getMethods();
		for(Method m  :methodArray) {
			System.out.println(m);
		}

	}

}
