package com.pcwk.ex12.stringbuilder;

public class StringBuilderMain {

	public static void main(String[] args) {
		//char 배열크기가 16개인 배열 생성.
		StringBuilder  sb=new StringBuilder();
		System.out.println(sb.capacity());
		sb.append("Select name, col ");
		sb.append("From tab ");
		System.out.println(sb.capacity());//담을 수 있는 크기 
		
		
		System.out.println("sb.toString()\n"+sb.toString());

	}

}
