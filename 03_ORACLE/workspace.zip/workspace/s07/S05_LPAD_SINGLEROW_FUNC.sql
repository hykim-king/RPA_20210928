col ename FOR a18
col "LPAD" FOR a10
SELECT ename,
       LPAD(ename,9,'123456789') "LPAD"
FROM emp
WHERE deptno = 10
;