col name for a20
col tel for a15
col "AREA_CODE" for a10
SELECT name,
       tel,
	   SUBSTR(tel,1,INSTR(tel,')')-1) "AREA_CODE"
FROM student
WHERE deptno1 = 201
;
NAME                 TEL             AREA_CODE
-------------------- --------------- ----------
Demi Moore           02)6255-9875    02)
Macaulay Culkin      02)312-9838     02)
Wesley Snipes        053)736-4981    053)
Steve Martin         02)6175-3945    02)
Sean Connery         02)381-5440     02)
Christian Slater     031)345-5677    031)

6 행이 선택되었습니다.
