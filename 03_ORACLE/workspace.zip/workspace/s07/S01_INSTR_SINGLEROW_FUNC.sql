--INSTR()													
--		주어진 문자열이나 컬럼에서 특정 글자의 위치를 찾아주는 함수.											
--		문  법: INSTR(‘문자열’ 또는 컬럼 , 찾는 글자 , 시작위치 , 몇번째인지(기본값은 1) )											
--SELECT 'A-B-C-D',
--       INSTR('A-B-C-D','-',1,3) "INSTR"
--FROM dual
--;
--'A-B-C-D'           INSTR
---------------- ----------
--A-B-C-D                 6


--SELECT 'A-B-C-D',
--       INSTR('A-B-C-D','-',3,1) "INSTR"
--FROM dual
--;
--'A-B-C-D'           INSTR
---------------- ----------
--A-B-C-D                 4

SELECT 'A-B-C-D',
       INSTR('A-B-C-D','-',-1,3) "INSTR"
FROM dual
;  

--오른쪽 1번째 부터 '-' 3번째 나오는 위치 RETURN
--'A-B-C-D'           INSTR
---------------- ----------
--A-B-C-D                 2