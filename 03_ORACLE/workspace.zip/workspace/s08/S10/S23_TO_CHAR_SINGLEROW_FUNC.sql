SELECT SYSDATE,
       TO_CHAR(SYSDATE,'YYYY') "YYYY",
	   TO_CHAR(SYSDATE,'RRRR') "RRRR",
	   TO_CHAR(SYSDATE,'YY') "YY",
	   TO_CHAR(SYSDATE,'RR') "RR",
	   TO_CHAR(SYSDATE,'YEAR') "YEAR"
FROM dual
;
SYSDATE             YYYY     RRRR     YY   RR   YEAR
------------------- -------- -------- ---- ---- ------------------------------------------------------------------------------------
2021-11-26:14:06:34 2021     2021     21   21   TWENTY TWENTY-ONE