--SYSDATE
--서버의 시간을 함부로 바꾸면 안된다.
--SELECT SYSDATE
--FROM dual
--;

--임시로 현재 SESSION시간 FORMAT변경
--ALTER SESSION SET NLS_DATE_FORMAT = 'RRRR-MM-DD:HH24:MI:SS';

SELECT SYSDATE
FROM dual
;

SYSDATE
-------------------
2021-11-26:11:26:20