--아래 화면과 같이 emp 테이블에서 deptno 가 10번인 사원들의 
--이름을 총 9자리로 출력하되 오른쪽 빈자리에는 해당 자리 수에 해당되는 
--숫자가 출력되도록 하세요.
col ename for a10
col "RPAD" for a10
col "LENG" for a10
SELECT ename,
       RPAD(ename,9,SUBSTR('123456789',LENGTH(ename)+1,9)) "RPAD",
	   SUBSTR('123456789',LENGTH(ename)+1,9) "LENG"
FROM emp
WHERE deptno = 10;

ENAME      RPAD       LENG
---------- ---------- ----------
CLARK      CLARK6789  6789
KING       KING56789  56789
MILLER     MILLER789  789