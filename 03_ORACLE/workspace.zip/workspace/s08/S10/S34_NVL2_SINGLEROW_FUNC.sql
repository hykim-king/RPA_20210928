col empno for 9999
col ename for a18
col sal   for 99999
col comm  for 99999
col  "NVL2" for 99999
SELECT empno,
       ename,
	   sal,
	   comm,
	   NVL2(comm,sal+comm, sal+0) "NVL2"
FROM emp
WHERE deptno = 30
;