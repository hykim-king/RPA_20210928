SELECT SYSDATE,
       TO_CHAR(SYSDATE,'DD') "DD",
	   TO_CHAR(SYSDATE,'DAY') "DAY",
	   TO_CHAR(SYSDATE,'DDTH') "DDTH"
FROM dual
;	   

SYSDATE             DD   DAY                      DDTH
------------------- ---- ------------------------ --------
2021-11-26:14:11:41 26   금요일                   26TH