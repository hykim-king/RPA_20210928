col name for a20
col tel for a20
col "REPLACE" for a20
col "SUBSTR" for a10
SELECT name,
       tel,
	   REPLACE(tel,SUBSTR(tel,5,3),'***') "REPLACE",
	   SUBSTR(tel,5,3) "SUBSTR"
FROM student
WHERE deptno1 = 102
;
NAME                 TEL                  REPLACE              SUBSTR
-------------------- -------------------- -------------------- ----------
Rene Russo           051)426-1700         051)***-1700         426
Nicholas Cage        051)418-9627         051)***-9627         418
Tim Robbins          055)488-2998         055)***-2998         488
Charlie Sheen        055)423-9870         055)***-9870         423