--TO_DATE()																	
--	날짜가 아닌 날짜처럼 생긴 문자를 날짜로 바꿔주는 함수																
--		TO_DATE('날짜처럼 생긴 문자')															

--ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
SELECT TO_DATE('2021-05-30')
FROM dual
;
TO_DATE('2
----------
2021-05-30