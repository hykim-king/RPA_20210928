SELECT SYSDATE,
       TO_CHAR(SYSDATE,'MM') "MM",
	   TO_CHAR(SYSDATE,'MON') "MON",
	   TO_CHAR(SYSDATE,'MONTH') "MONTH"
FROM dual
;	   
SYSDATE             MM   MON              MONTH
------------------- ---- ---------------- ----------------
2021-11-26:14:09:10 11   11월             11월