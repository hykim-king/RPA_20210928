col name for a20
col tel for a20
col "REPLACE" for a20
col "SUBSTR" for a10
col "INSTR" for 99999
SELECT name,
       tel,
	   REPLACE(tel,SUBSTR(tel,INSTR(tel,'-')+1,4),'****') "REPLACE",
	   SUBSTR(tel,INSTR(tel,'-')+1,4) "SUBSTR",
	   INSTR(tel,'-') "INSTR"
FROM student
WHERE deptno1 = 101
;
NAME                 TEL                  REPLACE              SUBSTR      INSTR
-------------------- -------------------- -------------------- ---------- ------
James Seo            055)381-2158         055)381-****         2158            8
Billy Crystal        055)333-6328         055)333-****         6328            8
Richard Dreyfus      02)6788-4861         02)6788-****         4861            8
Danny Devito         055)278-3649         055)278-****         3649            8