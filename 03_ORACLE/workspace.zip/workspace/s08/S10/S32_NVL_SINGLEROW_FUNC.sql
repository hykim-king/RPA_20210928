

SELECT ename,
       comm,
	   comm+100,
	   NVL(comm,0)+100,
	   NVL(comm,10),
	   deptno
FROM emp
WHERE deptno = 30
;
ENAME               COMM   COMM+100 NVL(COMM,0)+100     DEPTNO
----------------- ------ ---------- --------------- ----------
ALLEN                300        400             400        300
WARD                 500        600             600        500
MARTIN              1400       1500            1500       1400
BLAKE                                           100         10
TURNER                 0        100             100          0
JAMES                                           100         10

6 행이 선택되었습니다.