COL empno FOR 99999
COL ename FOR A17
COL "hiredate" FOR A10
COL comm FOR 
COL "sal" FOR A10
COL "15% up" FOR A10
SELECT empno,
       ename,
	   TO_CHAR(hiredate,'YYYY-MM-DD') "hiredate",
	   TO_CHAR((sal*12)+comm,'$999,999') "sal",
	   TO_CHAR(((sal*12)+comm )*1.15,'$999,999') "15% up",
	   comm
FROM emp
WHERE comm IS NOT NULL
;
