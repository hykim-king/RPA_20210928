--TO_NUMBER()																	
--	숫자가 아닌 숫자처럼 생긴 문자를 숫자로 바꾸어 주는 함수																
--		TO_NUMBER('숫자처럼 생긴 문자')															

--SELECT TO_NUMBER('5')
--FROM dual;

--SELECT TO_NUMBER('A')
--FROM dual;
--1행에 오류:
--ORA-01722: 수치가 부적합합니다

--SELECT ASCII('A')
--FROM dual;

--ASCII('A')
------------
--        65

--ASCII코드를 문자로 
SELECT CHR(65)
FROM dual;

CH
--
A