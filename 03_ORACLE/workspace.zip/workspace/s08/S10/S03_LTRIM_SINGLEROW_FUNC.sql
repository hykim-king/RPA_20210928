--LTRIM()
--문  법: LTRIM(‘문자열’ 또는 컬럼명 , ‘제거할 문자’ )
col ename for a10
col "LRTIM" for a10
SELECT ename,
       LTRIM(ename,'C') "LRTIM"
FROM emp
WHERE deptno = 10;

ENAME      LRTIM
---------- ----------
CLARK      LARK
KING       KING
MILLER     MILLER