--LAST_DAY(): 주어진 날짜가 속한 달의 가장 마지막 날을 출력
--이번달 까지는 30% 할인 적용한 가격으로 처리.

SELECT SYSDATE,
       LAST_DAY(SYSDATE)
FROM dual
;

SYSDATE  LAST_DAY
-------- --------
21/11/26 21/11/30