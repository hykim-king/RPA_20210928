--EXTRACT : 날짜에서 년, 월, 일 추출
SELECT ename,
       hiredate,
	   EXTRACT(YEAR FROM hiredate) as "h_year",
	   EXTRACT(MONTH FROM hiredate) as "h_month",
	   EXTRACT(DAY FROM hiredate) as "h_day"
FROM emp
;
ENAME                HIREDATE                h_year    h_month      h_day
-------------------- ------------------- ---------- ---------- ----------
SMITH                1980-12-17:00:00:00       1980         12         17
ALLEN                1981-02-20:00:00:00       1981          2         20
WARD                 1981-02-22:00:00:00       1981          2         22
JONES                1981-04-02:00:00:00       1981          4          2
MARTIN               1981-09-28:00:00:00       1981          9         28
BLAKE                1981-05-01:00:00:00       1981          5          1
CLARK                1981-06-09:00:00:00       1981          6          9
KING                 1981-11-17:00:00:00       1981         11         17
TURNER               1981-09-08:00:00:00       1981          9          8
JAMES                1981-12-03:00:00:00       1981         12          3
FORD                 1981-12-03:00:00:00       1981         12          3
MILLER               1982-01-23:00:00:00       1982          1         23