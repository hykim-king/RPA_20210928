--DESC professor;
SELECT profno,
       name,
	   pay,
	   bonus,
	   TO_CHAR(pay*12+NVL(bonus,0),'999,999') "TOTAL"
FROM professor
WHERE deptno =201
;
    PROFNO NAME            PAY        BONUS      TOTAL
---------- --------------- ---------- ---------- ----------------
      4001 Meryl Streep           570        130    6,970
      4002 Susan Sarandon         330               3,960