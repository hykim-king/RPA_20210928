--ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD:HH24:MI:SS';
SELECT SYSDATE,
       ROUND(SYSDATE),
	   TRUNC(SYSDATE)
FROM dual
;

SYSDATE             ROUND(SYSDATE)      TRUNC(SYSDATE)
------------------- ------------------- -------------------
2021-11-26:13:22:35 2021-11-27:00:00:00 2021-11-26:00:00:00