SELECT SYSDATE,
	   TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') "YYYY-MM-DD",
	   TO_CHAR(SYSDATE,'YYYY/MM/DD HH:MI:SS') "YYYY/MM/DD"
FROM dual
;
SYSDATE             YYYY-MM-DD             YYYY/MM/DD
------------------- --------------------- ---------------------
2021-11-26:14:18:12 2021-11-26 14:18:12    2021/11/26 02:18:12