--REPLACE()
--- 문   법: REPLACE(‘문자열’ 또는 컬럼명 , ‘문자1’ , ’문자2’)
--주어진 첫 번째 문자열이나 컬럼에서 문자1을 문자2로 치환 
col ename for a10
col "REPLACE" for a10
SELECT ename,
       REPLACE(	ename,SUBSTR(ename,1,2),'**') "REPLACE"
FROM emp
WHERE deptno = 10;
