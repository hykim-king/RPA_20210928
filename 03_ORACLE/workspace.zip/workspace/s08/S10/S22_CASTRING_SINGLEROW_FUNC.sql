--묵시적
--SELECT 11 + '13'
--FROM dual
--;
--   11+'13'
------------
--        24


SELECT 11 + TO_NUMBER('13')
FROM dual;

11+TO_NUMBER('13')
------------------
                24