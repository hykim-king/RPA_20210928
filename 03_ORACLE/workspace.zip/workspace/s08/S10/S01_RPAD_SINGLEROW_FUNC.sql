--RPAD()함수
-- 문  법: RPAD(‘문자열’ 또는 컬럼명, 자리수 , ‘채울문자’ )
--예) emp 테이블에서 아래와 같이 deptno 가 10번인 사원들의 ename 을 
--     10자리로 출력하되 오른쪽 빈자리에는 ‘-’ 로 채우세요.
col ename for a10
col "RPAD" for a10
SELECT ename,
       RPAD(ename,10,'-') "RPAD"
FROM emp
WHERE deptno = 10;

ENAME      RPAD
---------- ----------
CLARK      CLARK-----
KING       KING------
MILLER     MILLER----