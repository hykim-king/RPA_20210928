--RTRIM()
--문  법: RTRIM(‘문자열’ 또는 컬럼명 , ‘제거할 문자’ )
col ename for a10
col "RTRIM" for a10
SELECT ename,
       RTRIM(ename,'R') "RTRIM"
FROM emp
WHERE deptno = 10;

ENAME      RTRIM
---------- ----------
CLARK      CLARK
KING       KING
MILLER     MILLE