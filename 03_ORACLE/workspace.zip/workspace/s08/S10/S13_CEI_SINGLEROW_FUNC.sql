--CEIL : PAGING에 사용, GROUP에 사용된다.
SELECT ROWNUM,
       ename,
	   CEIL(ROWNUM/3) 
FROM emp
;

--    ROWNUM ENAME      CEIL(ROWNUM/3)
------------ ---------- --------------
--         1 SMITH                   1
--         2 ALLEN                   1
--         3 WARD                    1
--         4 JONES                   2
--         5 MARTIN                  2
--         6 BLAKE                   2
--         7 CLARK                   3
--         8 KING                    3
--         9 TURNER                  3
--        10 JAMES                   4
--        11 FORD                    4
--        12 MILLER                  4
--
--12 행이 선택되었습니다.