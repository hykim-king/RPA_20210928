--NEXT_DAY: 주어진 날짜를 기준으로 돌아오는 가장 최근 요일
--WINDOWS:NEXT_DAY(SYSDATE,'월')
--UNIX:NEXT_DAY(SYSDATE,'MON')
SELECT SYSDATE,
       NEXT_DAY(SYSDATE,'화')
FROM dual;

SYSDATE  NEXT_DAY
-------- --------
21/11/26 21/11/30