create or replace NONEDITIONABLE PACKAGE p_board --패키지 선언부
AS
   PROCEDURE do_insert(board_id NUMBER,
                       title VARCHAR2,
                       contents CLOB,
                       reg_id VARCHAR2
                       ); 
                       
   PROCEDURE do_delete(board_id NUMBER);       
   
   PROCEDURE do_update(v_board_id NUMBER,
                        v_title VARCHAR2,
                        v_contents CLOB,
                        v_reg_id VARCHAR2);
   PROCEDURE do_select_one(board_id NUMBER);                        
END p_board;
/