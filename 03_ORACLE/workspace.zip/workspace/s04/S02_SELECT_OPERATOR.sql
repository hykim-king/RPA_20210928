--IN연산자: 여러 조건을 간편하게 검색하기

--emp테이블에서 부서번호 10,20인 사원들에 empno, ename, deptno
SELECT empno,
       ename,
	   deptno
FROM emp
WHERE deptno IN (10,20);
;

--16:16:06 SCOTT>@S02_SELECT_OPERATOR.sql
--
--     EMPNO ENAME                    DEPTNO
------------ -------------------- ----------
--      7369 SMITH                        20
--      7566 JONES                        20
--      7782 CLARK                        10
--      7839 KING                         10
--      7902 FORD                         20
--      7934 MILLER                       10