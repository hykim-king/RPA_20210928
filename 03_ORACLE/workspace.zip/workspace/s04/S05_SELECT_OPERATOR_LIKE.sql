--입사일이 12월이 사원
SELECT empno,
       ename,
	   sal,
	   hiredate
FROM emp
WHERE hiredate LIKE '___12%'
;
--절대로 '%,_을 먼저 쓰면 않된다.
--ex) '_1234','%자바%'

--16:33:30 SCOTT>@S05_SELECT_OPERATOR_LIKE.sql
--
--     EMPNO ENAME                       SAL HIREDATE
------------ -------------------- ---------- --------
--      7369 SMITH                       800 80/12/17
--      7900 JAMES                       950 81/12/03
--      7902 FORD                       3000 81/12/03