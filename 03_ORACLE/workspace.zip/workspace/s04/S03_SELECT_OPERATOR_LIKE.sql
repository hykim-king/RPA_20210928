--LIKE : 연산자로 비숫한 것들 모두 찾기
--LIKE와 같이 사용 가능한 연산자 %,_(Underscore)
--%: 글자수에 제한이 없고(0포함) 어떤 글자가 와도 상관없습니다.
--_(Underscore): 글자수는 한 글자만 올 수 있고 어떤 글자가 와도 상관없습니다.

SELECT empno,
       ename,
	   sal
FROM emp
WHERE ename LIKE 'A%'
--WHERE sal LIKE '1%'
ORDER BY sal
;
--16:23:57 SCOTT>@S03_SELECT_OPERATOR_LIKE.sql
--
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7369 SMITH                       800
--      7900 JAMES                       950
--      7521 WARD                       1250
--      7654 MARTIN                     1250
--      7934 MILLER                     1300
--      7844 TURNER                     1500
--      7499 ALLEN                      1600
--      7782 CLARK                      2450
--      7698 BLAKE                      2850
--      7566 JONES                      2975
--      7902 FORD                       3000
--      7839 KING                       5000
--
--12 행이 선택되었습니다.
--
--16:24:02 SCOTT>@S03_SELECT_OPERATOR_LIKE.sql
--
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7654 MARTIN                     1250
--      7521 WARD                       1250
--      7934 MILLER                     1300
--      7844 TURNER                     1500
--      7499 ALLEN                      1600