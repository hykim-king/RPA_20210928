--2000<=X<=3000
--BETWEEN A AND B
--emp테이블에서 sal 2000과 3000사이에 있는 사람들의 empno,ename,sal
--SELECT empno,
--       ename,
--	   sal
--FROM emp
--WHERE sal BETWEEN 2000 AND 3000
--ORDER BY sal
--;

SELECT empno,
       ename,
	   sal
FROM emp
WHERE sal >= 2000 
AND   sal <= 3000
ORDER BY sal
;

--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7782 CLARK                      2450
--      7698 BLAKE                      2850
--      7566 JONES                      2975
--      7902 FORD                       3000