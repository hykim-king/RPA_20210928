SELECT empno,
       ename,
	   sal,
	   hiredate
FROM emp
WHERE hiredate LIKE '80%'
;
--16:28:25 SCOTT>@S04_SELECT_OPERATOR_LIKE.sql
--
--     EMPNO ENAME                       SAL HIREDATE
------------ -------------------- ---------- --------
--      7369 SMITH                       800 80/12/17
--      7499 ALLEN                      1600 81/02/20
--      7521 WARD                       1250 81/02/22
--      7566 JONES                      2975 81/04/02
--      7654 MARTIN                     1250 81/09/28
--      7698 BLAKE                      2850 81/05/01
--      7782 CLARK                      2450 81/06/09
--      7839 KING                       5000 81/11/17
--      7844 TURNER                     1500 81/09/08
--      7900 JAMES                       950 81/12/03
--      7902 FORD                       3000 81/12/03
--      7934 MILLER                     1300 82/01/23
--
--12 행이 선택되었습니다.
--
--16:28:57 SCOTT>@S04_SELECT_OPERATOR_LIKE.sql
--
--     EMPNO ENAME                       SAL HIREDATE
------------ -------------------- ---------- --------
--      7369 SMITH                       800 80/12/17