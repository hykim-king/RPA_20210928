SELECT deptno,																		
	   name,																		
	   pay,																		
	   SUM(pay) OVER(PARTITION BY deptno ) total_pay,
	   ROUND(RATIO_TO_REPORT(pay) OVER(PARTITION BY deptno)*100,2) "RATIO_%"	   
FROM professor					
ORDER BY deptno, name														
;																		
