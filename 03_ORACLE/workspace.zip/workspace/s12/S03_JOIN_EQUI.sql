--SELECT empno,
--       ename,
--       deptno
--FROM emp;

--SELECT *
--FROM dept;

SELECT t1.ename,
       t1.deptno,
       t2.dname
FROM emp t1, dept t2
WHERE t1.deptno = t2.deptno