SETP 1. 부서번호가 10번인 사원들의 정보를 조회																				
																				
  SELECT ename,
         empno,
		 job,
		 sal
  FROM emp
  WHERE deptno = 10;


STEP 2. 임의의 3건 추출																				
						
SELECT level c1
FROM dual
CONNECT BY level <=3   
;
														
STEP 3. 카티션 곱을 사용하여 부서 번호 10번인 집합 3세트를 생성.																				
SELECT *
FROM (SELECT ename,
             empno,
             job,
             sal
      FROM emp
      WHERE deptno = 10
),(SELECT level c1
   FROM dual
   CONNECT BY level <=3)
;
ENAME              EMPNO JOB                  SAL         C1
-   - 
Tiger               1000                     3600          1
CLARK               7782 MANAGER             2450          1
KING                7839 PRESIDENT           5000          1
MILLER              7934 CLERK               1300          1
Tiger               1000                     3600          2
CLARK               7782 MANAGER             2450          2
KING                7839 PRESIDENT           5000          2
MILLER              7934 CLERK               1300          2
Tiger               1000                     3600          3
CLARK               7782 MANAGER             2450          3
KING                7839 PRESIDENT           5000          3
MILLER              7934 CLERK               1300          3

12 행이 선택되었습니다.