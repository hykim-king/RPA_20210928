--SELECT *
--FROM score
--;

--SELECT *
--FROM hakjum
--;

--ORACLE NON EQUI JOIN
--SELECT t3.name "STU_NM",
--       t1.total,
--       t2.grade
--FROM score t1, hakjum t2, student t3
--WHERE t1.total BETWEEN t2.min_point AND t2.max_point
--AND   t1.studno = t3.studno
--;

--ANSI NON EQUI JOIN
SELECT t3.name "STU_NM",
       t1.total,
       t2.grade
FROM score t1 JOIN hakjum t2
ON t1.total BETWEEN t2.min_point AND t2.max_point
JOIN student t3
ON t1.studno = t3.studno
;

STU_NM                                                            TOTAL GRADE
------------------------------------------------------------ ---------- ------
James Seo                                                            97 A+
Macaulay Culkin                                                      95 A0
Billy Crystal                                                        92 A0
Danny Devito                                                         91 A0
Richard Dreyfus                                                      89 B+
Sean Connery                                                         88 B+
Danny Glover                                                         88 B+
Nicholas Cage                                                        87 B+
Daniel Day-Lewis                                                     87 B+
Wesley Snipes                                                        86 B+
Anthony Hopkins                                                      84 B0
Sandra Bullock                                                       83 B0
Charlie Sheen                                                        83 B0
Steve Martin                                                         82 B0
Christian Slater                                                     82 B0
Micheal Keaton                                                       81 B0
Bill Murray                                                          79 C+
Rene Russo                                                           78 C+
Tim Robbins                                                          77 C+
Demi Moore                                                           62 D

20 행이 선택되었습니다.