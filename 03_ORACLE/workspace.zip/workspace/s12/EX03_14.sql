col deptno     for 9999
col name       for a21 
col pay        for 99999
col total_pay  for 999999

SELECT deptno,
       name,
	   pay,
	   SUM(pay) OVER() total_pay,
	   --ROUND(pay/SUM(pay) OVER()*100,2) "RATIO_%"
	   ROUND(RATIO_TO_REPORT(pay) OVER()*100,2) "RATIO_%"
FROM professor
ORDER BY pay DESC
;
