COL "STU_NAME" FOR A25
COL "PROF_NAME" FOR A20
COL "DEPT_NAME" FOR A32
--ORACLE EQUI Join
--SELECT t1.name "STU_NAME",
--       t3.dname "DEPT_NAME", 
--       t2.name "PROF_NAME"
--FROM student t1, professor t2, department t3
--WHERE t1.deptno1 = t3.deptno
--AND t1.profno = t2.profno
--;

--ANSI Join
SELECT t1.name "STU_NAME",
       t3.dname "DEPT_NAME", 
       t2.name "PROF_NAME"
FROM student t1 JOIN professor t2 
ON t1.profno = t2.profno 
JOIN department t3         --JOIN 테이블
ON t1.deptno1 = t3.deptno  --ON 조인조건
;
STU_NAME                  DEPT_NAME                        PROF_NAME
------------------------- -------------------------------- --------------------
James Seo                 Computer Engineering             Audie Murphy
Richard Dreyfus           Computer Engineering             Angela Bassett
Billy Crystal             Computer Engineering             Angela Bassett
Rene Russo                Multimedia Engineering           Winona Ryder
Tim Robbins               Multimedia Engineering           Winona Ryder
Nicholas Cage             Multimedia Engineering           Michelle Pfeiffer
Sandra Bullock            Software Engineering             Julia Roberts
Demi Moore                Electronic Engineering           Meryl Streep
Macaulay Culkin           Electronic Engineering           Meryl Streep
Wesley Snipes             Electronic Engineering           Susan Sarandon
Steve Martin              Electronic Engineering           Nicole Kidman
Danny Glover              Mechanical Engineering           Nicole Kidman
Micheal Keaton            Mechanical Engineering           Nicole Kidman
Daniel Day-Lewis          Library and Information science  Jodie Foster
Bill Murray               Library and Information science  Jodie Foster

15 행이 선택되었습니다.