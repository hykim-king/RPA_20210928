--ANSI EQUI Join
SELECT t1.ename,
       t1.deptno,
       t2.dname
FROM emp t1 INNER JOIN dept t2
ON   t1.deptno = t2.deptno
;
ENAME                    DEPTNO DNAME
-------------------- ---------- ----------------------------
KING                         10 ACCOUNTING
CLARK                        10 ACCOUNTING
Tiger                        10 ACCOUNTING
MILLER                       10 ACCOUNTING
FORD                         20 RESEARCH
JONES                        20 RESEARCH
SMITH                        20 RESEARCH
JAMES                        30 SALES
TURNER                       30 SALES
BLAKE                        30 SALES
WARD                         30 SALES
ALLEN                        30 SALES
Cat                          30 SALES
MARTIN                       30 SALES

14 행이 선택되었습니다.