DESC customer;
DESC gift;   
COL GNAME  FOR A25 
COL G_START  FOR 999999
COL G_END  FOR 9999999
SELECT *
FROM gift
;
--       GNO GNAME                     G_START    G_END
------------ ------------------------- ------- --------
         1 Tuna Set                        1   100000
         2 Shampoo Set                100001   200000
         3 Car wash Set               200001   300000
         4 Kitchen Supplies Set       300001   400000
         5 Mountain bike              400001   500000
         6 LCD Monitor                500001   600000
         7 Notebook                   600001   700000
         8 Wall-Mountable TV          700001   800000
         9 Drum Washing Machine       800001   900000
        10 Refrigerator               900001  1000000

10 행이 선택되었습니다.

SELECT *
FROM customer
;
--       GNO GNAME                     JUMIN                           POINT
------------ ------------------------- -------------------------- ----------
  20010001 James Seo                 7510231369824                  980000
  20010002 Mel Gibson                7502241128467                   73000
  20010003 Bruce Willis              7506152123648                  320000
  20010004 Bill Pullman              7512251063421                   65000
  20010005 Liam Neeson               7503031639826                  180000
  20010006 Samuel Jackson            7601232186327                  153000
  20010007 Ahnjihye                  7604212298371                  273000

--ANSI NONE EQUI JOIN
SELECT t1.gname,
       TO_CHAR(t1.point,'999,999') point,
	   t2.gname
FROM customer t1 JOIN gift t2
ON t1.point BETWEEN t2.g_start AND t2.g_end
;

--ORACLE NONE EQUI JOIN
SELECT t1.gname,
       TO_CHAR(t1.point,'999,999') point,
	   t2.gname
FROM customer t1, gift t2
WHERE t1.point BETWEEN t2.g_start AND t2.g_end
;

GNAME                     POINT            GNAME
------------------------- ---------------- -------------------------
Bill Pullman                65,000         Tuna Set
Mel Gibson                  73,000         Tuna Set
Michael Douglas             99,000         Tuna Set
Brad Pitt                  110,000         Shampoo Set
Samuel Jackson             153,000         Shampoo Set
Liam Neeson                180,000         Shampoo Set
Arnold Scharz              265,000         Car wash Set
Ahnjihye                   273,000         Car wash Set
Tom Hanks                  298,000         Car wash Set
Jim Carrey                 315,000         Kitchen Supplies Set
Bruce Willis               320,000         Kitchen Supplies Set
Angela Bassett             420,000         Mountain bike
Robin Williams             470,000         Mountain bike
Morgan Freeman             542,000         LCD Monitor
Jessica Lange              598,000         LCD Monitor
Winona Ryder               625,000         Notebook
Michelle Pfeiffer          670,000         Notebook
James Seo                  980,000         Refrigerator

18 행이 선택되었습니다.
--BETWEEN ->  t2.g_start<=t1.point<=t2.g_start 
SELECT t1.gname,
       TO_CHAR(t1.point,'999,999') point,
	   t2.gname
FROM customer t1, gift t2
WHERE t1.point >= t2.g_start 
AND   t1.point <=t2.g_end 
;