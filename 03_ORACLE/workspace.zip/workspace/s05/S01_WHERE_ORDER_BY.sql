--사용자에게 조건을 받아서 조건에 맞는 값 출력
SELECT empno,
       ename,
	   sal
FROM emp
WHERE empno = &empno
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7369 SMITH                       800