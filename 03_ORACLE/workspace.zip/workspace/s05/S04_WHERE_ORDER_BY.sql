SELECT ename,
       sal,
	   hiredate,
	   deptno
FROM emp
ORDER BY 4 ASC, 2 DESC  --SELECT LIST에 나오는 순서로 ORDER BY
;
--ENAME                       SAL HIREDATE     DEPTNO
---------------------- ---------- -------- ----------
--KING                       5000 81/11/17         10
--CLARK                      2450 81/06/09         10
--MILLER                     1300 82/01/23         10
--FORD                       3000 81/12/03         20
--JONES                      2975 81/04/02         20
--SMITH                       800 80/12/17         20
--BLAKE                      2850 81/05/01         30
--ALLEN                      1600 81/02/20         30
--TURNER                     1500 81/09/08         30
--WARD                       1250 81/02/22         30
--MARTIN                     1250 81/09/28         30
--JAMES                       950 81/12/03         30
--
--12 행이 선택되었습니다.