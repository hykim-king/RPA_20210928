SELECT studno,
       name
FROM student
WHERE deptno1= 101
INTERSECT
SELECT studno,
       name
FROM student
WHERE deptno2= 201
;
--교집합
--    STUDNO NAME
------------ ------------------------------------------------------------
--      9411 James Seo