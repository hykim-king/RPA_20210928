--SUBSTR()
--문  법: SUBSTR(‘문자열’ 또는 컬럼명 , 1 , 4) 
COL "SUBSTR(3,2)" FOR A12
COL "SUBSTR(-3,2)" FOR A15
COL "SUBSTR(-3,4)" FOR A12
SELECT SUBSTR('abcde',3,2) "SUBSTR(3,2)",
       SUBSTR('abcde',-3,2) "SUBSTR(-3,2)",
	   SUBSTR('abcde',-3,4) "SUBSTR(-3,4)"
FROM dual
;

-- 시작이 '-'이면 오른쪽 부터 COUNT
-- 시작이 '+'이면 왼른쪽 부터 COUNT

--16:40:29 SCOTT>@S05_SINGLE_FUNC_SUBSTR.sql
--
--SUBSTR(3,2)  SUBSTR(-3,2)    SUBSTR(-3,4)
-------------- --------------- ------------
--cd           cd              cde