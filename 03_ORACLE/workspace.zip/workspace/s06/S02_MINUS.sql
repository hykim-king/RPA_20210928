SELECT empno,
       ename,
	   sal
FROM emp
UNION 
SELECT empno,
       sal,
       ename
FROM emp
WHERE sal > 2500
;

--16:09:09 SCOTT>@S02_MINUS.sql
--SELECT empno,
--*
--1행에 오류:
--ORA-01789: 질의 블록은 부정확한 수의 결과 열을 가지고 있습니다.
--
--
--16:09:53 SCOTT>@S02_MINUS.sql
--       ename,
--       *
--2행에 오류:
--ORA-01790: 대응하는 식과 같은 데이터 유형이어야 합니다