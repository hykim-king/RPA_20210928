--한글의 BYTE는 오라클 설정(ENCODING)에 따라 
--다르다.
SELECT '이상무' "name",
       LENGTH('이상무') "LENGTH",
	   LENGTHB('이상무') "LENGTHB"
FROM dual;
name                   LENGTH    LENGTHB
------------------ ---------- ----------
이상무                      3          9  