--LENGTH/LENGTHB : 입력된 문자열의 길이(바이트수)를 계산
SELECT ename,
       LENGTH(ename) "length",
	   LENGTHB(ename) "lengthb"
FROM emp
WHERE deptno = 20
;
--ascii코드는 length=lengthb동일

ENAME                    length    lengthb
-------------------- ---------- ----------
SMITH                         5          5
JONES                         5          5
FORD                          4          4