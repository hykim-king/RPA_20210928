--Student 테이블에서 jumin 컬럼을 사용해서 1 전공이 101번인 
--학생들의 이름과태어난 월일 , 생일 하루 전 날짜를 출력하세요.
COL name FOR A20
COL jumin FOR 9999999999999
COL "MM_DD" FOR 9999
COL "Birth-1" FOR 9999
SELECT name,
       jumin,
	   SUBSTR(jumin,3,4) "MM_DD",
	   SUBSTR(jumin,3,4)-1 "Birth-1"
FROM student
WHERE deptno1 =101
;
--NAME                 JUMIN                      MM_DD                            Birth-1
---------------------- -------------------------- -------------------------------- -------
--James Seo            7510231901813              1023                                1022
--Billy Crystal        7601232186327              0123                                 122
--Richard Dreyfus      7711291186223              1129                                1128
--Danny Devito         7808192157498              0819                                 818