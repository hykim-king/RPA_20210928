--표현식 안에 홑따옴표(') 있을 경우


--1. 'it ''s deptno: '
--SELECT dname, 
--       'it ''s deptno: ',
--	   deptno 
--FROM dept
--;
--NAME          'IT''SDEPTNO:'               DEPTNO
---------------- ---------------------------- ------
--ACCOUNTING     it 's deptno:                    10
--RESEARCH       it 's deptno:                    20
--SALES          it 's deptno:                    30
--OPERATIONS     it 's deptno:                    40

--2. q'[ 문장을 기록]'
SELECT dname, 
       q'[it 's deptno:]' ,
	   deptno 
FROM dept
;

--DNAME          Q'[IT'SDEPTNO:]'           DEPTNO
---------------- -------------------------- ------
--ACCOUNTING     it 's deptno:                  10
--RESEARCH       it 's deptno:                  20
--SALES          it 's deptno:                  30
--OPERATIONS     it 's deptno:                  40