DESC dept;

SET LINE 200
SET PAGESIZE 50
COL DEPTNO FOR 9999
COL DNAME  FOR a14
COL LOC    FOR a13
SELECT *
FROM dept
;
--15:44:34 SCOTT>@S01_SELECT.sql
-- 이름                                                  널?      유형
-- ----------------------------------------------------- -------- ------------------------------------
-- DEPTNO                                                NOT NULL NUMBER(2)
-- DNAME                                                          VARCHAR2(14)
-- LOC                                                            VARCHAR2(13)
--
--15:44:39 SCOTT>@S01_SELECT.sql
--
--DEPTNO DNAME          LOC
-------- -------------- -------------
--    10 ACCOUNTING     NEW YORK
--    20 RESEARCH       DALLAS
--    30 SALES          CHICAGO
--    40 OPERATIONS     BOSTON