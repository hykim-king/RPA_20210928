SET  LINE 80
SELECT name || q'['s ID : ]' || id || ', WEIGHT is ' || weight ||'Kg'  "ID AND WEIGHT"
FROM student
;	   

--ID AND WEIGHT
----------------------------------------------------------------------------------
--James Seo's ID : 75true, WEIGHT is 72Kg
--Rene Russo's ID : Russo, WEIGHT is 64Kg
--Sandra Bullock's ID : Bullock, WEIGHT is 52Kg
--Demi Moore's ID : Moore, WEIGHT is 83Kg
--Danny Glover's ID : Glover, WEIGHT is 70Kg
--Billy Crystal's ID : Crystal, WEIGHT is 48Kg
--Nicholas Cage's ID : Cage, WEIGHT is 42Kg
--Micheal Keaton's ID : Keaton, WEIGHT is 55Kg
--Bill Murray's ID : Murray, WEIGHT is 58Kg
--Macaulay Culkin's ID : Culkin, WEIGHT is 54Kg
--Richard Dreyfus's ID : Dreyfus, WEIGHT is 72Kg
--Tim Robbins's ID : Robbins, WEIGHT is 70Kg
--Wesley Snipes's ID : Snipes, WEIGHT is 82Kg
--Steve Martin's ID : Martin, WEIGHT is 51Kg
--Daniel Day-Lewis's ID : Day-Lewis, WEIGHT is 62Kg
--Danny Devito's ID : Devito, WEIGHT is 48Kg
--Sean Connery's ID : Connery, WEIGHT is 63Kg
--Christian Slater's ID : Slater, WEIGHT is 69Kg
--Charlie Sheen's ID : Sheen, WEIGHT is 81Kg
--Anthony Hopkins's ID : Hopkins, WEIGHT is 51Kg
--
--20 행이 선택되었습니다.