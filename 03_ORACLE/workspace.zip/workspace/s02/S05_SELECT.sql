--DISTINCT 명령어 :  중복된 값을 제거하거 출력 하기
--SELECT deptno
--FROM emp
--;
--DEPTNO
--------
--    20
--    30
--    30
--    20
--    30
--    30
--    10
--    10
--    30
--    30
--    20
--    10
--
--12 행이 선택되었습니다.

--SELECT DISTINCT deptno
--FROM emp
--;
--DEPTNO
--------
--    30
--    10
--    20

--컬럼의 조합에서 유일한 데이터를 출력.
--SELECT 키워드 뒤에 사용해야 합니다.
--불필요한 DISTINCT 금지!
SELECT DISTINCT job,  ename
FROM emp
ORDER BY 1,2
;
--JOB                ENAME
-------------------- --------------------
--ANALYST            FORD
--CLERK              JAMES
--CLERK              MILLER
--CLERK              SMITH
--MANAGER            BLAKE
--MANAGER            CLARK
--MANAGER            JONES
--PRESIDENT          KING
--SALESMAN           ALLEN
--SALESMAN           MARTIN
--SALESMAN           TURNER
--SALESMAN           WARD
--
--12 행이 선택되었습니다.