--연결 연산자(Concatenation)로 컬럼을 붙여서 출력하기

--SELECT ename,
--       job
--FROM emp
--;
--ENAME                JOB
---------------------- ------------------
--SMITH                CLERK
--ALLEN                SALESMAN
--WARD                 SALESMAN
--JONES                MANAGER
--MARTIN               SALESMAN
--BLAKE                MANAGER
--CLARK                MANAGER
--KING                 PRESIDENT
--TURNER               SALESMAN
--JAMES                CLERK
--FORD                 ANALYST
--MILLER               CLERK
--
--12 행이 선택되었습니다.

SELECT ename || ' ''s job is ' || job
       job
FROM emp
;

--JOB
--------------------------------------------------------------
--SMITH 's job is CLERK
--ALLEN 's job is SALESMAN
--WARD 's job is SALESMAN
--JONES 's job is MANAGER
--MARTIN 's job is SALESMAN
--BLAKE 's job is MANAGER
--CLARK 's job is MANAGER
--KING 's job is PRESIDENT
--TURNER 's job is SALESMAN
--JAMES 's job is CLERK
--FORD 's job is ANALYST
--MILLER 's job is CLERK
--
--12 행이 선택되었습니다.