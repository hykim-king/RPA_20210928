--SELECT 명령에 표현식(Expression)을 사용하여 출력,리터럴(literal)
SET pagesize 50
SELECT name, 'good morning!' "Good morning"
FROM professor
;
--NAME                                     Good morning
------------------------------------------ --------------------------
--Audie Murphy                             good morning!
--Angela Bassett                           good morning!
--Jessica Lange                            good morning!
--Winona Ryder                             good morning!
--Michelle Pfeiffer                        good morning!
--Whoopi Goldberg                          good morning!
--Emma Thompson                            good morning!
--Julia Roberts                            good morning!
--Sharon Stone                             good morning!
--Meryl Streep                             good morning!
--Susan Sarandon                           good morning!
--Nicole Kidman                            good morning!
--Holly Hunter                             good morning!
--Meg Ryan                                 good morning!
--Andie Macdowell                          good morning!
--Jodie Foster                             good morning!
--
--16 행이 선택되었습니다.