CREATE TABLE dept5						
AS						
SELECT *						
FROM dept2
WHERE 1=2
;				


SELECT *
FROM dept5;