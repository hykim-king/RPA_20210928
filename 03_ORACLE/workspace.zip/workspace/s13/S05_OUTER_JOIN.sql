COL deptno  FOR 9999
COL dname  FOR a15
COL loc    FOR a15
COL empno  FOR 99999
COL ename  FOR a15
COL sal     FOR 999999

SELECT t1.deptno,
       t1.dname,
       t1.loc,
       t2.empno,
       t2.ename,
       t2.sal
FROM dept t1, emp t2
WHERE t1.deptno = t2.deptno(+)
AND   t2.deptno(+) = 20
ORDER BY 1
;
--outer join 조건에 (+)연사자 누락: 일반조인
--WHERE t1.deptno = t2.deptno(+),
--AND   t2.deptno = 20
DEPTNO DNAME           LOC              EMPNO ENAME               SAL
------ --------------- --------------- ------ --------------- -------
    20 RESEARCH        DALLAS            7369 SMITH               800
    20 RESEARCH        DALLAS            7566 JONES              2975
    20 RESEARCH        DALLAS            7902 FORD               3000

09:48:20 SCOTT>@S05_OUTER_JOIN.sql
--WHERE t1.deptno = t2.deptno(+),
--AND   t2.deptno(+) = 20
DEPTNO DNAME           LOC              EMPNO ENAME               SAL
------ --------------- --------------- ------ --------------- -------
    10 ACCOUNTING      NEW YORK
    20 RESEARCH        DALLAS            7369 SMITH               800
    20 RESEARCH        DALLAS            7902 FORD               3000
    20 RESEARCH        DALLAS            7566 JONES              2975
    30 SALES           CHICAGO
    40 OPERATIONS      BOSTON

6 행이 선택되었습니다.