COL "STU_NAME" FOR  A23
COL "PROF_NAME" FOR  A23

--oracle outer join
--where조건에 데이터가 없는 쪽에(+) 사용
--SELECT t1.name "STU_NAME",
--       t2.name "PROF_NAME"
--FROM student t1, professor t2   
--WHERE t1.profno = t2.profno(+)
--;

--ansi outer join
--데이터가 있는 쪽을 가리킨다.
SELECT t1.name "STU_NAME",
       t2.name "PROF_NAME"
FROM student t1 LEFT OUTER JOIN professor t2   
ON t1.profno = t2.profno(+)
;

STU_NAME                PROF_NAME
----------------------- -----------------------
James Seo               Audie Murphy
Billy Crystal           Angela Bassett
Richard Dreyfus         Angela Bassett
Rene Russo              Winona Ryder
Tim Robbins             Winona Ryder
Nicholas Cage           Michelle Pfeiffer
Sandra Bullock          Julia Roberts
Demi Moore              Meryl Streep
Macaulay Culkin         Meryl Streep
Wesley Snipes           Susan Sarandon
Danny Glover            Nicole Kidman
Micheal Keaton          Nicole Kidman
Steve Martin            Nicole Kidman
Bill Murray             Jodie Foster
Daniel Day-Lewis        Jodie Foster
Danny Devito
Sean Connery
Christian Slater
Charlie Sheen
Anthony Hopkins

20 행이 선택되었습니다.