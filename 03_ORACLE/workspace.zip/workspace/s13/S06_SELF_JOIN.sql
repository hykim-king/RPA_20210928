--SELECT empno,
--       ename,
--       mgr
--FROM emp 
--;
col "ENAME"    for a23
col "MGR_NAME" for a23
--ansi join
SELECT t1.ename "ENAME",
       t2.ename "MGR_NAME"
FROM emp t1 JOIN emp t2
ON t1.mgr = t2.empno
;
--ENAME                   MGR_NAME
------------------------- -----------------------
--FORD                    JONES
--ALLEN                   BLAKE
--WARD                    BLAKE
--MARTIN                  BLAKE
--TURNER                  BLAKE
--JAMES                   BLAKE
--MILLER                  CLARK
--JONES                   KING
--BLAKE                   KING
--CLARK                   KING
--SMITH                   FORD
--
--11 행이 선택되었습니다.

--oracle join
--SELECT t1.ename "ENAME",
--       t2.ename "MGR_NAME"
--FROM emp t1, emp t2
--WHERE t1.mgr = t2.empno
--;