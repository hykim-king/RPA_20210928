--모든 컬럼 다 복사
--CREATE TABLE dept3
--AS
--SELECT *
--FROM dept2;


DESC dept3;

SELECT COUNT(*) FROM dept3;
SELECT COUNT(*) FROM dept2;