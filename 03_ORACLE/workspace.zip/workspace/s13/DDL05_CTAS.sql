--특정 컬럼 만 복사
CREATE TABLE dept4
AS
SELECT dcode,dname
FROM dept2;

DESC dept4;

SELECT *
FROM dept4;