COL "CUST_NAME" FOR a19
COL point FOR 999999
COL "GIFT_NAME" FOR a15

SELECT t1.gname "CUST_NAME",
	   t1.point,
	   t2.gname "GIFT_NAME"
FROM customer t1, gift t2
WHERE t1.point >= t2.g_start
AND   t2.gname ='Notebook'
;

--SELECT gno,gname,point
--FROM customer;


--       GNO GNAME                    POINT
------------ ------------------ ----------
--  20010001 James Seo              980000
--  20010002 Mel Gibson              73000
--  20010003 Bruce Willis           320000
--  20010004 Bill Pullman            65000
--  20010005 Liam Neeson            180000
--  20010006 Samuel Jackson         153000
--  20010007 Ahnjihye               273000
--  20010008 Jim Carrey             315000
--  20010009 Morgan Freeman         542000
--  20010010 Arnold Scharz          265000
--  20010011 Brad Pitt              110000
--  20010012 Michael Douglas         99000
--  20010013 Robin Williams         470000
--  20010014 Tom Hanks              298000
--  20010015 Angela Bassett         420000
--  20010016 Jessica Lange          598000
--  20010017 Winona Ryder           625000
--  20010018 Michelle Pfeiffer      670000
  
--SELECT *
--FROM gift;
--
--       GNO GNAME                     G_START G_END
--        
------------ ---------------------- ---------- ----------
--         1 Tuna Set                        1     100000
--         2 Shampoo Set                100001     200000
--         3 Car wash Set               200001     300000
--         4 Kitchen Supplies Set       300001     400000
--         5 Mountain bike              400001     500000
--         6 LCD Monitor                500001     600000
--         7 Notebook                   600001     700000
--         8 Wall-Mountable TV          700001     800000
--         9 Drum Washing Machine       800001     900000
--        10 Refrigerator               900001    1000000