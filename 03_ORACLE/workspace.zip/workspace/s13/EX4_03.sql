
col name               for a19
col "CURR_POSITION"    for a30
col "BE_POSITION"    for a30


SELECT TRUNC( (SYSDATE-t1.birthday)/365 ) AGE,
       t1.name
FROM emp2 t1
ORDER BY 1;

11:14:20 SCOTT>@EX4_03.sql

       AGE NAME
---------- -------------------
        36 Jack Nicholson
        38 Denzel Washington
        39 Richard Gere
        40 Clint Eastwood
        40 Kevin Costner
        41 Robert De Niro
        41 Tom Cruise
        41 Harrison Ford
        41 Sly Stallone
        41 JohnTravolta
        45 Tommy Lee Jones
        45 Val Kilmer
        46 Woody Harrelson
        48 Gene Hackman
        48 AL Pacino
        49 Hugh Grant
        49 Kevin Bacon
        49 Chris O Donnell
        50 Keanu Reeves
        57 Kurt Russell

20 행이 선택되었습니다.

SELECT position,
       s_age,
       e_age
FROM p_grade
;

POSITION                                       S_AGE      E_AGE
----------------------------------------- ---------- ----------
Manager                                            0         24
Deputy Section chief                              25         28
Section head                                      29         32
Deputy department head                            33         36
Department head                                   37         40
Director                                          41         55


--oracle join
SELECT t1.name,
       TRUNC( (SYSDATE-t1.birthday)/365 ) AGE,
       t1.position "CURR_POSITION",
       t2.position "BE_POSITION"
FROM emp2 t1, p_grade t2
WHERE TRUNC( (SYSDATE-t1.birthday)/365 ) BETWEEN t2.s_age AND t2.e_age  
;

NAME                       AGE CURR_POSITION                  BE_POSITION
------------------- ---------- ------------------------------ ------------------------------
Jack Nicholson              36                                Deputy department head
Denzel Washington           38                                Department head
Richard Gere                39                                Department head
Clint Eastwood              40                                Department head
Kevin Costner               40                                Department head
Robert De Niro              41                                Director
Tom Cruise                  41                                Director
Harrison Ford               41                                Director
Sly Stallone                41                                Director
JohnTravolta                41                                Director
Tommy Lee Jones             45 Deputy department head         Director
Val Kilmer                  45 Department head                Director
Woody Harrelson             46 Section head                   Director
Gene Hackman                48 Section head                   Director
AL Pacino                   48 Department head                Director
Hugh Grant                  49 Section head                   Director
Kevin Bacon                 49 Department head                Director
Chris O'Donnell             49 Section head                   Director
Keanu Reeves                50 Deputy Section chief           Director

19 행이 선택되었습니다.