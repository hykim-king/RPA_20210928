CREATE TABLE tt02(
 no NUMBER(3,1)    DEFAULT 0,
 name VARCHAR2(10) DEFAULT 'NO Name',
 hiredate DATE     DEFAULT SYSDATE
);

14:41:15 SCOTT>DESC TT02;
 이름         널?      유형               
 ------------ -------- ----------------
 NO                    NUMBER(3,1)
 NAME                  VARCHAR2(10)
 HIREDATE              DATE
 
 INSERT INTO tt02(no) VALUES (1);
 
 SELECT * 
 FROM tt02;
 
         NO NAME                HIREDATE
---------- ------------------- --------
         1 NO Name             21/12/03