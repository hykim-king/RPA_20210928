
--10:12:39 SCOTT>DESC student;
-- 이름                                  널?      유형             
-- ----------------------------------- -------- ---------------
-- STUDNO                              NOT NULL NUMBER(4)
-- NAME                                NOT NULL VARCHAR2(30)
-- ID                                  NOT NULL VARCHAR2(20)
-- GRADE                                        NUMBER
-- JUMIN                               NOT NULL CHAR(13)
-- BIRTHDAY                                     DATE
-- TEL                                          VARCHAR2(15)
-- HEIGHT                                       NUMBER(4)
-- WEIGHT                                       NUMBER(3)
-- DEPTNO1                                      NUMBER(3)
-- DEPTNO2                                      NUMBER(3)
-- PROFNO                                       NUMBER(4)
--10:13:58 SCOTT>desc department;
-- 이름                                널?      유형
-- ----------------------------------- -------- ---------------
-- DEPTNO                              NOT NULL NUMBER(3)
-- DNAME                               NOT NULL VARCHAR2(50)
-- PART                                         NUMBER(3)
-- BUILD                                        VARCHAR2(30)
-- 
 COL "STU_NAME" FOR A21
 COL deptno1 FOR 9999
 COL "DEPT_NAME" FOR A35
 --SELECT t1.name "STU_NAME",
 --       t1.deptno1,
 --       t2.dname "DEPT_NAME"
 --FROM student t1, department t2
 --WHERE t1.deptno1 = t2.deptno
 --ORDER BY t1.studno
 --;
 
  SELECT t1.name "STU_NAME",
        t1.deptno1,
        t2.dname "DEPT_NAME"
 FROM student t1 INNER JOIN department t2
 ON  t2.deptno = t1.deptno1
 ORDER BY t1.studno
 ;
 
 STU_NAME              DEPTNO1 DEPT_NAME
--------------------- ------- -----------------------------------
James Seo                 101 Computer Engineering
Rene Russo                102 Multimedia Engineering
Sandra Bullock            103 Software Engineering
Demi Moore                201 Electronic Engineering
Danny Glover              202 Mechanical Engineering
Billy Crystal             101 Computer Engineering
Nicholas Cage             102 Multimedia Engineering
Micheal Keaton            202 Mechanical Engineering
Bill Murray               301 Library and Information science
Macaulay Culkin           201 Electronic Engineering
Richard Dreyfus           101 Computer Engineering
Tim Robbins               102 Multimedia Engineering
Wesley Snipes             201 Electronic Engineering
Steve Martin              201 Electronic Engineering
Daniel Day-Lewis          301 Library and Information science
Danny Devito              101 Computer Engineering
Sean Connery              201 Electronic Engineering
Christian Slater          201 Electronic Engineering
Charlie Sheen             102 Multimedia Engineering
Anthony Hopkins           103 Software Engineering

20 행이 선택되었습니다.