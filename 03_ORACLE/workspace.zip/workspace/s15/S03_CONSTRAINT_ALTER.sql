--new_emp2 테이블의 name 컬럼에 unique 제약조건 추가
ALTER TABLE new_emp2
ADD CONSTRAINT emp2_name_uk UNIQUE(name);