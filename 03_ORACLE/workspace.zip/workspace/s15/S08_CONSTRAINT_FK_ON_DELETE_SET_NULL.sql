--제약조건 DROP : c_test1_deptno_fk
--ALTER TABLE c_test1 DROP CONSTRAINT c_test1_deptno_fk;


--ALTER TABLE c_test1
--ADD CONSTRAINT c_test1_deptno_fk FOREIGN KEY(deptno)
--REFERENCES c_test2(no)
--ON DELETE SET NULL;  

--SELECT *
--FROM c_test1;
--
--SELECT *
--FROM c_test2;

--c_test2 부모쪽 no = 20삭제
--SELECT *
--FROM c_test2
--WHERE no = 20;

DELETE FROM  c_test2
WHERE no = 20;

SELECT *
FROM c_test1;

        NO NAME             DEPTNO
---------- ------------ ----------
         2 banana
         3 cherry               30