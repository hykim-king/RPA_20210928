CREATE TABLE new_emp2(
 no   NUMBER(4)          PRIMARY KEY,
 name VARCHAR2(20 BYTE)  NOT NULL,
 jumin VARCHAR2(13)      NOT NULL
                         UNIQUE,
 loc_code NUMBER(1)      CHECK(loc_code < 5),
 deptno VARCHAR2(6)      REFERENCES dept2(dcode) 
);
--ORACLE이 제약조건 이름을 부여
--SYSxxxxx
--테이블이 생성되었습니다.