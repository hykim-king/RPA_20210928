--* 참조키 제약 조건 설정시 주의 사항.																	
--부모 테이블 쪽에 설정되는 컬럼이 Primary Key이거나, Unique Key																	
ALTER TABLE new_emp2
ADD CONSTRAINT emp2_name_fk FOREIGN KEY(name)
REFERENCES emp2(name);

3행에 오류:
ORA-02270: 이 열목록에 대해 일치하는 고유 또는 기본 키가 없습니다.

emp2 name 컬럼에 unique key 설정
ALTER TABLE emp2
ADD CONSTRAINT emp2_name_uk9 UNIQUE(name);

name 컬럼에 unique key 설정이후 fk생성됨.
ALTER TABLE new_emp2
ADD CONSTRAINT emp2_name_fk FOREIGN KEY(name)
REFERENCES emp2(name);

--테이블이 변경되었습니다.