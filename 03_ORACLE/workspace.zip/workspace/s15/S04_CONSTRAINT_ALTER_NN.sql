--null과 not null 제약 조건 추가														
--	new_emp2 테이블의 loc_code에 not null제약 추가	
--ALTER TABLE new_emp2
--ADD CONSTRAINT emp2_loccode_nn NOT NULL(loc_code);												
--2행에 오류:
--ORA-00904: : 부적합한 식별자

ALTER TABLE new_emp2
MODIFY ( loc_code CONSTRAINT emp2_loccode_nn NOT NULL);
--테이블이 변경되었습니다.
