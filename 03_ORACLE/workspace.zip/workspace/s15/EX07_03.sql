ALTER TABLE tcons
DISABLE VALIDATE constraint tcons_jumin_uk;