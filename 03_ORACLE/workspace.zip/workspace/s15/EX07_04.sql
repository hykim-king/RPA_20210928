ENABLE VALIDATE: 데이터 모두다 검사										
(기존 데이터, 새로운 데이터 모두 검사)										


EXCEPTION TABLE생성
@C:\app\HKEDU\product\18.0.0\dbhomeXE\rdbms\admin\utlexcpt.sql


ALTER TABLE t_cons
ENABLE VALIDATE CONSTRAINT TCONS_JUMIN_UK
EXCEPTIONS  INTO exceptions