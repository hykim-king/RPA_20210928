ALTER TABLE new_emp2
ADD CONSTRAINT emp2_no_fk FOREIGN KEY(no)
REFERENCES emp2(empno);

--테이블이 변경되었습니다.