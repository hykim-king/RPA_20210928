--new_emp2 테이블에 설정되어 있는 제약 조건 조회
col owner for a15
col constraint_name for a15
col constraint_type for a15
col status for a15
SELECT owner,
       constraint_name,
	   constraint_type,
	   status
FROM user_constraints
WHERE table_name ='NEW_EMP2'  
;
--OWNER           CONSTRAINT_NAME CONSTRAINT_TYPE STATUS
----------------- --------------- --------------- ---------------
--SCOTT           SYS_C008791     R               ENABLED
--SCOTT           EMP2_NO_FK      R               ENABLED
--SCOTT           EMP2_NAME_FK    R               ENABLED
--SCOTT           SYS_C008787     C               ENABLED
--SCOTT           SYS_C008788     C               ENABLED
--SCOTT           SYS_C008786     C               ENABLED
--SCOTT           EMP2_LOCCODE_NN C               ENABLED
--SCOTT           SYS_C008789     P               ENABLED
--SCOTT           SYS_C008790     U               ENABLED
--SCOTT           EMP2_NAME_UK    U               ENABLED
--
--10 행이 선택되었습니다.
--constraint_type : 
--P : Primary KEY
--U : UNIQUE
--C : CHECK
--R : 외래키


