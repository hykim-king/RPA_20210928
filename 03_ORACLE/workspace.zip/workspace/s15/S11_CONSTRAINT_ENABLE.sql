--ENABLE NOVALIDATE: 기존 데이터는 검사하지 않고, 새로운 데이터만 검사

--ENABLE VALIDATE: 기존 데이터, 새로운 데이터 모두 검사	
--  EXCEPTIONS라는 테이블을 사용해서 에러사항을 별도로 기록

--  시간이 오래 걸리므로 업무시간에 사용 주의

--SELECT *
--FROM t_enable
--;
--"NAME" VARCHAR2(10 BYTE) CONSTRAINT "TE_NAME_NN" NOT NULL ENABLE,

--INSERT INTO t_enable VALUES (1,'AAA');
--INSERT INTO t_enable VALUES (2,'BBB');
--
--INSERT INTO t_enable VALUES (3,NULL);
--1행에 오류:
--ORA-01400: NULL을 ("SCOTT"."T_ENABLE"."NAME") 안에 삽입할 수 없습니다
--commit;

--ALTER TABLE t_enable
--DISABLE CONSTRAINT TE_NAME_NN;

--INSERT INTO t_enable VALUES (3,NULL);

--SELECT *
--FROM t_enable;

--기존 데이터는 검사하자 않음
--ALTER TABLE t_enable
--ENABLE NOVALIDATE CONSTRAINT TE_NAME_NN;


--세로운 데이터는 검사
INSERT INTO t_enable VALUES (4,NULL);
1행에 오류:
ORA-01400: NULL을 ("SCOTT"."T_ENABLE"."NAME") 안에 삽입할 수 없습니다