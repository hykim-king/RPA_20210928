SELECT deptno, AVG(NVL(sal,0))
FROM emp
HAVING AVG(NVL(sal,0)) > 2000
GROUP BY deptno 
;

--DEPTNO AVG(NVL(SAL,0))
-------- ---------------
--    10      2916.66667
--    20      2258.33333