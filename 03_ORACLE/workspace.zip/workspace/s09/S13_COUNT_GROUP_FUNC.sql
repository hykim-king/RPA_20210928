SELECT COUNT(*),
       COUNT(COMM) COMM
FROM emp;


--COUNT(*)는 NULL포함
--COUNT(COMM) NULL이 아닌 경우만 COUNT
--  COUNT(*)       COMM
------------ ----------
--        12          4