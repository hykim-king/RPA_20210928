SELECT COUNT(comm),
       SUM(comm)
FROM emp;

COUNT(COMM)  SUM(COMM)
----------- ----------
          4       2200