--3.소문자로 시작하고 공백을 포함하는 경우
--SELECT *
--FROM t_reg
--WHERE REGEXP_LIKE(text,'[a-z] ')
--;
--TEXT
----------------------
--abc 123
--abc  123


--4.소문자로 시작하고 공백을 1칸 포함하고 숫자로 끝나는
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[a-z] [0-9]')
;
--TEXT
----------------------
--abc 123