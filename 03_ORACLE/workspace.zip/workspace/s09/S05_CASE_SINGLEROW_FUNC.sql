col name for a22
col tel for a13
col "LOC" for a18
SELECT name,
       tel,	 
       CASE SUBSTR(tel,1,INSTR(tel,')',1)-1) WHEN 	'02'  THEN 'SEOUL'
	                                         WHEN 	'031' THEN 'GYEONGGI'
											 WHEN 	'051' THEN 'BUSAN'
											 WHEN 	'052' THEN 'ULSAN'
											 WHEN 	'055' THEN 'GYEONGNAM'
											 ELSE   'ETC'
       END "LOC" 
FROM student
WHERE deptno1 = 201
;

NAME                   TEL           LOC
---------------------- ------------- ------------------
Demi Moore             02)6255-9875  SEOUL
Macaulay Culkin        02)312-9838   SEOUL
Wesley Snipes          053)736-4981  ETC
Steve Martin           02)6175-3945  SEOUL
Sean Connery           02)381-5440   SEOUL
Christian Slater       031)345-5677  GYEONGGI

6 행이 선택되었습니다.