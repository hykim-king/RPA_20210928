col name for a18
col jumin for a13
col name for a15
SELECT name,
       jumin,
	   DECODE(SUBSTR(jumin,7,1),1,'MAN'
	                           ,2,'WOMAN') "Gender",
	   SUBSTR(jumin,7,1) "sub"						   
FROM student
WHERE deptno1 = 101
;

--NAME            JUMIN         Gender
----------------- ------------- ----------
--James Seo       7510231901813 MAN
--Billy Crystal   7601232186327 WOMAN
--Richard Dreyfus 7711291186223 MAN
--Danny Devito    7808192157498 WOMAN