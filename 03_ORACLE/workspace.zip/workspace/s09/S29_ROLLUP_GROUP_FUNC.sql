SELECT deptno,
       position,
	   SUM(pay),
	   COUNT(*)
FROM professor2
GROUP BY deptno,ROLLUP(position)
; 

DEPTNO POSITION               SUM(PAY)   COUNT(*)
------ -------------------- ---------- ----------
   101 instructor                  370          2
   101 a full professor            650          2
   101 assistant professor         480          2
   101                            1500          6
   102 instructor                  250          1
   102 a full professor            490          1
   102 assistant professor         350          1
   102                            1090          3
   103 instructor                  290          1
   103 a full professor            530          1
   103 assistant professor         330          1
   103                            1150          3
   201 a full professor            570          1
   201 assistant professor         330          1
   201                             900          2
   202 instructor                  260          1
   202 assistant professor         310          1
   202                             570          2
   203 a full professor            500          1
   203                             500          1
   301 instructor                  220          1
   301 assistant professor         290          1
   301                             510          2