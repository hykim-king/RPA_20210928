--1.영문 소문자가 들어가 있는 행만 출력
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[a-z]')
;
--TEXT
----------------------
--ABC123
--ABC 123
--ABC  123
--abc 123
--abc  123
--a1b2c3
--aabbcc123
--?/!@#$*&
--\~*().,
--123123
--123abc
--abc

--TEXT
----------------------
--abc 123
--abc  123
--a1b2c3
--aabbcc123
--123abc
--abc
--
--6 행이 선택되었습니다.