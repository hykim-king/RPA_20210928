--2.영문 대문자가 들어가 있는 행만 출력
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[A-Z]')
;
--TEXT
----------------------
--ABC123
--ABC 123
--ABC  123