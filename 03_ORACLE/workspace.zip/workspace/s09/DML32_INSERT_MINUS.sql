--CREATE TABLE t_minus
--(
--	no1 NUMBER,
--	no2 NUMBER(3),
--	no3 NUMBER(3,2)
--);
--15:36:13 SCOTT>@DML32_INSERT_MINUS.sql
--
--테이블이 생성되었습니다.
--DESC t_minus;

--INSERT INTO t_minus VALUES(1,1,1);
--INSERT INTO t_minus VALUES(1,1,1);

--INSERT INTO t_minus VALUES(1.1,1.1,1.1);

INSERT INTO t_minus VALUES(-1.1,-1.1,-1.1);

SELECT *
FROM t_minus;