--MAX,MIN : 정렬한 이우 최대 최소를 구한다.
SELECT MAX(sal),
       MIN(sal)
FROM emp
;

--  MAX(SAL)   MIN(SAL)
------------ ----------
--      5000        800