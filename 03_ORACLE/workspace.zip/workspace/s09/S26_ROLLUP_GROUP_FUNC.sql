--position별로 먼저 분류를 한 후 같은 deptno가 있을 경우 rollup()
--함수를 사용해서 요약한 deptno별로 출력.
COL deptno FOR 999
COL position FOR A20
COL pay FOR 99999
SELECT deptno,
       position,
	   SUM(pay),
	   COUNT(*)
FROM professor
GROUP BY position,ROLLUP(deptno)
;  
DEPTNO POSITION               SUM(PAY)   COUNT(*)
------ -------------------- ---------- ----------
   101 instructor                  270          1
   102 instructor                  250          1
   103 instructor                  290          1
   202 instructor                  260          1
   301 instructor                  220          1
       instructor                 1290          5
   101 a full professor            550          1
   102 a full professor            490          1
   103 a full professor            530          1
   201 a full professor            570          1
   203 a full professor            500          1
       a full professor           2640          5
   101 assistant professor         380          1
   102 assistant professor         350          1
   103 assistant professor         330          1
   201 assistant professor         330          1
   202 assistant professor         310          1
   301 assistant professor         290          1
       assistant professor        1990          6