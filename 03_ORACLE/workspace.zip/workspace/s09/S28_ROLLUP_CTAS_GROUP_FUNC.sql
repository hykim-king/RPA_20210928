--DROP TABLE professor2;
--
--CREATE TABLE professor2
--AS 
--SELECT deptno, position, pay
--FROM professor
--;
--
----SELECT *
----FROM professor2;
--
----DATA 추가
--INSERT INTO professor2 (deptno, position, pay)
--VALUES (101,'instructor',100);
--
--INSERT INTO professor2 (deptno, position, pay)
--VALUES (101,'a full professor',100);
--
--INSERT INTO professor2 (deptno, position, pay)
--VALUES (101,'assistant professor',100);
--
----확정
--COMMIT;
--
--SELECT *
--FROM professor2
--ORDER BY deptno, position
--;
DEPTNO POSITION                PAY
------ -------------------- ------
   101 a full professor        100
   101 a full professor        550
   101 assistant professor     100
   101 assistant professor     380
   101 instructor              270
   101 instructor              100
   102 a full professor        490
   102 assistant professor     350
   102 instructor              250
   103 a full professor        530
   103 assistant professor     330
   103 instructor              290
   201 a full professor        570
   201 assistant professor     330
   202 assistant professor     310
   202 instructor              260
   203 a full professor        500
   301 assistant professor     290
   301 instructor              220

19 행이 선택되었습니다.