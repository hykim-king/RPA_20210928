SELECT AVG(NVL(sal,0))
FROM emp
WHERE AVG(NVL(sal,0)) > 2000
;
--WHERE AVG(NVL(sal,0)) > 2000
--      *
--3행에 오류:
--ORA-00934: 그룹 함수는 허가되지 않습니다