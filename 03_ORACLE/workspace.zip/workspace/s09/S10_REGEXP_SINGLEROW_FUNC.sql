--3.영문 대문자,소문자가 들어가 있는 행만 출력
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[a-zA-Z]')
;
TEXT
--------------------
ABC123
ABC 123
ABC  123
abc 123
abc  123
a1b2c3
aabbcc123
123abc
abc