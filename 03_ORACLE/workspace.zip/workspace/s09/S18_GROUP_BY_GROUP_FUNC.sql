--부서별 평균 급여
--GROUP BY절 뒤에 오는 컬럼 값을 기준으로 먼저 모아 놓고
--SELECT절에 적혀 있는 그룹 함수를 적용.

SELECT deptno,
       AVG(NVL(sal,0)) "AVG"
FROM emp
GROUP BY deptno
;

DEPTNO        AVG
------ ----------
    30 1566.66667
    10 2916.66667
    20 2258.33333