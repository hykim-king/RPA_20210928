--desc dept2;
--INSERT INTO dept2 (dcode,dname,pdept,area)
--VALUES ('9000','temp_1','1006','temp area'); 

--입력 컬럼 생략
--INSERT INTO dept2 VALUES ('9001','temp_2','1006','Temp Area');

--특정컬럼만 입력
--INSERT INTO dept2 (dcode,dname,pdept)
--VALUES ('9002','temp_3','1006'); 


col dcode for 9999
col dname for a25
col pdept for 9999
col area for a25
SELECT dcode,dname,pdept,area
FROM dept2
;

--DCODE        DNAME                     PDEPT        AREA
-------------- ------------------------- ------------ -------------------------
--9000         temp_1                    1006         temp area
--9001         temp_2                    1006         Temp Area
--9002         temp_3                    1006
--0001         President                              Pohang Main Office
--1000         Management Support Team   0001         Seoul Branch Office
--1001         Financial Management Team 1000         Seoul Branch Office
--1002         General affairs           1000         Seoul Branch Office
--1003         Engineering division      0001         Pohang Main Office
--1004         H/W Support Team          1003         Daejeon Branch Office
--1005         S/W Support Team          1003         Kyunggi Branch Office
--1006         Business Department       0001         Pohang Main Office
--1007         Business Planning Team    1006         Pohang Main Office
--1008         Sales1 Team               1007         Busan Branch Office
--1009         Sales2 Team               1007         Kyunggi Branch Office
--1010         Sales3 Team               1007         Seoul Branch Office
--1011         Sales4 Team               1007         Ulsan Branch Office
--
--16 행이 선택되었습니다.