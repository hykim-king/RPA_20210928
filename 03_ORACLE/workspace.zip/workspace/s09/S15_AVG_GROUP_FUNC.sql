--SELECT COUNT(comm),
--       SUM(comm),
--	   AVG(comm)
--FROM emp
--;

--COUNT(COMM)  SUM(COMM)  AVG(COMM)
------------- ---------- ----------
--          4       2200        550

--전체 사원에 대한 comm평균
--SELECT COUNT(*),
--       SUM(comm),
--	   AVG(NVL(comm,0))
--FROM emp
--;
--  COUNT(*)  SUM(COMM) AVG(NVL(COMM,0))
------------ ---------- ----------------
--        12       2200       183.333333
SELECT AVG(N_COMM)
FROM (
	SELECT NVL(comm,0) N_COMM
	FROM emp
)
;

NVL(COMM,0)
-----------
          0
        300
        500
          0
       1400
          0
          0
          0
          0
          0
          0
          0

12 행이 선택되었습니다.

11:37:59 SCOTT>@S15_AVG_GROUP_FUNC.sql

AVG(N_COMM)
-----------
 183.333333