SELECT deptno,
       job,
	   AVG(NVL(sal,0)) "AVG"
FROM emp
GROUP BY deptno
;
--13:25:56 SCOTT>@S20_GROUP_BY_GROUP_FUNC.sql
--       job,
--       *
--2행에 오류:
--ORA-00979: GROUP BY 표현식이 아닙니다.