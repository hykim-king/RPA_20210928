--professor테이블에 있는 데이터 데이터를 professor3에 COPY
--CTAS

--CREATE TABLE professor3
--AS
--SELECT *
--FROM professor
--WHERE 1=2
--;


--INSERT INTO professor3_00
--SELECT *
--FROM professor
--;

SELECT * FROM professor3_00;