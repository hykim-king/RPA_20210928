col empno for 9999 
col ename for a15 
col sal for 999999 
col "LEVEL" for a15
SELECT empno,
       ename,
	   sal,
	   CASE WHEN sal BETWEEN 1    AND 1000 THEN 'LEVEL 1'
	        WHEN sal BETWEEN 1001 AND 2000 THEN 'LEVEL 2'
			WHEN sal BETWEEN 2001 AND 3000 THEN 'LEVEL 3'
			WHEN sal BETWEEN 3001 AND 4000 THEN 'LEVEL 4'
			WHEN sal >= 4001               THEN 'LEVEL 5'
	   END "LEVEL"		
FROM emp
ORDER BY sal DESC
;
EMPNO ENAME               SAL LEVEL
----- --------------- ------- ---------------
 7839 KING               5000 LEVEL 5
 7902 FORD               3000 LEVEL 3
 7566 JONES              2975 LEVEL 3
 7698 BLAKE              2850 LEVEL 3
 7782 CLARK              2450 LEVEL 3
 7499 ALLEN              1600 LEVEL 2
 7844 TURNER             1500 LEVEL 2
 7934 MILLER             1300 LEVEL 2
 7654 MARTIN             1250 LEVEL 2
 7521 WARD               1250 LEVEL 2
 7900 JAMES               950 LEVEL 1
 7369 SMITH               800 LEVEL 1

12 행이 선택되었습니다.