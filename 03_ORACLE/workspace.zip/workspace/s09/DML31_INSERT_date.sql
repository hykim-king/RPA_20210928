--날짜 데이터 입력
--DESC professor;
--날짜 데이터 FORMAT이 맞아야 입력 가능.
INSERT INTO professor ( profno,name,position,id,pay,hiredate)
VALUES (5001,'James Bond','Love_me','정교수',510,'2014-10-23');