SELECT deptno no,
	   AVG(NVL(sal,0)) "AVG"
FROM emp
GROUP BY no
;
--GROUP BY no
--         *
--4행에 오류:
--ORA-00904: "NO": 부적합한 식별자