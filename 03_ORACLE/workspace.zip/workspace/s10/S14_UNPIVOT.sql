--UNPIVOT
--CREATE TABLE unpivot
--AS
--SELECT * FROM ( SELECT deptno,job,empno 
--                FROM emp )
--PIVOT(	COUNT(empno) FOR job IN ( 'CLERK'      AS "CLERK"    
--                                 ,'SALESMAN'   AS "SALESMAN" 
--                                 ,'MANAGER'    AS "MANAGER"  
--                                 ,'PRESIDENT'  AS "PRESIDENT"
--                                 ,'ANALYST'    AS "ANALYST"
--                       )
--)
--ORDER BY deptno
--;

--DEPTNO     CLERK  SALESMAN   MANAGER PRESIDENT    ANALYST
-------- --------- --------- --------- --------- ----------
--    10         1         0         1         1          0
--    20         1         0         1         0          1
--    30         1         4         1         0          0

--13:28:48 SCOTT>desc unpivot;
-- 이름                                                  널?      유형
-- ----------------------------------------------------- -------- ------------------------------------
-- DEPTNO                                                         NUMBER(2)
-- CLERK                                                          NUMBER
-- SALESMAN                                                       NUMBER
-- MANAGER                                                        NUMBER
-- PRESIDENT                                                      NUMBER
-- ANALYST                                                        NUMBER
--
--13:29:02 SCOTT>select * from unpivot;
--
--DEPTNO     CLERK  SALESMAN   MANAGER PRESIDENT    ANALYST
-------- --------- --------- --------- --------- ----------
--    10         1         0         1         1          0
--    20         1         0         1         0          1
--    30         1         4         1         0          0

SELECT * FROM unpivot
UNPIVOT
(
  empno FOR job IN (CLERK,SALESMAN,MANAGER,PRESIDENT,ANALYST)
);
DEPTNO JOB                  EMPNO
------ --------------- ----------
    10 CLERK                    1
    10 SALESMAN                 0
    10 MANAGER                  1
    10 PRESIDENT                1
    10 ANALYST                  0
    20 CLERK                    1
    20 SALESMAN                 0
    20 MANAGER                  1
    20 PRESIDENT                0
    20 ANALYST                  1
    30 CLERK                    1
    30 SALESMAN                 4
    30 MANAGER                  1
    30 PRESIDENT                0
    30 ANALYST                  0

15 행이 선택되었습니다.