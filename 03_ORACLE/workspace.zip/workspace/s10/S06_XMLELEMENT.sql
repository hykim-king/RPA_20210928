col deptno for 999
col "xml_ename" for a30
--SELECT deptno,
--       XMLELEMENT(name,',',ename) "xml_ename"
--FROM emp
--;
col "dept_ename_list" for a50
SELECT deptno,
       SUBSTR(XMLAGG( XMLELEMENT(name,',',ename) ORDER BY hiredate)
	   .EXTRACT('//text()').getStringVal(),2) "dept_ename_list"
FROM emp
GROUP BY deptno
;

DEPTNO dept_ename_list
------ --------------------------------------------------
    10 CLARK,KING,MILLER
    20 SMITH,JONES,FORD
    30 ALLEN,WARD,BLAKE,TURNER,MARTIN,JAMES