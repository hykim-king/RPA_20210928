--전체 순위 확인			
-- 전체순위보기: RANK( ) 뒤가 WITHIN GROUP 가 아니고 OVER 로 바뀝니다.
-- RANK ( )  OVER (ORDER BY  조건컬럼명 [ASC | DESC] )

--예 1) 
--emp 테이블에서 사원들의 empno, ename, sal, 
--급여순위를 출력하세요.

--SELECT empno, 
--       ename, 
--	   sal,
--	   RANK() OVER(ORDER BY sal ) "RANK_ASC",	   
--FROM emp
--;
--     EMPNO ENAME                       SAL   RANK_ASC
------------ -------------------- ---------- ----------
--      7369 SMITH                       800          1
--      7900 JAMES                       950          2
--      7521 WARD                       1250          3
--      7654 MARTIN                     1250          3
--      7934 MILLER                     1300          5
--      7844 TURNER                     1500          6
--      7499 ALLEN                      1600          7
--      7782 CLARK                      2450          8
--      7698 BLAKE                      2850          9
--      7566 JONES                      2975         10
--      7902 FORD                       3000         11
--      7839 KING                       5000         12
--
--12 행이 선택되었습니다.

SELECT empno, 
       ename, 
	   sal,
	   RANK() OVER(ORDER BY sal DESC ) "RANK_DESC"	   
FROM emp
;
--     EMPNO ENAME                       SAL  RANK_DESC
------------ -------------------- ---------- ----------
--      7839 KING                       5000          1
--      7902 FORD                       3000          2
--      7566 JONES                      2975          3
--      7698 BLAKE                      2850          4
--      7782 CLARK                      2450          5
--      7499 ALLEN                      1600          6
--      7844 TURNER                     1500          7
--      7934 MILLER                     1300          8
--      7654 MARTIN                     1250          9
--      7521 WARD                       1250          9
--      7900 JAMES                       950         11
--      7369 SMITH                       800         12