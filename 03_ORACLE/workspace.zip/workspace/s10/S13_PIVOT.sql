COL "C_COUNT" FOR 9999
COL "C_SUM"   FOR 9999
COL "S_COUNT" FOR 9999
COL "S_SUM"   FOR 9999
COL "M_COUNT" FOR 9999
COL "M_SUM"   FOR 9999
COL "A_COUNT" FOR 9999
COL "A_SUM"   FOR 9999
--PIVOT decode함수에 사용했던 그룹함수(Count)를 쓰고
--for 부분에 그룹핑할 컬럼 이름과 IN 뒤부분에 분류할 목록을 기록

--각 인원수 별로 급여 합계
SELECT * FROM ( SELECT deptno,job,empno,sal 
                FROM emp )				
PIVOT(	
		COUNT(empno)    AS count,
		SUM(NVL(sal,0)) AS sum FOR job IN ( 'CLERK'      AS "C"    
                                           ,'SALESMAN'   AS "S" 
                                           ,'MANAGER'    AS "M"  
                                           ,'PRESIDENT'  AS "P"
                                           ,'ANALYST'    AS "A"
                       )
)
ORDER BY deptno;

DEPTNO C_COUNT C_SUM S_COUNT S_SUM M_COUNT M_SUM    P_COUNT      P_SUM A_COUNT A_SUM
------ ------- ----- ------- ----- ------- ----- ---------- ---------- ------- -----
    10       1  1300       0             1  2450          1       5000       0
    20       1   800       0             1  2975          0                  1  3000
    30       1   950       4  5600       1  2850          0                  0