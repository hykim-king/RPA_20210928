--RANK()함수 : 순위 출력																
--	주어진 컬럼 값의 그룹에서 값의 순위를 계산한 후 순위를 출력															
--	같은 순위 일때 가지는 순위 기준에 대해서 같은 출력 값을 가진다.															
--																
--	특정 데이터의 순위 확인하기															
--SELECT ename
--FROM emp
--ORDER BY ename;
--
--ENAME
----------------------
--ALLEN
--BLAKE
--CLARK
--FORD
--JAMES
--JONES
--KING
--MARTIN
--MILLER
--SMITH
--TURNER
--WARD
--
--12 행이 선택되었습니다.

SELECT RANK('SMITH')WITHIN GROUP (ORDER BY ename) "RANK"
FROM emp;

      RANK
----------
        10