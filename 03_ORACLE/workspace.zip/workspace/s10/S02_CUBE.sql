col deptno  for 99999
col job  for a15
col AVG_SAL  for 9999.9
col CNT_EMP  for 99999
SELECT deptno, 
       job,
	   ROUND(AVG(NVL(sal,0)),1) AVG_SAL,
	   COUNT(*) CNT_EMP
FROM emp
GROUP BY CUBE(job,deptno)
ORDER BY deptno,job
;
DEPTNO JOB             AVG_SAL CNT_EMP
------ --------------- ------- -------
    10 CLERK            1300.0       1
    10 MANAGER          2450.0       1
    10 PRESIDENT        5000.0       1
    10                  2916.7       3
    20 ANALYST          3000.0       1
    20 CLERK             800.0       1
    20 MANAGER          2975.0       1
    20                  2258.3       3
    30 CLERK             950.0       1
    30 MANAGER          2850.0       1
    30 SALESMAN         1400.0       4
    30                  1566.7       6
       ANALYST          3000.0       1
       CLERK            1016.7       3
       MANAGER          2758.3       3
       PRESIDENT        5000.0       1
       SALESMAN         1400.0       4
                        2077.1      12

18 행이 선택되었습니다.