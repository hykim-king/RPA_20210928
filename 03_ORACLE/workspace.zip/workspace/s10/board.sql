DROP TABLE BOARD;

CREATE TABLE BOARD (
   BOARD_ID NUMBER PRIMARY KEY,
   TITLE VARCHAR2(100 CHAR) NOT NULL,
   READ_CNT NUMBER(8) DEFAULT 0,
   CONENTS CLOB,
   REG_ID VARCHAR2(20 BYTE),
   REG_DT DATE DEFAULT SYSDATE
);

--�Է�
INSERT INTO BOARD (BOARD_ID, TITLE,CONENTS,REG_ID,REG_DT)
VALUES (1,'����01','����_01','apple',sysdate);

--�ܰ���ȸ
SELECT board_id, 
       title,
	     read_cnt,
	     conents,
	     reg_id,
	     TO_CHAR(reg_dt,'YYYY/MM/DD HH24:MI:SS') reg_dt
FROM board
WHERE board_id = 1
;

--����
DELETE FROM board
WHERE board_id = 1

--����
UPDATE board
SET title   = '����01_U',
    conents = '����_01',
	reg_id  = 'james',
	reg_dt  = sysdate
WHERE board_id = 1
;





