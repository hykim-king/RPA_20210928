COL SUN FOR A4
COL MON FOR A4
COL TUE FOR A4
COL WED FOR A4
COL THU FOR A4
COL FRI FOR A4
COL SAT FOR A4

--SELECT MAX(DECODE(day,'SUN',dayno))   SUN,
--       MAX(DECODE(day,'MON',dayno))   MON,
--	     MAX(DECODE(day,'TUE',dayno))   TUE,
--	     MAX(DECODE(day,'WED',dayno))   WED,
--	     MAX(DECODE(day,'THU',dayno))   THU,
--	     MAX(DECODE(day,'FRI',dayno))   FRI,
--	     MAX(DECODE(day,'SAT',dayno))   SAT
--FROM cal
--GROUP BY weekno
--ORDER BY weekno
--;
SELECT "week",SUN,MON,TUE,WED,THU,FRI,SAT
FROM (
		SELECT * FROM (SELECT weekno "week",day,dayno FROM cal)
		PIVOT
		(  MAX(dayno) FOR day IN (
									'SUN' AS SUN
								   ,'MON' AS MON
								   ,'TUE' AS TUE
								   ,'WED' AS WED
								   ,'THU' AS THU
								   ,'FRI' AS FRI
								   ,'SAT' AS SAT
								 )
		)
		ORDER BY "week"
)
; 						
11:32:41 SCOTT>@S10_PIVOT_CAL.sql

we SUN  MON  TUE  WED  THU  FRI  SAT
-- ---- ---- ---- ---- ---- ---- ----
1  1    2    3    4    5    6    7
2  8    9    10   11   12   13   14
3  15   16   17   18   19   20   21
4  22   23   24   25   26   27   28
5  29   30   31