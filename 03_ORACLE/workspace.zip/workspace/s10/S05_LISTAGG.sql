col deptno for 999
col "LISTAGG" for a50
SELECT deptno,
       LISTAGG(ename,',') 
	   WITHIN GROUP (ORDER BY hiredate) "LISTAGG"
FROM emp
GROUP BY deptno
;

DEPTNO LISTAGG
------ --------------------------------------------------
    10 CLARK,KING,MILLER
    20 SMITH,JONES,FORD
    30 ALLEN,WARD,BLAKE,TURNER,MARTIN,JAMES