COL "CLERK"     FOR 99999999
COL "SALESMAN"  FOR 99999999
COL "MANAGER"   FOR 99999999
COL "PRESIDENT" FOR 99999999
COL "PRESIDENT" FOR 99999999

SELECT deptno,
       COUNT(DECODE(job,'CLERK','0')    ) "CLERK",
	   COUNT(DECODE(job,'SALESMAN','0') ) "SALESMAN",
	   COUNT(DECODE(job,'MANAGER','0')  ) "MANAGER",
	   COUNT(DECODE(job,'PRESIDENT','0')) "PRESIDENT",
	   COUNT(DECODE(job,'ANALYST','0')  ) "PRESIDENT"
FROM emp
GROUP BY deptno
ORDER BY deptno
;
DEPTNO     CLERK  SALESMAN   MANAGER PRESIDENT PRESIDENT
------ --------- --------- --------- --------- ---------
    10         1         0         1         1         0
    20         1         0         1         0         1
    30         1         4         1         0         0