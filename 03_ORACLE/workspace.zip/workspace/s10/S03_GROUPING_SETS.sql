--Student 테이블에서 학년별로 학생들의 인원수 합계
--Student 테이블에서 학과별 학생들의 인원 합계
--desc student;

col grade  for 9999
col CNT    for 9999

SELECT grade,
       null deptno1,
       COUNT(*) CNT
FROM student
GROUP BY grade
UNION ALL
SELECT null grade,
       deptno1,
       COUNT(*) cnt
FROM student
GROUP BY deptno1
;
GRADE    DEPTNO1        CNT
----- ---------- ----------
    1                     5
    2                     5
    4                     5
    3                     5
             101          4
             103          2
             202          2
             301          2
             201          6
             102          4

10 행이 선택되었습니다.