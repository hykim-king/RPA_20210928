--DESC dept2;
--COL dcode FOR 9999
--COL dname FOR a15
--SELECT dcode,
--       dname
--FROM dept2
--WHERE dcode BETWEEN 9000 AND 9999;
--
--DCODE        DNAME
-------------- ---------------
--9001         temp_2
--9003         temp_3

--DELETE FROM dept2
--WHERE dcode BETWEEN 9000 AND 9999;

--COL dcode FOR 9999
--COL dname FOR a28
--SELECT dcode,
--       dname
--FROM dept2;
--WHERE dcode BETWEEN 9000 AND 9999;
--
--DML작업을 원래대로 되돌리기.
--ROLLBACK;

--COL dcode FOR 9999
--COL dname FOR a28
--SELECT dcode,
--       dname
--FROM dept2;
--WHERE dcode BETWEEN 9000 AND 9999;

--DELETE FROM dept2
--WHERE dcode BETWEEN 9000 AND 9999;

COL dcode FOR 9999
COL dname FOR a28
SELECT dcode,
       dname
FROM dept2;
WHERE dcode BETWEEN 9000 AND 9999;



DELETE FROM dept2
WHERE dcode BETWEEN 9000 AND 9999;

SELECT dcode
       dname
FROM dept2;

--확정
COMMIT;

