--ROW()단위를 COLUMN단위로 변경									
--DROP TABLE tb_pivot;
--
--CREATE TABLE tb_pivot(
--	year VARCHAR2(4 byte),
--	month number(2)
--);
--
--INSERT INTO tb_pivot VALUES ('2021',1  );
--INSERT INTO tb_pivot VALUES ('2021',2  );
--INSERT INTO tb_pivot VALUES ('2021',3  );
--INSERT INTO tb_pivot VALUES ('2021',4  );
--INSERT INTO tb_pivot VALUES ('2021',5  );
--INSERT INTO tb_pivot VALUES ('2021',6  );
--INSERT INTO tb_pivot VALUES ('2021',7  );
--INSERT INTO tb_pivot VALUES ('2021',8  );
--INSERT INTO tb_pivot VALUES ('2021',9  );
--INSERT INTO tb_pivot VALUES ('2021',10 );
--INSERT INTO tb_pivot VALUES ('2021',11 );
--INSERT INTO tb_pivot VALUES ('2021',12 );
--
--COMMIT;

--SELECT *
--FROM tb_pivot;
--
--YEAR          MONTH
---------- ----------
--2021              1
--2021              2
--2021              3
--2021              4
--2021              5
--2021              6
--2021              7
--2021              8
--2021              9
--2021             10
--2021             11
--2021             12
--
--12 행이 선택되었습니다.
COL M01 FOR 99
COL M02 FOR 99
COL M03 FOR 99
COL M04 FOR 99
COL M05 FOR 99
COL M06 FOR 99
COL M07 FOR 99
COL M08 FOR 99
COL M09 FOR 99
COL M10 FOR 99
COL M11 FOR 99
COL M12 FOR 99


--SELECT year,
--       DECODE(month,1,month,null)  M01,
--	   DECODE(month,2,month,null)  M02,
--	   DECODE(month,3,month,null)  M03,	
--	   DECODE(month,4,month,null)  M04,	
--       DECODE(month,5,month,null)  M05,
--	   DECODE(month,6,month,null)  M06,
--	   DECODE(month,7,month,null)  M07,	
--	   DECODE(month,8,month,null)  M08,
--       DECODE(month,9,month,null)  M09,
--	   DECODE(month,10,month,null) M10,
--	   DECODE(month,11,month,null) M11,	
--	   DECODE(month,12,month,null) M12	   
--FROM tb_pivot
--;
--YEAR     M01 M02 M03 M04 M05 M06 M07 M08 M09 M10 M11 M12
---------- --- --- --- --- --- --- --- --- --- --- --- ---
--2021       1
--2021           2
--2021               3
--2021                   4
--2021                       5
--2021                           6
--2021                               7
--2021                                   8
--2021                                       9
--2021                                          10
--2021                                              11
--2021                                                  12
--
--12 행이 선택되었습니다.

SELECT year,
       MAX(DECODE(month,1,month,null) ) M01,
	   MAX(DECODE(month,2,month,null) ) M02,
	   MAX(DECODE(month,3,month,null) ) M03,	
	   MAX(DECODE(month,4,month,null) ) M04,	
       MAX(DECODE(month,5,month,null) ) M05,
	   MAX(DECODE(month,6,month,null) ) M06,
	   MAX(DECODE(month,7,month,null) ) M07,	
	   MAX(DECODE(month,8,month,null) ) M08,
       MAX(DECODE(month,9,month,null) ) M09,
	   MAX(DECODE(month,10,month,null)) M10,
	   MAX(DECODE(month,11,month,null)) M11,	
	   MAX(DECODE(month,12,month,null)) M12	   
FROM tb_pivot
GROUP BY year
;   

YEAR     M01 M02 M03 M04 M05 M06 M07 M08 M09 M10 M11 M12
-------- --- --- --- --- --- --- --- --- --- --- --- ---
2021       1   2   3   4   5   6   7   8   9  10  11  12