--col name for a23
--col bonus for 99999
--col position for a23
--SELECT name,
--       bonus,
--	   position
--FROM professor
--WHERE position = 'assistant professor'
--;	   
--NAME                     BONUS POSITION
------------------------- ------ -----------------------
--Angela Bassett              60 assistant professor
--Michelle Pfeiffer           80 assistant professor
--Julia Roberts               50 assistant professor
--Susan Sarandon                 assistant professor
--Nicole Kidman               50 assistant professor
--Jodie Foster                30 assistant professor
--
--6 행이 선택되었습니다.
--UPDATE professor
--SET bonus = 200
--WHERE position = 'assistant professor'

--col name for a23
--col bonus for 99999
--col position for a23
--SELECT name,
--       bonus,
--	   position
--FROM professor
--WHERE position = 'assistant professor'
--;	   

--ROLLBACK;


col name for a23
col bonus for 99999
col position for a23
SELECT name,
       bonus,
	   position
FROM professor
WHERE position = 'assistant professor'
;	   