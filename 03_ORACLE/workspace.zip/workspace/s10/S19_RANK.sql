SELECT empno, 
       ename, 
	   sal,
	   deptno,
	   RANK() OVER(ORDER BY sal DESC ) "RANK_DESC"	   
FROM emp
WHERE deptno = 10
;
--     EMPNO ENAME                       SAL DEPTNO  RANK_DESC
------------ -------------------- ---------- ------ ----------
--      7839 KING                       5000     10          1
--      7782 CLARK                      2450     10          2
--      7934 MILLER                     1300     10          3