--비교연산자
SELECT empno,
       ename,
	   sal
FROM emp
WHERE sal >=4000
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7839 KING                       5000