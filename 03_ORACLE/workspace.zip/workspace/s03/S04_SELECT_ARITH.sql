--SQL에서 산술연산자 사용

SELECT t1.ename,
       sal,
	   sal*1.1 as "sal+bonus",  --보너스 급여 10%,
	   sal+100 
FROM emp t1
WHERE deptno = 10
;
--ENAME                       SAL  sal+bonus    SAL+100
---------------------- ---------- ---------- ----------
--CLARK                      2450       2695       2550
--KING                       5000       5500       5100
--MILLER                     1300       1430       1400