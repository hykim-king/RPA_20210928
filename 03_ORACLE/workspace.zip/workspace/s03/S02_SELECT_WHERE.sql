--원하는 조건만 골라내기 : WHERE절
--SELECT  [ Column or Expression ]
--FROM  [ Table  or View ]
--WHERE  원하는 조건  ;

--문자열은 : ''만 된다.
--데이터는 대소문자를 구분 한다.
SELECT empno,
       ename,
	   sal
FROM emp
WHERE ename = 'JAMES'
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7900 JAMES                       950