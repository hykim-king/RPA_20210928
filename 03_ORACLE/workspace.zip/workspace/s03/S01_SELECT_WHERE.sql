--원하는 조건만 골라내기 : WHERE절
--SELECT  [ Column or Expression ]
--FROM  [ Table  or View ]
--WHERE  원하는 조건  ;

SELECT ename,
       sal
FROM emp
WHERE sal < 1000
;
--16:17:38 SCOTT>@S01_SELECT_WHERE.sql
--
--ENAME                       SAL
---------------------- ----------
--SMITH                       800
--JAMES                       950