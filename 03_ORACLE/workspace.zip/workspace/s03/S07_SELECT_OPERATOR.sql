--비교연산자 문자 비교
SELECT empno,
       ename,
	   sal
FROM emp
WHERE ename >= 'W'
;

--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7521 WARD                       1250