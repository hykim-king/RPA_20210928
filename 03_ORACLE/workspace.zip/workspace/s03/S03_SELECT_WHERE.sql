--원하는 조건만 골라내기 : WHERE절
--SELECT  [ Column or Expression ]
--FROM  [ Table  or View ]
--WHERE  원하는 조건  ;

SELECT empno,
       ename,
	   hiredate
FROM emp
WHERE ename = 'JAMES'
;

--     EMPNO ENAME                HIREDATE
------------ -------------------- --------
--      7900 JAMES                81/12/03