--CREATE TABLE st_table(
-- no  NUMBER
--);

--1000건 입력

--BEGIN
--	FOR i IN 1..1000 LOOP
--		INSERT INTO st_table VALUES (i );
--	END LOOP;
--	
--	COMMIT;
--	
--END;
--/

--SELECT count(*)
--FROM st_table;


--STATIC DIC 조회
--SELECT num_rows,
--       blocks
--FROM user_tables
--WHERE table_name ='ST_TABLE'
--;
--  NUM_ROWS     BLOCKS
------------ ----------
--

--딕셔너리를 관리자가 수동으로 업데이트
--ANALYZE TABLE st_table COMPUTE STATISTICS;
--테이블이 분석되었습니다.

--사용량이 많은 업무시간에는 해당 작업 금지

STATIC DIC 조회
SELECT num_rows,
       blocks
FROM user_tables
WHERE table_name ='ST_TABLE'
;

  NUM_ROWS     BLOCKS
---------- ----------
      1000          5
