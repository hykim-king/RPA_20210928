--DROP TABLE dept7;

--휴지통 확인
--SHOW recyclebin;
--
--
--ORIGINAL NAME    RECYCLEBIN NAME                OBJECT TYPE  DROP TIME
------------------ ------------------------------ ------------ -------------------
--BOARD            BIN$BSP1M6ngTjyhvCeP7fKO4A==$0 TABLE        2021-12-02:14:03:35
--BOARD            BIN$xSzm3GdERLGgt8qpcFmtFA==$0 TABLE        2021-12-02:14:03:10
--CAT_B            BIN$hPoNEYGrTYOhBJi8UWOIRg==$0 TABLE        2021-12-02:11:09:02
--DEPT7            BIN$FlpBeg2aTFSRqm8CDjn1Og==$0 TABLE        2021-12-06:09:49:04
--TB_PIVOT         BIN$DUeSpRAJRsu8jE1zrfxC6A==$0 TABLE        2021-11-30:10:29:50
--TB_PIVOT         BIN$j+o/x5AUTimz2jJsbzZIiA==$0 TABLE        2021-11-30:10:27:18

--FLASHBACK table "BIN$FlpBeg2aTFSRqm8CDjn1Og==$0" to BEFORE DROP;
--
--플래시백이 완료되었습니다.

--복구된 테이블 확인
--desc dept7;

--1. 테이블 생성
--
--2. 테이블 drop
--
--3. 휴지통 확인
--
--4. 복원

--1
--drop table dept_test;

--CREATE TABLE dept_test
--AS
--SELECT *
--FROM dept;

--SELECT *
--FROM dept_test;

--2
--DROP TABLE dept_test;

--3
--show recyclebin;

--4
--flashback table "BIN$HWC/PHuhRC621hpQ0y2aTA==$0" to before drop;

--5
SELECT *
FROM dept_test;