CREATE TABLE new_emp3
AS
SELECT *
FROM new_emp2
WHERE 1=2
;