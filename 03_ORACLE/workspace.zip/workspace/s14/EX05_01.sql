DROP TABLE new_emp;
CREATE TABLE new_emp(
  no NUMBER(5),
  name VARCHAR2(20),
  hiredate DATE,
  bonus NUMBER(6,2)
);


--col column_name for a30
--col data_type for a15
--col data_default for a20
--SELECT column_name,
--       data_type,
--	   data_default
--FROM user_tab_columns
--WHERE table_name = 'NEW_EMP'
--ORDER BY column_id;


--COLUMN_NAME   DATA_TYPE       DATA_DEFAULT
--------------- --------------- --------------------
--NO            NUMBER
--NAME          VARCHAR2
--HIREDATE      DATE
--BONUS         NUMBER