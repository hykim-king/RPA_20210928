--데이터와 공간도 삭제.
--delete는 공간은 남아 있다.
--TRUNCATE TABLE dept7;

SELECT *
FROM dept7;