ALTER TABLE new_emp2 RENAME COLUMN BIRTHDAY TO BIRTH;

DESC new_emp2;

 이름         널?      유형
 ------------ -------- ------------------------------------
 NO                    NUMBER(5)
 NAME                  VARCHAR2(20)
 HIREDATE              DATE
 BIRTH                 DATE