
--동적SQL
--SELECT TT1.board_id,
--       TT1.rnum AS num,
--	   TT1.read_cnt,
--	   TO_CHAR(TT1.reg_dt,'YYYY/MM/DD') REG_DT,
--	   TT1.REG_ID
--FROM (
--	SELECT rownum rnum, T1.*
--	FROM(
--		SELECT *
--		FROM board
--		--WHERE 조건
--		--WHERE title like '제목_1' ||'%'
--		--WHERE contents like '내용_1' ||'%'
--		--WHERE contents like 'admin' ||'%'
--		ORDER BY reg_dt DESC
--	)T1
--)TT1	
--WHERE rnum BETWEEN 1 AND 10
----WHERE rnum BETWEEN &PAGE_SIZE*(&PAGE_NUM-1)+1 AND &PAGE_SIZE*(&PAGE_NUM-1)+&PAGE_SIZE
--;

--총건수
SELECT COUNT(*) total_cnt
FROM board;
--WHERE 조건
--WHERE title like '제목_1' ||'%'
--WHERE contents like '내용_1' ||'%'
--WHERE contents like 'admin' ||'%'