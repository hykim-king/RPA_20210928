
--동적SQL
SELECT A.*,B.*
FROM (
		SELECT TT1.board_id,
			   TT1.rnum AS num,
			   TT1.read_cnt,
			   TO_CHAR(TT1.reg_dt,'YYYY/MM/DD') REG_DT,
			   TT1.REG_ID
		FROM (
			SELECT rownum rnum, T1.*
			FROM(
				SELECT *
				FROM board
				--WHERE
				ORDER BY reg_dt DESC
			)T1
		)TT1	
		WHERE rnum BETWEEN 1 AND 10
)A CROSS JOIN (	SELECT COUNT(*) total_cnt
				FROM board
				--WHERE
)B
;
--BOARD_ID        NUM READ_CNT REG_DT          REG_ID           TOTAL_CNT
---------- ---------- -------- --------------- --------------- ----------
--     360          1        0 2021/12/06      admin0              100000
--     370          2        0 2021/12/06      admin0              100000
--     380          3        0 2021/12/06      admin0              100000
--     390          4        0 2021/12/06      admin0              100000
--     400          5        0 2021/12/06      admin0              100000
--     200          6        0 2021/12/06      admin0              100000
--     210          7        0 2021/12/06      admin0              100000
--     220          8        0 2021/12/06      admin0              100000
--     230          9        0 2021/12/06      admin0              100000
--     240         10        0 2021/12/06      admin0              100000
--
--10 행이 선택되었습니다.