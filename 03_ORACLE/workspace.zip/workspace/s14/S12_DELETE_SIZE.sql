--scott 계정에 있는 reorg 생성
--CREATE TABLE scott.reorg ( 
--	no NUMBER,
--	name VARCHAR2(20),
--	addr VARCHAR2(20)
--);	

--DBMS_RANDOM.STRING
--- 랜덤한 문자열을 생성한다.
--- Syntax : DBMS_RANDOM.STRING opt IN CHAR, len IN NUMBER)
--- opt (옵션)은 아래와 같다.
--'u', 'U' : 대문자
--'l', 'L' : 소문자
--'a', 'A' : 대소문자 구분없는 영문자
--'x', 'X' : 영문자와 숫자 혼합
--'p', 'P' : 문자 혼합

--BEGIN
--	FOR i IN 1..500000 LOOP
--		INSERT INTO scott.reorg 
--		VALUES (i, DBMS_RANDOM.STRING('u',19)
--		         ,DBMS_RANDOM.STRING('u',19));
--	END LOOP;
--	COMMIT;
--END;
--/

--SELECT COUNT(*)
--FROM scott.reorg ;

--  COUNT(*)
------------
--    500000

--딕셔너리를 관리자가 수동으로 업데이트											
--ANALYZE TABLE scott.reorg COMPUTE STATISTICS;		

--SELECT SUM(bytes)/1024/1024 MB
--FROM dba_segments
--WHERE owner = 'SCOTT'		
--AND segment_name ='REORG'							
--;
----테이블 크기
--        MB
------------
--        28  
--col table_name for a30
--col num_rows for 999999999
--col blocks for 99999 
--col empty_blocks for 99999 
--SELECT table_name,
--       num_rows,
--	   blocks,
--	   empty_blocks
--FROM dba_tables
--WHERE owner = 'SCOTT'		
--AND table_name ='REORG'							
----;
--
--TABLE_NAME     NUM_ROWS BLOCKS EMPTY_BLOCKS
-------------- ---------- ------ ------------
--REORG            500000   3520           64


--SELECT COUNT( DISTINCT DBMS_ROWID.ROWID_BLOCK_NUMBER(rowid) ||
--                       DBMS_ROWID.ROWID_RELATIVE_FNO(rowid)) "REAL_USED"
--FROM scott.reorg
--;

--실제 TABLE에서 사용하고 있는 공간.
-- REAL_USED
------------
--      3447

--DELETE FROM scott.reorg;
--
--COMMIT;
--
--SELECT COUNT(*)
--FROM scott.reorg;


SELECT SUM(bytes)/1024/1024 MB
FROM dba_segments
WHERE owner = 'SCOTT'		
AND segment_name ='REORG'			
;

SELECT COUNT( DISTINCT DBMS_ROWID.ROWID_BLOCK_NUMBER(rowid) ||
                       DBMS_ROWID.ROWID_RELATIVE_FNO(rowid)) "REAL_USED"
FROM scott.reorg
;

        MB
----------
        28


 REAL_USED
----------
         0