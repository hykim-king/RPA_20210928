DROP TABLE new_emp2;
