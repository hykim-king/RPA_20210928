ALTER TABLE new_emp2
ADD ( birthday DATE DEFAULT SYSDATE);


