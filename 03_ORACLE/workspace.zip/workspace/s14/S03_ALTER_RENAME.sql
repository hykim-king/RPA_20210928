--테이블명 변경
--RENAME dept6 TO dept7;
--테이블 이름이 변경되었습니다.

SELECT *
FROM dept7;

DCODE        DNAME                               LOC             LOC99
------------ ----------------------------------- --------------- --------------------
1000         Management Support Team                             SEOUL
1001         Financial Management Team                           SEOUL
1002         General affairs                                     SEOUL