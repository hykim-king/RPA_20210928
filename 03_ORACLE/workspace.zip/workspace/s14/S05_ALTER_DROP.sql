ALTER TABLE dept7 DROP COLUMN loc;
테이블이 변경되었습니다.
--제약조건이 걸려 있는 경우(fk)
ALTER TABLE dept7 DROP COLUMN loc CASCADE CONSTRAINTS;