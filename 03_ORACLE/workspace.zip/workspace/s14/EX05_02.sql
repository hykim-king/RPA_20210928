CREATE TABLE new_emp2
AS
SELECT no,
       name,
	   hiredate
FROM new_emp
;

DESC new_emp2;

 이름             널?      유형               
 ---------------- -------- -----------------
 NO                        NUMBER(5)
 NAME                      VARCHAR2(20)
 HIREDATE                  DATE
