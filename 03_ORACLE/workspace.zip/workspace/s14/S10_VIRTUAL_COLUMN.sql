--step.1 가상 컬럼을 가지는 테이블 vt1생성																										
--step.2 테이블에 데이터 입력															
--step.3 입력된 데이터 조회												
--step.4 기존 값을 변경 이우 가상 컬럼 반영 여부											
--step.5 새로운 가상 컬럼 추가										
--step.6 테이블에서 가상 컬럼 내영 조회							
--step.7 조건절을 활용한 가상 컬럼 생성														


--1.
--CREATE TABLE vt1(
--	col1 NUMBER,
--	col2 NUMBER,
--	col3 NUMBER GENERATED ALWAYS AS ( col1 * col2)
--);

--DESC vt1;

--2.
--INSERT INTO vt1 VALUES (1,2,3);
--1행에 오류:
--ORA-54013: INSERT 작업은 가상 열에서 허용되지 않습니다.
--INSERT INTO vt1(col1,col2) VALUES (1,2);

--3.
--SELECT *
--FROM vt1;

--4
--UPDATE vt1
--SET COL1 = 5;

--SELECT *
--FROM vt1;

--5
--ALTER TABLE vt1
--ADD (col4 GENERATED ALWAYS AS ((COL1*COL2)+COL2) );

--SELECT *
--FROM vt1;

--6
--col column_name for a30
--col data_type for a15
--col data_default for a20
--SELECT column_name,
--       data_type,
--	   data_default
--FROM user_tab_columns
--WHERE table_name = 'VT1'
--ORDER BY column_id;
--
--COLUMN_NAME                    DATA_TYPE       DATA_DEFAULT
-------------------------------- --------------- --------------------
--COL1                           NUMBER
--COL2                           NUMBER
--COL3                           NUMBER          "COL1"*"COL2"
--COL4                           NUMBER          "COL1"*"COL2"+"COL2"


--7 가상 컬럼에 case문 사용 20211206
--CREATE TABLE sales10(
--	no NUMBER,
--	pcode CHAR(4),
--	pdate CHAR(8),
--	pqty  NUMBER,
--	pbungi NUMBER(1)
--	GENERATED ALWAYS AS
--	(
--		CASE WHEN SUBSTR(pdate,5,2) IN ('01','02','03') THEN 1
--		     WHEN SUBSTR(pdate,5,2) IN ('04','05','06') THEN 2
--			 WHEN SUBSTR(pdate,5,2) IN ('07','08','09') THEN 3
--			 ELSE 4
--		END	 
--	) virtual
--)
--;
--테이블이 생성되었습니다.

--INSERT INTO sales10 (no,pcode,pdate,pqty) VALUES(1,'100','20110112',10);
--INSERT INTO sales10 (no,pcode,pdate,pqty) VALUES(2,'300','20110512',10);
--INSERT INTO sales10 (no,pcode,pdate,pqty) VALUES(3,'400','20110812',10);
--INSERT INTO sales10 (no,pcode,pdate,pqty) VALUES(4,'200','20111012',10);
--COMMIT;

SELECT *
FROM sales10;

        NO PCODE    PDATE                  PQTY     PBUNGI
---------- -------- ---------------- ---------- ----------
         1 100      20110112                 10          1
         2 300      20110512                 10          2
         3 400      20110812                 10          3
         4 200      20111012                 10          4