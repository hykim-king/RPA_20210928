--1000건 입력
--BEGIN
--	FOR i IN 1..1000 LOOP
--		INSERT INTO scott.reorg 
--		VALUES (i, DBMS_RANDOM.STRING('u',19)
--		         ,DBMS_RANDOM.STRING('u',19));
--	END LOOP;
--	COMMIT;
--END;
--/

--입력 건수 
--SELECT COUNT(*)
--FROM scott.reorg;
--
--  COUNT(*)
------------
--      1000


--딕셔너리를 관리자가 수동으로 업데이트											
--ANALYZE TABLE scott.reorg COMPUTE STATISTICS;		
--
----용량확인 
--SELECT SUM(bytes)/1024/1024 MB
--FROM dba_segments
--WHERE owner = 'SCOTT'		
--AND segment_name ='REORG'			
--;
--
--        MB
------------
--        28

--300건 데이터 삭제.
--DELETE FROM scott.reorg 
--WHERE no BETWEEN 1 AND 300;

--COMMIT;


--입력 건수 
--SELECT COUNT(*)
--FROM scott.reorg;



--테이블 재구성 작업
--col table_name for a25
--col tablespace_name for a25
--SELECT table_name,
--       tablespace_name
--FROM dba_tables
--WHERE table_name ='REORG' 
--;

--TABLE_NAME                TABLESPACE_NAME
--------------------------- -------------------------
--REORG                     USERS

--ALTER TABLE scott.reorg MOVE tablespace users;

----용량확인 
SELECT SUM(bytes)/1024/1024 MB
FROM dba_segments
WHERE owner = 'SCOTT'		
AND segment_name ='REORG'			
;