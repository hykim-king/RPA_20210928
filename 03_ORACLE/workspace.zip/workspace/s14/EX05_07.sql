--ALTER TABLE 테이블명 DROP COLUMN 컬럼명
--DESC new_emp2;
-- 이름             널?      유형            
-- -------------- -------- ---------------
-- NO                      NUMBER(7)
-- NAME                    VARCHAR2(20)
-- HIREDATE                DATE
-- BIRTH                   DATE

--ALTER TABLE new_emp2 DROP COLUMN BIRTH;

DESC new_emp2;

-- 이름             널?      유형
-- -------------- -------- ------------------------------------
-- NO                      NUMBER(7)
-- NAME                    VARCHAR2(20)
-- HIREDATE                DATE