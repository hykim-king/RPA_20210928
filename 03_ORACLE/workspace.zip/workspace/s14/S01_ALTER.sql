--새로운 컬럼 추가
--CREATE TABLE dept6
--AS
--SELECT dcode,
--       dname
--FROM dept2
--WHERE dcode IN (1000,1001,1002)
--;

--DESC dept6;

--SELECT *
--FROM dept6;

--ALTER TABLE dept6
--ADD ( LOC VARCHAR2(10));

--DESC dept6;

--default value
--ALTER TABLE dept6
--ADD ( location VARCHAR2(10) DEFAULT 'SEOUL');

SELECT *
FROM dept6;

DCODE        DNAME                               LOC             LOCATION
------------ ----------------------------------- --------------- --------------------
1000         Management Support Team                             SEOUL
1001         Financial Management Team                           SEOUL
1002         General affairs                                     SEOUL