09:30:32 SCOTT>DESC DEPT7;
 이름      널?      유형              
 --------- -------- --------------
 DCODE              VARCHAR2(6)
 DNAME     NOT NULL VARCHAR2(30)
 LOC                VARCHAR2(10)  --> VARCHAR2(20)
 LOC99              VARCHAR2(10)
ALTER TABLE dept7 MODIFY ( loc VARCHAR2(20) );

09:34:25 SCOTT>DESC DEPT7;
 이름     널?      유형                
 -------- -------- ----------------
 DCODE             VARCHAR2(6)
 DNAME    NOT NULL VARCHAR2(30)
 LOC               VARCHAR2(20)
 LOC99             VARCHAR2(10)
