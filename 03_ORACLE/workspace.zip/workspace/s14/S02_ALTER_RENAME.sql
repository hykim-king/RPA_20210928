--컬럼이름 변경
ALTER TABLE dept6 RENAME COLUMN location TO LOC99;

SELECT *
FROM dept6;

DCODE        DNAME                               LOC             LOC99
------------ ----------------------------------- --------------- --------------------
1000         Management Support Team                             SEOUL
1001         Financial Management Team                           SEOUL
1002         General affairs                                     SEOUL