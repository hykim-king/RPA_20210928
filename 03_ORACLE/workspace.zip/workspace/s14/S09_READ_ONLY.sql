--1. 테이블 생성
--2. 데이터 입력
--3. 데이터 조회
--4. 읽기전용으로 변경
--5. 쓰기 가능한 테이블로 변경

--1.
 --CREATE TABLE t_readonly(
 --   no NUMBER,
--	name VARCHAR2(10)
 --);
 
 --2.
 --INSERT INTO t_readonly VALUES (1,'AAA');
 
 --2.1. COMMIT
 --COMMIT;
 
 --3
 --SELECT *
 --FROM t_readonly;
 
 --4
 --ALTER TABLE t_readonly READ ONLY;
 --테이블이 변경되었습니다.
 
-- INSERT INTO t_readonly VALUES (2,'BBB');
-- 1행에 오류:
--ORA-12081: "SCOTT"."T_READONLY" 테이블에 작업을 업데이트하는 것이 허용되지 않습 니다


--5
--ALTER TABLE t_readonly READ WRITE;
--테이블이 변경되었습니다.

--INSERT INTO t_readonly VALUES (2,'BBB');

SELECT *
FROM t_readonly;

        NO NAME
---------- -------------------
         1 AAA
         2 BBB