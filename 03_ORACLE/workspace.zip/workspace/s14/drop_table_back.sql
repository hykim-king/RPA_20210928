--오라클에서도 Flashback Drop 기능을 사용해서 복원작업이 가능합니다. 
--단, purge 명령어를 사용해서 테이블을 Drop했다면 복원이 불가능합니다.

1. 테이블 생성
CREATE TABLE dept_test
AS
SELECT *
FROM dept;

17:25:00 SCOTT>select * from dept_test;

DEPTNO DNAME                               LOC
------ ----------------------------------- ---------------
    10 ACCOUNTING                          NEW YORK
    20 RESEARCH                            DALLAS
    30 SALES                               CHICAGO
    40 OPERATIONS                          BOSTON

2. 테이블 삭제
DROP TABLE dept_test;

테이블이 삭제되었습니다.

3. 휴지통 확인
show recyclebin;

ORIGINAL NAME    RECYCLEBIN NAME                OBJECT TYPE  DROP TIME
---------------- ------------------------------ ------------ -------------------
BOARD            BIN$BSP1M6ngTjyhvCeP7fKO4A==$0 TABLE        2021-12-02:14:03:35
BOARD            BIN$xSzm3GdERLGgt8qpcFmtFA==$0 TABLE        2021-12-02:14:03:10
CAT_B            BIN$hPoNEYGrTYOhBJi8UWOIRg==$0 TABLE        2021-12-02:11:09:02
DEPT_TEST        BIN$Bs8ey3Q+TyK/VF5iP56D3A==$0 TABLE        2021-12-03:17:26:09
TB_PIVOT         BIN$DUeSpRAJRsu8jE1zrfxC6A==$0 TABLE        2021-11-30:10:29:50
TB_PIVOT         BIN$j+o/x5AUTimz2jJsbzZIiA==$0 TABLE        2021-11-30:10:27:18


4. 복원
flashback table DEPT_TEST to before drop;
flashback table "BIN$Bs8ey3Q+TyK/VF5iP56D3A==$0" to before drop;
플래시백이 완료되었습니다.

5.복원확인
select * from dept_test;
DEPTNO DNAME                               LOC
------ ----------------------------------- ---------------
    10 ACCOUNTING                          NEW YORK
    20 RESEARCH                            DALLAS
    30 SALES                               CHICAGO
    40 OPERATIONS                          BOSTON