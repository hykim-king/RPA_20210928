ALTER TABLE new_emp2 MODIFY (  no NUMBER(7));

DESC new_emp2

 이름            널?      유형
 --------------- -------- ------------------------------------
 NO                       NUMBER(7)
 NAME                     VARCHAR2(20)
 HIREDATE                 DATE
 BIRTH                    DATE