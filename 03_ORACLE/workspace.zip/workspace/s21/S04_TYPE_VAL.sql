DECLARE
   vno employees.employee_id%TYPE;
   vname employees.first_name%TYPE;
   vsal employees.salary%TYPE;
BEGIN
	SELECT employee_id,first_name,salary 
	  INTO vno,vname,vsal
	FROM employees
	WHERE employee_id = 180;
	DBMS_OUTPUT.PUT_LINE(vno||','||vname||','||vsal);
END;
/
--180,������,3200