--DECLARE
--
--BEGIN
--   UPDATE pl_test2
--   SET name = 'bbb'
--   WHERE no = 10;
--   
--   COMMIT;
--END;
--/

SELECT *
FROM pl_test2;

        NO NAME                 ADDR
---------- -------------------- --------------------
        10 bbb                  서울

1개의 행이 선택되었습니다.