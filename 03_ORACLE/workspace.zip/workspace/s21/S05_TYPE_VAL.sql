DECLARE
   vrow employees%ROWTYPE;
BEGIN
	SELECT *  
	  INTO vrow
	FROM employees
	WHERE employee_id = 180;
	DBMS_OUTPUT.PUT_LINE(vrow.employee_id||','||vrow.first_name||','||vrow.salary);
END;
/