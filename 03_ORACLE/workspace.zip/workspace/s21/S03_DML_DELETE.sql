BEGIN
  DELETE FROM  pl_test2
  WHERE no = 10;
  
  COMMIT;
END;
/

SELECT *
FROM pl_test2;

선택된 레코드가 없습니다.