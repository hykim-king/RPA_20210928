DECLARE --선언부
  vno NUMBER(4);
  vname VARCHAR2(10);
BEGIN --실행부
  SELECT empno, ename INTO vno,vname
  FROM emp
  WHERE empno = 7369;
  
  DBMS_OUTPUT.PUT_LINE(vno ||',' ||vname);

END;
/