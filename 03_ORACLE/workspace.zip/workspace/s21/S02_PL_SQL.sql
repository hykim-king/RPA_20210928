
--employees.employee_id%TYPE
--employees테이블의 컬럼이 employee_id 데이터 타입
DECLARE
   v_empid  employees.employee_id%TYPE;
   v_salary employees.salary%TYPE;
BEGIN

	SELECT employee_id,salary INTO v_empid, v_salary
	FROM employees
	WHERE employee_id = 197;
	
	
	DBMS_OUTPUT.PUT_LINE(v_empid||'===='||v_salary);
	
END;
/	
--197====3000