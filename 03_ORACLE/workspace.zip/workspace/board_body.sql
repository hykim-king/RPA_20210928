create or replace NONEDITIONABLE PACKAGE BODY  p_board --패키지 선언부
AS
    ------do_delete ------------------------------------------------------------
	PROCEDURE do_insert(board_id NUMBER,
                       title VARCHAR2,
                       contents CLOB,
                       reg_id VARCHAR2) 
    IS
      status NUMBER;
	BEGIN
		INSERT INTO BOARD (BOARD_ID, TITLE,CONTENTS,REG_ID,REG_DT)
        VALUES (board_id,title,contents,reg_id,SYSDATE);
        status := SQL%ROWCOUNT;  -- SQL%ROWCOUNT 위해 산림 커서 속성
        DBMS_OUTPUT.PUT_LINE('do_insert status:'||status);
        COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
     status := 0;
	END do_insert;
    ------//do_delete ----------------------------------------------------------
    
    ------do_delete ------------------------------------------------------------
	PROCEDURE do_delete(board_id NUMBER) 
    IS
      status NUMBER;
	BEGIN
		DELETE FROM board
        WHERE board_id = board_id;
        
        status := SQL%ROWCOUNT;  -- SQL%ROWCOUNT 위해 산림 커서 속성
        DBMS_OUTPUT.PUT_LINE('do_delete status:'||status);
        COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
     status := 0;
	END do_delete;
    ------//do_delete end-------------------------------------------------------
    
    -------do_update -----------------------------------------------------------
	PROCEDURE do_update(v_board_id NUMBER,
                        v_title VARCHAR2,
                        v_contents CLOB,
                        v_reg_id VARCHAR2) 
    IS
      status NUMBER;
	BEGIN
		UPDATE board t1
        SET t1.TITLE = v_title,
            t1.CONTENTS = v_contents,
            t1.REG_ID   = v_reg_id,
            t1.REG_DT   = SYSDATE
        WHERE t1.BOARD_ID = v_board_id;
        
        status := SQL%ROWCOUNT;  -- SQL%ROWCOUNT 위해 산림 커서 속성
        DBMS_OUTPUT.PUT_LINE('do_update status:'||status);
        COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
     status := 0;
	END do_update;
    ------//do_update ----------------------------------------------------------
    
    ------do_select_one ------------------------------------------------------------
	PROCEDURE do_select_one(board_id NUMBER) 
    IS
      CURSOR board_cur IS
      SELECT board_id,
             title,
             read_cnt,
             contents,
             reg_id,
             TO_CHAR(reg_dt,'YYYY/MM/DD HH24:MI:SS') reg_dt
       FROM board
       WHERE board_id = board_id;
       
       v_board_id NUMBER;
       v_read_cnt NUMBER;
       v_title VARCHAR2(200);
       v_contents CLOB;
       v_reg_id VARCHAR2(20);   
       v_reg_dt VARCHAR2(20);   
	BEGIN
        OPEN board_cur;  --OPEN 커서
        FETCH board_cur INTO v_board_id,v_title,v_read_cnt,v_contents,v_reg_id,v_reg_dt;  --FETCH
        DBMS_OUTPUT.PUT_LINE(' board_id : ' || v_board_id);
        DBMS_OUTPUT.PUT_LINE(' title : ' || v_title);
        DBMS_OUTPUT.PUT_LINE(' read_cnt : ' || v_read_cnt);
        DBMS_OUTPUT.PUT_LINE(' contents : ' || v_contents);
        DBMS_OUTPUT.PUT_LINE(' reg_id : ' || v_reg_id);
        DBMS_OUTPUT.PUT_LINE(' reg_dt : ' || v_reg_dt);          
        CLOSE board_cur;  --CLOSE 커서    
        
   EXCEPTION
     WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM||'에러 발생 ');
	END do_select_one;
    ------//do_select_one end-------------------------------------------------------
    
END p_board; 
/