--테이블 t3,t4
--CREATE TABLE t3(
-- no NUMBER,
-- name VARCHAR2(10),
-- deptno NUMBER
--);


--CREATE TABLE t4(
-- deptno NUMBER,
-- dname VARCHAR2(10)
--);

--Test 1) 2 건 이상의 데이터 반환을 요청하는 경우 - 에러 발생합니다																		

--T3
--INSERT INTO t3 VALUES (1,'AAA',100);
--INSERT INTO t3 VALUES (2,'BBB',200);
--INSERT INTO t3 VALUES (3,'CCC',300);
--
--COMMIT;

--SELECT *
--FROM t3;
--
--        NO NAME                              DEPTNO
------------ ----------------------------- ----------
--         1 AAA                                  100
--         2 BBB                                  200
--         3 CCC                                  300

--t4
--INSERT INTO t4 VALUES (100,'DDD');--100 ->400
----2 건 이상의 데이터 반환(오류)
--INSERT INTO t4 VALUES (100,'EEE');
--INSERT INTO t4 VALUES (200,'FFF');
--INSERT INTO t4 VALUES (300,'GGG');
--COMMIT;

--SELECT *
--FROM t4;
--    DEPTNO DNAME
------------ ---------------------------------
--       100 DDD
--       100 EEE
--       200 FFF
--       300 GGG

--SELECT t3.no,
--       t3.name,
--	   (SELECT dname
--	    FROM t4
--		WHERE t3.deptno = t4.deptno)
--FROM t3
--;
--3행에 오류:
--ORA-01427: 단일 행 하위 질의에 2개 이상의 행이 리턴되었습니다.

--DEPTNO 100 -> 400번으로 UPDATE
--UPDATE T4
--SET deptno = 400
--WHERE dname = 'DDD';

--COMMIT;

--SELECT *
--FROM t4;

--오류 해결됨
--SELECT t3.no,
--       t3.name,
--	   (SELECT dname
--	    FROM t4
--		WHERE t3.deptno = t4.deptno) DNAME
--FROM t3
--;

--Test 2) 2 개 이상의 컬럼을 조회할 경우에도 에러가 발생 합니다																	

--SELECT t3.no,
--       t3.name,
--	   (SELECT dname,deptno
--	    FROM t4
--		WHERE t3.deptno = t4.deptno) DNAME
--FROM t3
--;

3행에 오류:
ORA-00913: 값의 수가 너무 많습니다