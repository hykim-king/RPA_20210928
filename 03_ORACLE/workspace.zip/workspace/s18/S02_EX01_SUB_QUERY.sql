COL "STUD_NAME" FOR A25
COL "DEPT_NAME" FOR A25
SELECT t1.name "STUD_NAME",
       t2.dname "DEPT_NAME"
FROM student t1, department t2
WHERE t1.deptno1 = t2.deptno
AND t1.deptno1 = (SELECT deptno1
                  FROM student
                  WHERE name = 'Anthony Hopkins'
)
;