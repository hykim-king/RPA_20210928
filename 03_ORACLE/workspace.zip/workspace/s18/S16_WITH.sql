--14:43:15 SCOTT>CONN / AS sysdba;
--col tablespace_name for a15
--col MB for 9999
--col file_name for a55
--
--SELECT tablespace_name,
--       bytes/1024/1024 MB,
--	   file_name
--FROM dba_data_files
--;
--
--TABLESPACE_NAME    MB FILE_NAME
----------------- ----- -------------------------------------------------------
--USERS              35 C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\USERS01.DBF
--UNDOTBS1           65 C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\UNDOTBS01.DBF
--SYSTEM            850 C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\SYSTEM01.DBF
--SYSAUX            750 C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\SYSAUX01.DBF


--필요한 만큼 자동 증가 되도록 설정 변경
--C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\USERS01.DBF

--ALTER DATABASE DATAFILE 'C:\APP\HKEDU\PRODUCT\18.0.0\ORADATA\XE\USERS01.DBF'
--AUTOEXTEND ON;
--
--데이타베이스가 변경되었습니다.
--^
--|
--SYS 

--with_test1 테이블 생성
--CREATE TABLE with_test1 (
--   no NUMBER,
--   name VARCHAR2(10),
--   pay  NUMBER(6)
--)
--TABLESPACE USERS;
--
--테이블이 생성되었습니다.

--SQL수행 시간을 표시하도록 설정
SET TIMING ON

--BEGIN
--	FOR i IN 1..5000000 LOOP
--		INSERT INTO with_test1 VALUES ( i, DBMS_RANDOM.STRING('A',5)
--		                                  ,DBMS_RANDOM.VALUE(6,999999 ) );
--	END LOOP;
--	COMMIT;
--END;
--/

--SELECT COUNT(*)
--FROM with_test1;

--ㅡmax함수와 min함수로 최대 최소값의 차
--SELECT MAX(pay) - MIN(pay)
--FROM with_test1
--;

--index 생성해서 시간 측정
--CREATE INDEX idx_with_test1_pay 
--ON with_test1(pay);

--ㅡindex사용 max함수와 min함수로 최대 최소값의 차
--SELECT MAX_PAY - MIN_PAY
--FROM (
--	   (SELECT /*+ index_desc(w idx_with_test1_pay) */ MAX(pay) MAX_PAY
--		FROM with_test1 w
--		WHERE pay > 0
--		)
--		CROSS JOIN (
--		SELECT /*+ index(w idx_with_test1_pay) */ MIN(pay) MIN_PAY
--		FROM with_test1 w
--		WHERE pay > 0
--		)
--);
--MAX_PAY-MIN_PAY
-----------------
--         999993
--
--경   과: 00:00:00.62



--SETP.4 WITH절을 사용 최대값 최소값을 WITH절 업이 소요시간 측정
WITH a AS (
  SELECT /*+ index_desc(w idx_with_test1_pay) */ w.pay
  FROM with_test1 w
  WHERE w.pay > 0
  AND rownum =1 
),
b AS (
  SELECT /*+ index(w idx_with_test1_pay) */ w.pay
  FROM with_test1 w
  WHERE w.pay > 0
  AND rownum =1 
)
SELECT a.pay -b.pay
FROM a,b;

A.PAY-B.PAY
-----------
     999993

경   과: 00:00:00.01






