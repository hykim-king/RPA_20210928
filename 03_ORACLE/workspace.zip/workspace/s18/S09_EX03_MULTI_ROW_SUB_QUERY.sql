col name for a29
col pay for a15
col dname for a29
SELECT t2.dname,
       name,
       TO_CHAR(pay,'$999,999,999') pay
FROM emp2 t1, dept2 t2
WHERE t1.deptno = t2.dcode
AND pay <ALL (
                   SELECT avg(pay)
                   FROM emp2
                   GROUP BY deptno
)
ORDER BY PAY
;

DNAME                         NAME                          PAY
----------------------------- ----------------------------- ---------------
Sales4 Team                   Tom Cruise                      $20,000,000
H/W Support Team              Harrison Ford                   $20,000,000
S/W Support Team              Clint Eastwood                  $20,000,000
Sales3 Team                   Sly Stallone                    $22,000,000
Sales1 Team                   JohnTravolta                    $22,000,000
Sales2 Team                   Robert De Niro                  $22,000,000

6 행이 선택되었습니다.