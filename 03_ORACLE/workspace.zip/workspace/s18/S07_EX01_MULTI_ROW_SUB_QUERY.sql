 --이름                   널?      유형             
 ---------------------- -------- ---------------
 --EMPNO                NOT NULL NUMBER
 --NAME                 NOT NULL VARCHAR2(30)
 --BIRTHDAY                      DATE
 --DEPTNO               NOT NULL VARCHAR2(6)
 --EMP_TYPE                      VARCHAR2(30)
 --TEL                           VARCHAR2(15)
 --HOBBY                         VARCHAR2(30)
 --PAY                           NUMBER
 --POSITION                      VARCHAR2(30)
 --PEMPNO                        NUMBER
 COL  name FOR a17
 COL  position FOR a27
 COL  pay FOR a17
 
 SELECT name,
        position,
		TO_CHAR(pay,'$999,999,999') PAY
 FROM emp2
 WHERE pay >ANY (SELECT pay
                 FROM emp2
				 WHERE position ='Section head')
 ;
 
NAME              POSITION                    PAY
----------------- --------------------------- -----------------
Kurt Russell      Boss                         $100,000,000
Kevin Bacon       Department head               $75,000,000
AL Pacino         Department head               $72,000,000
Val Kilmer        Department head               $68,000,000
Tommy Lee Jones   Deputy department head        $60,000,000
Gene Hackman      Section head                  $56,000,000
Hugh Grant        Section head                  $51,000,000
Woody Harrelson   Section head                  $50,000,000

8 행이 선택되었습니다.
