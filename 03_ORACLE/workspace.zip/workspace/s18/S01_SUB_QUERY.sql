--EMP 테이블에서 WARD보다 COMM을 적게 받는 사람의 이름과 COMM을 출력 하세요.

SELECT ename,
       comm
FROM emp
WHERE comm < (SELECT comm
              FROM emp
              WHERE ename = 'WARD')
;

--ENAME                      COMM
---------------------- ----------
--ALLEN                       300
--TURNER                        0

- Sub Query 부분은 WHERE 절에 연산자 오른쪽에 위치해야 하며 반드시 괄호로 묶어야 합니다.
- 특별한 경우 (Top-n 분석 등)를 제외하고는 Sub Query 절에 Order by 절이 올 수 없습니다.
- 단일 행 Sub Query 와 다중 행 Sub Query 에 따라 연산자를 잘 선택해야 합니다.


