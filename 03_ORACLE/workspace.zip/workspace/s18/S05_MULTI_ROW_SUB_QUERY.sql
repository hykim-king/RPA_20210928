--Emp2 테이블과 Dept2 테이블을 참조하여 근무지역(dept2 테이블의 area 컬럼)이 																						
--'Pohang Main Office' 인 모든 사원들의 사번과 이름, 부서번호를 출력하세요.		

--DESC dept2;		

SELECT empno,
       name,
	   deptno
FROM emp2
WHERE deptno IN (																		
					SELECT dcode
					FROM dept2
					WHERE area = 'Pohang Main Office'
				)
;
     EMPNO NAME                      DEPTNO
---------- ------------------------- ------------
  19900101 Kurt Russell              0001
  19966102 Kevin Bacon               1003
  19970112 Val Kilmer                1006
  19960212 Chris O'Donnell           1007