--sql 성능이 매우 않좋다.
SELECT a.name,
       a.position,
	   a.pay
FROM emp2 a
WHERE pay >= (SELECT AVG(pay)
              FROM emp2 b
			  WHERE a.position = b.position
              )
;			  