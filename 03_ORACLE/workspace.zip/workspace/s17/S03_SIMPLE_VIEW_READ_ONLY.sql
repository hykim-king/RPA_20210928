--읽기 전용 VIEW생성
CREATE OR REPLACE VIEW view2
AS
	SELECT a,
		   b
	FROM o_table
--읽기전용	
WITH READ ONLY;

SELECT *
FROM view2;


INSERT INTO view2 VALUES (3,4);
1행에 오류:
ORA-42399: 읽기 전용 뷰에서는 DML 작업을 수행할 수 없습니다.

INSERT INTO view1 VALUES (3,4);

SELECT *
FROM view2;