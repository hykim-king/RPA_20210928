SELECT COUNT(*)
FROM professor;

  COUNT(*)
----------
        16

SELECT COUNT(*)
FROM m_prof;

  COUNT(*)
----------
        16

원본 테이블 데이터 1건 삭제
DELETE FROM professor
WHERE profno = 4001;

COMMIT;

SELECT COUNT(*)
FROM professor;

  COUNT(*)
----------
        15
SELECT COUNT(*)
FROM m_prof;

  COUNT(*)
----------
        16
DBMS_MVIEW 패키지로 동기화 수행.

BEGIN
	DBMS_MVIEW.REFRESH('M_PROF');
END;
/

SELECT *
FROM m_prof
ORDER BY profno;

PROFNO NAME                               PAY
------ --------------------------- ----------
  1001 Audie Murphy                       550
  1002 Angela Bassett                     380
  1003 Jessica Lange                      270
  2001 Winona Ryder                       250
  2002 Michelle Pfeiffer                  350
  2003 Whoopi Goldberg                    490
  3001 Emma Thompson                      530
  3002 Julia Roberts                      330
  3003 Sharon Stone                       290
  4002 Susan Sarandon                     330
  4003 Nicole Kidman                      310
  4004 Holly Hunter                       260
  4005 Meg Ryan                           500
  4006 Andie Macdowell                    220
  4007 Jodie Foster                       290

15 행이 선택되었습니다.