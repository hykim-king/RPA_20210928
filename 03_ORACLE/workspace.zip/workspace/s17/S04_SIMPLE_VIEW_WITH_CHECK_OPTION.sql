--With Check Option
INSERT INTO o_table VALUES(5,6);
SELECT *
FROM o_table;


A=3인 값을 다른 값으로 변경하려면 오류 발생.
CREATE OR REPLACE VIEW view3
AS
	SELECT a,b
	FROM o_table
	WHERE a = 3
	WITH CHECK OPTION;

a = 3을 다른 값으로 UPDATE

SELECT *
FROM view3;

UPDATE view3
SET a = 5
WHERE b= 4;
1행에 오류:
ORA-01402: 뷰의 WITH CHECK OPTION의 조건에 위배 됩니다

UPDATE view3
SET b = 55
WHERE a= 3;

1 행이 업데이트되었습니다.

SELECT *
FROM view3;