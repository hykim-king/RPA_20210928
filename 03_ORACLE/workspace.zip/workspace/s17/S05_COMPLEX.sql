--emp테이블과 dept테이블을 조회 하여 사원이름,부서 이름을 출력하는 
--view생성
CREATE OR REPLACE VIEW v_emp
AS 
	SELECT t1.ename,
		   t2.dname
	FROM emp t1, dept t2
	WHERE t1.deptno = t2.deptno
;

SELECT *
FROM v_emp;

ENAME                DNAME
-------------------- ----------------------------
KING                 ACCOUNTING
CLARK                ACCOUNTING
MILLER               ACCOUNTING
FORD                 RESEARCH
SMITH                RESEARCH
JONES                RESEARCH
JAMES                SALES
TURNER               SALES
MARTIN               SALES
WARD                 SALES
ALLEN                SALES
BLAKE                SALES

12 행이 선택되었습니다.