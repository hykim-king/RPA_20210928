--view조회
--DESC user_views;
--
--col view_name for a15
--col text for a50
--col read_only for a10
--SELECT view_name,
--       text,
--	   read_only
--FROM user_views;


--DROP
--DROP VIEW V_EMP;
--뷰가 삭제되었습니다.

col view_name for a15
col text for a50
col read_only for a10
SELECT view_name,
       text,
	   read_only
FROM user_views;

VIEW_NAME       TEXT                                               READ_ONLY
--------------- -------------------------------------------------- ----------
VIEW1           SELECT a,                                          N
                       b
                FROM o_table

VIEW2           SELECT a,                                          Y
                       b
                FROM o_table
                
                WITH READ ONLY

VIEW3           SELECT a,b                                         N
                FROM o_table
                WHERE a = 3
                WITH CHECK OPTION

V_EMP1          SELECT empno,                                      N
                       ename,
                           hiredate
                FROM emp