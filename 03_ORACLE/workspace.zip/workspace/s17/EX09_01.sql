--desc professor;

 --이름                               널?      유형                  
 ------------------------------------- -------- -------------------
 --PROFNO                              NOT NULL NUMBER(4)
 --NAME                                NOT NULL VARCHAR2(20)
 --ID                                  NOT NULL VARCHAR2(15)
 --POSITION                            NOT NULL VARCHAR2(30)
 --PAY                                 NOT NULL NUMBER(3)
 --HIREDATE                            NOT NULL DATE
 --BONUS                                        NUMBER(4)
 --DEPTNO                                       NUMBER(3)
 --EMAIL                                        VARCHAR2(50)
 --HPAGE                                        VARCHAR2(50)
 --
 
 --desc department;
 
1--1:32:11 SCOTT>@EX09_01.sql
 --이름                               널?      유형
 ------------------------------------- -------- -------------------
 --DEPTNO                              NOT NULL NUMBER(3)
 --DNAME                               NOT NULL VARCHAR2(50)
 --PART                                         NUMBER(3)
 --BUILD                                        VARCHAR2(30)

col profno for 9999
col name for a19
col dname for a32
--SELECT t1.profno,
--       t1.name,
--	   t2.dname
--FROM professor T1, department T2
--WHERE t1.deptno = t2.deptno
--;

--CREATE OR REPLACE VIEW v_prof_dept2
--AS 
--SELECT t1.profno,
--       t1.name,
--	   t2.dname
--FROM professor T1, department T2
--WHERE t1.deptno = t2.deptno
--;

SELECT *
FROM v_prof_dept2;

PROFNO NAME                DNAME
------ ------------------- --------------------------------
  1001 Audie Murphy        Computer Engineering
  1002 Angela Bassett      Computer Engineering
  1003 Jessica Lange       Computer Engineering
  2001 Winona Ryder        Multimedia Engineering
  2002 Michelle Pfeiffer   Multimedia Engineering
  2003 Whoopi Goldberg     Multimedia Engineering
  3001 Emma Thompson       Software Engineering
  3002 Julia Roberts       Software Engineering
  3003 Sharon Stone        Software Engineering
  4002 Susan Sarandon      Electronic Engineering
  4003 Nicole Kidman       Mechanical Engineering
  4004 Holly Hunter        Mechanical Engineering
  4005 Meg Ryan            Chemical Engineering
  4006 Andie Macdowell     Library and Information science
  4007 Jodie Foster        Library and Information science

15 행이 선택되었습니다.