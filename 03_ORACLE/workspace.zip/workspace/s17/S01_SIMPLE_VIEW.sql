emp테이블에서 empno, ename, hiredate
CREATE OR REPLACE VIEW v_emp1
AS 
SELECT empno,
       ename,
	   hiredate
FROM emp
;

SELECT *
FROM v_emp1;

VIEW에 데이터 없음: CREATE INDEX
CREATE INDEX idx_vemp_ename
ON v_emp1(ename);