--View를 통한 DML
--CREATE TABLE o_table(
--	a number,
--	b number
--);

--VIEW생성
--CREATE VIEW view1
--AS
--SELECT a,
--       b
--FROM o_table;	   

--데이터 없음 확인 
--SELECT a,
--       b
--FROM o_table;	

--dml
--INSERT INTO o_table VALUES (1,2);
--  INSERT INTO view1 VALUES (2,4);
--데이터 확인 
--SELECT a,
--       b
--FROM o_table;	
--         A          B
------------ ----------
--         1          2
--         2          4
ROLLBACK;