col deptno for a10
col profno for 9999
col name for a27
SELECT DECODE(deptno,ndeptno,NULL,deptno) deptno,
       profno,
       name
FROM (
	SELECT deptno,
		   LAG(deptno,1) OVER(ORDER BY deptno) ndeptno,
		   profno,
		   name
	FROM professor
)
;

DEPTNO     PROFNO NAME
---------- ------ ---------------------------
101          1001 Audie Murphy
             1002 Angela Bassett
             1003 Jessica Lange
102          2001 Winona Ryder
             2002 Michelle Pfeiffer
             2003 Whoopi Goldberg
103          3001 Emma Thompson
             3002 Julia Roberts
             3003 Sharon Stone
201          4001 Meryl Streep
             4002 Susan Sarandon
202          4003 Nicole Kidman
             4004 Holly Hunter
203          4005 Meg Ryan
301          4006 Andie Macdowell
             4007 Jodie Foster

16 행이 선택되었습니다.
--LAG()함수																
--	이전 행 값을 가져올 때 사용하는 함수															
--	형식															
--		LAG(출력할 컬럼명 , OFFSET , 기본 출력값) 														
--		 OVER (Query_partition구문 , ORDER BY 정렬할 컬럼)														
