--emp 테이블과 dept테이블을 조회하여 부서 번호와 부서별
--최대 급여 및 부서명을 출력 하세요.
SELECT t1.deptno,
       t1.max_sal,
	   t2.dname
FROM(SELECT deptno,
            MAX(sal) max_sal
     FROM emp
     GROUP BY deptno
)t1, dept t2
WHERE t1.deptno = t2.deptno
;
--from절에 있는 inline view를 수행해서 나온 테이블은
--원래 존재하지 않지만 우리가 원하는 결과를 만들기 위해서
--임시로 메모리에 생성.

    DEPTNO    MAX_SAL DNAME
---------- ---------- ----------------------------
        10       5000 ACCOUNTING
        20       3000 RESEARCH
        30       2850 SALES