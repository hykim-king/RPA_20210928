--DESC user_mviews;

--MVIEW조회
--COL mview_name FOR A15
--COL query FOR A50
--SELECT mview_name,
--       query 
--FROM user_mviews
--WHERE mview_name = 'M_PROF'
--;
--
--MVIEW_NAME      QUERY
----------------- --------------------------------------------------
--M_PROF          SELECT profno,
--                       name,
--                           pay
--                FROM professor

--MVIEW삭제
--DROP materialized VIEW M_PROF;

--구체화된 뷰가 삭제되었습니다.
COL mview_name FOR A15
COL query FOR A50
SELECT mview_name,
       query 
FROM user_mviews
WHERE mview_name = 'M_PROF'
;