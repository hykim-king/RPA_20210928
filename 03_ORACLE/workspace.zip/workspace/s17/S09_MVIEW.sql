--CREATE MATERIALIZED VIEW m_prof
--BUILD IMMEDIATE
--REFRESH
--ON DEMAND
--COMPLETE
--ENABLE QUERY REWRITE
--AS
--SELECT profno,
--       name,
--	   pay
--FROM professor
--;
--
--구체화된 뷰가 생성되었습니다.
--
--BUILD IMMEDIATE : 서버쿼리 수행 하면서 데이터를 가져오라																		
--ON DEMAND: 사용자가 수동으로 데이터 동기화																		ON COMMIT: 원본테이블 변경후 COMMIT 발생하면 동기화
--REFRESH																		
--		1.COMPLETE: MVIEW 내의 데이터 전체가 원본 테이블과 동기화 되는 방법																
--		2.FAST: 원본 테이블에 새로운 데이터가 입력된 경우 그 부분만 동기화																
--		3.FORCE: FAST방법이 가능한지 살펴보고 불가능하면 COMPLETE방법을 사용																
--		4.NAVER: 동기화 하지 않음																

--MVIEW에 데이터 존재 여부 확인: INDEX생성

--CREATE INDEX idx_m_prof_pay
--ON m_prof(pay);
--
--인덱스가 생성되었습니다.

SELECT *
FROM m_prof
WHERE pay > 0;