SELECT t2.grade,
       t2.name,
	   t2.height,
	   t1.avg_heigt
FROM (
		SELECT grade,
			   AVG(height) avg_heigt
		FROM student
		GROUP BY grade
)t1, student t2
WHERE t1.grade = t2.grade
AND   t2.height > t1.avg_heigt
ORDER BY 1
;
     GRADE NAME                    HEIGHT  AVG_HEIGT
---------- ----------------------- ------ ----------
         1 Christian Slater           173      170.4
         1 Sean Connery               175      170.4
         1 Charlie Sheen              179      170.4
         2 Richard Dreyfus            182      175.6
         2 Daniel Day-Lewis           184      175.6
         3 Macaulay Culkin            171      166.6
         3 Micheal Keaton             177      166.6
         4 Demi Moore                 177      175.8
         4 James Seo                  180      175.8
         4 Danny Glover               182      175.8

10 행이 선택되었습니다.