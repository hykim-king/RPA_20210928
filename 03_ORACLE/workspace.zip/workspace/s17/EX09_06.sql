SELECT *
FROM (
	SELECT rownum as num,
		   ceil(rownum/3) g_num,
		   A.*
	FROM (
	SELECT profno,
		   name,
		   pay,
		   SUM(pay) sum_pay,
		   ROUND(AVG(NVL(PAY,0)),1) AVG
	FROM professor
	GROUP BY profno,name,pay
	ORDER BY 1
	)A
	UNION ALL 	
	SELECT NULL AS NUM,
		   ceil(num/3) ceil_num,
		   NULL profno,
		   null name,
		   null pay,
		   SUM(pay),
		   ROUND(AVG(NVL(PAY,0)),1) AVG
	FROM (
		 SELECT rownum num,
				profno,
				pay
		 FROM professor
		 ORDER BY profno
	) GROUP BY ceil(num/3) 
)
ORDER BY 2,1,6,7
;