SELECT *
FROM (
		SELECT RANK() OVER(ORDER BY pay DESC) Ranking,
			   name,
			   pay
		FROM professor
)
WHERE Ranking <= 5
;