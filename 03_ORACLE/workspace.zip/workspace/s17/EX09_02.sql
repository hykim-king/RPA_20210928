--desc student;
SELECT t2.dname,
       t1.*
FROM (SELECT deptno1,
             MAX(HEIGHT) MAX_HEIGHT,
	         MAX(WEIGHT) MAX_WEIGHT
	  FROM student
	  GROUP BY deptno1)t1, department t2
WHERE t1.deptno1 = t2.deptno	  
;

DNAME                               DEPTNO1 MAX_HEIGHT MAX_WEIGHT
-------------------------------- ---------- ---------- ----------
Computer Engineering                    101        182         72
Multimedia Engineering                  102        179         81
Software Engineering                    103        168         52
Electronic Engineering                  201        177         83
Mechanical Engineering                  202        182         70
Library and Information science         301        184         62

6 행이 선택되었습니다.