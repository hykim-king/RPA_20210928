SELECT  p_store,
		p_date,
		p_code,
		p_qty,
		LAG(p_qty,1) OVER(ORDER BY p_date) "D-1 QTY",
		p_qty - LAG(p_qty,1) OVER(ORDER BY p_date) "DIFF-QTY",
		p_total,
		LAG(p_total,1) OVER(ORDER BY p_date) "D-1 PTOTAL",
		p_total - LAG(p_total,1) OVER(ORDER BY p_date) "DIFF PTOTAL"
FROM panmae
WHERE p_store = 1000
;

P_STORE  P_DATE   P_CODE  P_QTY    D-1 QTY   DIFF-QTY
-------- -------- ------ ------ ---------- ----------
1000     20110101    100      3
1000     20110102    102      2          3         -1
1000     20110102    105      2          2          0
1000     20110103    100      2          2          0