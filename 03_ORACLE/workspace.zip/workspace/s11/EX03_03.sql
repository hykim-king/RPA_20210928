col TOTAL for 9999
SELECT COUNT(AREA_CODE) TOTAL,
       COUNT(DECODE(AREA_CODE,'02',1 )) SEOUL,
       COUNT(DECODE(AREA_CODE,'031',1)) GYEONGGI,
	   COUNT(DECODE(AREA_CODE,'051',1)) BUSAN,
	   COUNT(DECODE(AREA_CODE,'052',1)) ULSAN,
	   COUNT(DECODE(AREA_CODE,'053',1)) DAEGU,
       COUNT(DECODE(AREA_CODE,'055',1)) GYEONGNAM
FROM (SELECT SUBSTR(tel,1,INSTR(tel,')')-1) AREA_CODE
      FROM student 
);

TOTAL   --   SEOUL   GYEONGGI      BUSAN      ULSAN      DAEGU  GYEONGNAM
----- ------------ ---------- ---------- ---------- ---------- ----------
   20   --       6          2          4          0          2          6