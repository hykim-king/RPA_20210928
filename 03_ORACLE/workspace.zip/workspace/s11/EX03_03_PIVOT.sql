
SELECT * FROM (SELECT COUNT(*) OVER() TOTAL ,SUBSTR(tel,1,INSTR(tel,')')-1) AREA_CODE
			   FROM student ) 
PIVOT
(
	 COUNT(AREA_CODE) FOR AREA_CODE IN (
	  '02'  AS SEOUL
	 ,'031' AS GYEONGGI
	 ,'051' AS BUSAN
	 ,'052' AS ULSAN
	 ,'053' AS DAEGU
	 ,'055' AS GYEONGNAM
	 )
);
TOTAL      SEOUL   GYEONGGI      BUSAN      ULSAN      DAEGU  GYEONGNAM
----- ---------- ---------- ---------- ---------- ---------- ----------
   20          6          2          4          0          2          6			   