COL TOTAL FOR A5
COL JAN FOR A3
COL FEB FOR A3
COL MAR FOR A3
COL APR FOR A3
COL MAY FOR A3
COL JUN FOR A3
COL JUL FOR A3
COL AUG FOR A3
COL SEP FOR A3
COL OCT FOR A3
COL NOV FOR A3
COL DEC FOR A3

SELECT COUNT(NVL(MM,0))||'EA' TOTAL,
       COUNT(DECODE(MM,'01',0))||'EA' JAN,
       COUNT(DECODE(MM,'02',0))||'EA' FEB,
	   COUNT(DECODE(MM,'03',0))||'EA' MAR,
	   COUNT(DECODE(MM,'04',0))||'EA' APR,
	   COUNT(DECODE(MM,'05',0))||'EA' MAY,
	   COUNT(DECODE(MM,'06',0))||'EA' JUN,
	   COUNT(DECODE(MM,'07',0))||'EA' JUL,
	   COUNT(DECODE(MM,'08',0))||'EA' AUG,
	   COUNT(DECODE(MM,'09',0))||'EA' SEP,
	   COUNT(DECODE(MM,'10',0))||'EA' OCT,
	   COUNT(DECODE(MM,'11',0))||'EA' NOV,
	   COUNT(DECODE(MM,'12',0))||'EA' DEC
FROM ( SELECT TO_CHAR(birthday,'MM') MM
       FROM student
)
;

--JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC
----- --- --- --- --- --- --- --- --- --- --- ---
--                                      1
--      1
--                      1
--                                              1
--          1
--  1
--              1
--                                  1
--  1
--                                      1
--                                          1
--              1
--                                  1
--      1
--                                              1
--                              1
--  1
--                              1
--          1
--      1

TOTAL JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC
----- --- --- --- --- --- --- --- --- --- --- --- ---
20EA  3EA 3EA 2EA 2EA 0EA 1EA 0EA 2EA 2EA 2EA 1EA 2EA