SELECT ename,
	   sal,
	   DENSE_RANK() OVER(ORDER BY sal ASC) "DENSE_RANK",
	   RANK()OVER (ORDER BY sal ASC) "RANK"
FROM emp
;
ENAME                       SAL DENSE_RANK       RANK
-------------------- ---------- ---------- ----------
SMITH                       800          1          1
JAMES                       950          2          2
WARD                       1250          3          3
MARTIN                     1250          3          3
MILLER                     1300          4          5
TURNER                     1500          5          6
ALLEN                      1600          6          7
CLARK                      2450          7          8
BLAKE                      2850          8          9
JONES                      2975          9         10
FORD                       3000         10         11
KING                       5000         11         12

12 행이 선택되었습니다.