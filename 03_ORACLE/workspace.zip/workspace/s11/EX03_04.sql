


---문법:NVL2(COL1,COL2,COL3)														
--														
--COL1값이 NULL이 아니면 COL2, NULL이면 COL3														

--Rollup(deptno)함수													
--		자동으로 소계와 합계를 구해주는 함수			
-- deptno별 합계
-- 전체 합계			
SELECT deptno,
       SUM(DECODE(job,'CLERK',sal,0)     ) CLERK,
	   SUM(DECODE(job,'MANAGER',sal,0)   ) MANAGER,
	   SUM(DECODE(job,'PRESIDENT',sal,0) ) PRESIDENT,
	   SUM(DECODE(job,'ANALYST',sal,0)   ) ANALYST,
	   SUM(DECODE(job,'SALESMAN',sal,0)  ) SALESMAN,
	   SUM(NVL2(job,sal,0)) "TOTAL" 
FROM emp
GROUP BY deptno
;					
    DEPTNO      CLERK    MANAGER  PRESIDENT    ANALYST   SALESMAN   TOTAL
---------- ---------- ---------- ---------- ---------- ---------- -------
        30        950       2850          0          0       5600    9400
        10       1300       2450       5000          0          0    8750
        20        800       2975          0       3000          0    6775


SELECT deptno,
       SUM(DECODE(job,'CLERK',sal,0)     ) CLERK,
	   SUM(DECODE(job,'MANAGER',sal,0)   ) MANAGER,
	   SUM(DECODE(job,'PRESIDENT',sal,0) ) PRESIDENT,
	   SUM(DECODE(job,'ANALYST',sal,0)   ) ANALYST,
	   SUM(DECODE(job,'SALESMAN',sal,0)  ) SALESMAN,
	   SUM(NVL2(job,sal,0)) "TOTAL" 
FROM emp
GROUP BY ROLLUP(deptno)
;
14:03:27 SCOTT>@EX03_04.sql

    DEPTNO      CLERK    MANAGER  PRESIDENT    ANALYST   SALESMAN   TOTAL
---------- ---------- ---------- ---------- ---------- ---------- -------
        10       1300       2450       5000          0          0    8750
        20        800       2975          0       3000          0    6775
        30        950       2850          0          0       5600    9400
                 3050       8275       5000       3000       5600   24925