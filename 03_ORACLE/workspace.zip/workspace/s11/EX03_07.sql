COL TOTAL       FOR A12
COL "SEOUL"     FOR A12
COL "GYEONGGI"  FOR A12
COL "BUSAN"     FOR A12
COL "ULSAN"     FOR A12
COL "DAEGU"     FOR A12
COL "GYEONGNAM" FOR A12

SELECT  COUNT(*)                         ||'EA  ('  ||  COUNT(*)                        /COUNT(*)*100   || '%)' TOTAL,
        COUNT(DECODE(area_code,'02' ,1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'02' ,1))/COUNT(*)*100   || '%)' "SEOUL",
		COUNT(DECODE(area_code,'031',1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'031',1))/COUNT(*)*100   || '%)' "GYEONGGI",
		COUNT(DECODE(area_code,'051',1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'051',1))/COUNT(*)*100   || '%)' "BUSAN",
		COUNT(DECODE(area_code,'052',1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'052',1))/COUNT(*)*100   || '%)' "ULSAN",
		COUNT(DECODE(area_code,'053',1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'053',1))/COUNT(*)*100   || '%)' "DAEGU",
		COUNT(DECODE(area_code,'055',1)) ||'EA  ('  ||  COUNT(DECODE(area_code,'055',1))/COUNT(*)*100   || '%)' "GYEONGNAM"
FROM (SELECT  SUBSTR(tel,1,INSTR(tel,')')-1) area_code
      FROM student
)
;
TOTAL        SEOUL        GYEONGGI     BUSAN        ULSAN        DAEGU        GYEONGNAM
------------ ------------ ------------ ------------ ------------ ------------ ------------
20EA  (100%) 6EA  (30%)   2EA  (10%)   4EA  (20%)   0EA  (0%)    2EA  (10%)   6EA  (30%)


--SELECT  COUNT(*)                         ||'EA ('|| '' || '%)' TOTAL,
--        COUNT(DECODE(area_code,'02' ,1)) ||'EA ('|| '' || '%)' "SEOUL",
--		COUNT(DECODE(area_code,'031',1)) ||'EA ('|| '' || '%)' "GYEONGGI",
--		COUNT(DECODE(area_code,'051',1)) ||'EA ('|| '' || '%)' "BUSAN",
--		COUNT(DECODE(area_code,'052',1)) ||'EA ('|| '' || '%)' "ULSAN",
--		COUNT(DECODE(area_code,'053',1)) ||'EA ('|| '' || '%)' "DAEGU",
--		COUNT(DECODE(area_code,'055',1)) ||'EA ('|| '' || '%)' "GYEONGNAM"
--FROM (SELECT  SUBSTR(tel,1,INSTR(tel,')')-1) area_code
--      FROM student
--)
--;
--
--TOTAL        SEOUL        GYEONGGI     BUSAN        ULSAN        DAEGU        GYEONGNAM
-------------- ------------ ------------ ------------ ------------ ------------ ------------
--20EA  (%)    6EA  (%)     2EA  (%)     4EA  (%)     0EA  (%)     2EA  (%)     6EA  (%)

SELECT  COUNT(*)                         ||'EA  ('|| RATIO_TO_REPORT( COUNT(*)) OVER()*100                          || '%)' TOTAL,
        COUNT(DECODE(area_code,'02' ,1)) ||'EA  ('|| RATIO_TO_REPORT( COUNT(DECODE(area_code,'02' ,1)) ) OVER()*100 || '%)' "SEOUL",
		COUNT(DECODE(area_code,'031',1)) ||'EA  ('|| '' || '%)' "GYEONGGI",
		COUNT(DECODE(area_code,'051',1)) ||'EA  ('|| '' || '%)' "BUSAN",
		COUNT(DECODE(area_code,'052',1)) ||'EA  ('|| '' || '%)' "ULSAN",
		COUNT(DECODE(area_code,'053',1)) ||'EA  ('|| '' || '%)' "DAEGU",
		COUNT(DECODE(area_code,'055',1)) ||'EA  ('|| '' || '%)' "GYEONGNAM"  
FROM (SELECT  SUBSTR(tel,1,INSTR(tel,')')-1) area_code
      FROM student
)
;