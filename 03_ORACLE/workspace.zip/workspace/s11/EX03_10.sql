
SELECT deptno,
	   ename,
	   sal,
	   SUM(sal) OVER(PARTITION BY deptno ORDER BY deptno) sum_dept,
	   ROUND(RATIO_TO_REPORT( sal ) OVER(PARTITION BY deptno)  * 100,2) "%" 
FROM emp
;
    DEPTNO ENAME           SAL   SUM_DEPT          %
---------- ------------- ----- ---------- ----------
        10 KING           5000      12350      40.49
        10 CLARK          2450      12350      19.84
        10 Tiger          3600      12350      29.15
        10 MILLER         1300      12350      10.53
        20 FORD           3000       6775      44.28
        20 JONES          2975       6775      43.91
        20 SMITH           800       6775      11.81
        30 JAMES           950      12400       7.66
        30 TURNER         1500      12400       12.1
        30 BLAKE          2850      12400      22.98
        30 WARD           1250      12400      10.08
        30 ALLEN          1600      12400       12.9
        30 Cat            3000      12400      24.19
        30 MARTIN         1250      12400      10.08

14 행이 선택되었습니다.