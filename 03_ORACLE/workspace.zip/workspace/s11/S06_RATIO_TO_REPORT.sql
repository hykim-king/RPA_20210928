SELECT p_code,
       --SUM(p_qty) OVER() "TOTAL_QTY",
	   SUM(p_total) OVER() "TOTAL_PRICE",
	   --p_qty,
	   p_total,
	   p_store,
	   --ROUND(RATIO_TO_REPORT( SUM(p_qty)) OVER()*100,2) "QTY_%",
	   ROUND(RATIO_TO_REPORT( SUM(p_total)) OVER()*100,2) "TOTAL_%"
FROM panmae
WHERE p_code =100
GROUP BY p_code,p_store,p_total;

P_CODE TOTAL_PRICE P_TOTAL P_STORE     TOTAL_%
------ ----------- ------- -------- ----------
   100       23200    2400 1000          10.34
   100       23200    2400 1001          10.34
   100       23200    4000 1004          17.24
   100       23200    8000 1004          34.48
   100       23200    1600 1000            6.9
   100       23200    3200 1003          13.79
   100       23200    1600 1002            6.9

7 행이 선택되었습니다.