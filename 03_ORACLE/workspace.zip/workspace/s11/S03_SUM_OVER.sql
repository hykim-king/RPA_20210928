--DESC panmae;
col p_date  for a8
col p_code  for 99999
col p_qty  for 99999
col p_total  for 99999
col p_store  for a8
col "TOTAL"  for 99999
SELECT p_date,
       p_code,
	   p_qty,
	   p_total,
	   SUM(p_total) OVER( ORDER BY p_total) "TOTAL",
	   p_store
FROM panmae
WHERE p_store = 1000
;
P_DATE   P_CODE  P_QTY P_TOTAL  TOTAL P_STORE
-------- ------ ------ ------- ------ --------
20110103    100      2    1600   1600 1000
20110102    102      2    2000   3600 1000
20110101    100      3    2400   6000 1000
20110102    105      2    3000   9000 1000