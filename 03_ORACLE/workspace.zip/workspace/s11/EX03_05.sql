SELECT deptno,
       ename,
	   sal,
	   SUM(sal) OVER(ORDER BY  sal) total
FROM emp
;

    DEPTNO ENAME           SAL   TOTAL
---------- ------------- ----- -------
        20 SMITH           800     800
        30 JAMES           950    1750
        30 MARTIN         1250    4250
        30 WARD           1250    4250
        10 MILLER         1300    5550
        30 TURNER         1500    7050
        30 ALLEN          1600    8650
        10 CLARK          2450   11100
        30 BLAKE          2850   13950
        20 JONES          2975   16925
        30 Cat            3000   22925
        20 FORD           3000   22925
        10 Tiger          3600   26525
        10 KING           5000   31525

14 행이 선택되었습니다.