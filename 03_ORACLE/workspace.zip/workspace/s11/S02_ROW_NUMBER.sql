col ename for a13
col sal   for 9999
col "ROW_NUMBER" for 99
col "RANK" for 99
col "DENSE_RANK" for 99
SELECT ename,
       sal,
	   ROW_NUMBER() OVER (ORDER BY sal ) "ROW_NUMBER",
	   RANK()OVER (ORDER BY sal ASC) "RANK",
	   DENSE_RANK() OVER(ORDER BY sal ASC) "DENSE_RANK"
FROM emp
;
ENAME           SAL ROW_NUMBER RANK DENSE_RANK
------------- ----- ---------- ---- ----------
SMITH           800          1    1          1
JAMES           950          2    2          2
WARD           1250          3    3          3
MARTIN         1250          4    3          3
MILLER         1300          5    5          4
TURNER         1500          6    6          5
ALLEN          1600          7    7          6
CLARK          2450          8    8          7
BLAKE          2850          9    9          8
JONES          2975         10   10          9
FORD           3000         11   11         10
KING           5000         12   12         11

12 행이 선택되었습니다.