SELECT MAX(s_sal)  "MAX", 
       MIN(s_sal)  "MIN",
	   ROUND(AVG(s_sal),1) "AVG"
FROM (SELECT NVL(sal,0)+NVL(comm,0) s_sal
	  FROM emp
)
;
--       MAX        MIN        AVG
------------ ---------- ----------
--      5000        800     2260.4