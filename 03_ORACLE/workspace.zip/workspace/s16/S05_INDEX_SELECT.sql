--DESC user_indexes;
--DESC user_ind_columns;

--EMP2 테이블 INDEX조회
-- 이름                          널?      유형             
-- --------------------------- -------- ---------------
-- INDEX_NAME                           VARCHAR2(128)
-- TABLE_NAME                           VARCHAR2(128)
-- COLUMN_NAME                          VARCHAR2(4000)
-- COLUMN_POSITION                      NUMBER
-- COLUMN_LENGTH                        NUMBER
-- CHAR_LENGTH                          NUMBER
-- DESCEND                              VARCHAR2(4)
-- COLLATED_COLUMN_ID                   NUMBER

col table_name   for a15
col column_name  for a15
col index_name   for a15
col descend      for a15
SELECT table_name,
       column_name,
	   index_name,
	   descend
FROM user_ind_columns
WHERE table_name = 'EMP2'
;

TABLE_NAME      COLUMN_NAME     INDEX_NAME      DESCEND
--------------- --------------- --------------- ---------------
EMP2            EMPNO           SYS_C007318     ASC
EMP2            NAME            EMP2_NAME_UK9   ASC

SELECT table_name,
       column_name,
	   index_name,
	   descend
FROM user_ind_columns
WHERE table_name = 'DEPT2'
;