--DEPT2 area 컬럼에 non-UNIQUE 인덱스 생성
col dcode for 9999
col dname for a25
col area for a25
SELECT dcode,
       dname,
	   area
FROM dept2;	  

DCODE        DNAME                     AREA
------------ ------------------------- -------------------------
9100         temp01                    Seoul Branch
0001         President                 Pohang Main Office
1000         Management Support Team   Seoul Branch Office
1001         Financial Management Team Seoul Branch Office
1002         General affairs           Seoul Branch Office
1003         Engineering division      Pohang Main Office
1004         H/W Support Team          Daejeon Branch Office
1005         S/W Support Team          Kyunggi Branch Office
1006         Business Department       Pohang Main Office
1007         Business Planning Team    Pohang Main Office
1008         Sales1 Team               Busan Branch Office
1009         Sales2 Team               Kyunggi Branch Office
1010         Sales3 Team               Seoul Branch Office
1011         Sales4 Team               Ulsan Branch Office

14 행이 선택되었습니다.

CREATE INDEX idx_dept2_area
ON dept2(area);