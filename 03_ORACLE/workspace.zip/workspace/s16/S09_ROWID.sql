SELECT ROWID,
       empno,
       ename
FROM emp
;

--ROWID                   EMPNO ENAME
-------------------- ---------- --------------------
--AAAR9dAAHAAAACWAAA       7369 SMITH
--AAAR9dAAHAAAACWAAB       7499 ALLEN
--AAAR9dAAHAAAACWAAC       7521 WARD
--AAAR9dAAHAAAACWAAD       7566 JONES
--AAAR9dAAHAAAACWAAE       7654 MARTIN
--AAAR9dAAHAAAACWAAF       7698 BLAKE
--AAAR9dAAHAAAACWAAG       7782 CLARK
--AAAR9dAAHAAAACWAAH       7839 KING
--AAAR9dAAHAAAACWAAI       7844 TURNER
--AAAR9dAAHAAAACWAAJ       7900 JAMES
--AAAR9dAAHAAAACWAAK       7902 FORD
--AAAR9dAAHAAAACWAAL       7934 MILLER
--
--12 행이 선택되었습니다.
--
--

SELECT ROWID,
       empno,
       ename
FROM emp
WHERE ROWID ='AAAR9dAAHAAAACWAAL'
;

ROWID                   EMPNO ENAME
------------------ ---------- --------------------
AAAR9dAAHAAAACWAAL       7934 MILLER