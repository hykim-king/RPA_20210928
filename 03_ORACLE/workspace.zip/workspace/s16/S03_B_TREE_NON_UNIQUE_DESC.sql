--professor 테이블에 pay컬럼
--CREATE INDEX ix_prof_pay
--ON professor (pay DESC);

--desc professor;
SELECT name,
       pay
FROM professor
WHERE pay>0
;

NAME                                            PAY
---------------------------------------- ----------
Meryl Streep                                    570
Audie Murphy                                    550
Emma Thompson                                   530
Meg Ryan                                        500
Whoopi Goldberg                                 490
Angela Bassett                                  380
Michelle Pfeiffer                               350
Julia Roberts                                   330
Susan Sarandon                                  330
Nicole Kidman                                   310
Sharon Stone                                    290
Jodie Foster                                    290
Jessica Lange                                   270
Holly Hunter                                    260
Winona Ryder                                    250
Andie Macdowell                                 220

16 행이 선택되었습니다.

SELECT name,
       pay
FROM professor;

NAME                                            PAY
---------------------------------------- ----------
Audie Murphy                                    550
Angela Bassett                                  380
Jessica Lange                                   270
Winona Ryder                                    250
Michelle Pfeiffer                               350
Whoopi Goldberg                                 490
Emma Thompson                                   530
Julia Roberts                                   330
Sharon Stone                                    290
Meryl Streep                                    570
Susan Sarandon                                  330
Nicole Kidman                                   310
Holly Hunter                                    260
Meg Ryan                                        500
Andie Macdowell                                 220
Jodie Foster                                    290

16 행이 선택되었습니다.