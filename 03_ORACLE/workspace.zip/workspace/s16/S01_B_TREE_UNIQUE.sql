--dept2 name unique 인덱스 생성
CREATE UNIQUE INDEX ID_DEPT2_NAME
ON dept2(dname)
;

name에 중복값 입력 여부 확인.

DESC dept2;
SELECT dcode,
       dname
FROM dept2;	   

INSERT INTO dept2 VALUES (9100,'temp01',1006,'Seoul Branch');

INSERT INTO dept2 VALUES (9101,'temp01',1006,'Busan Branch');

--1행에 오류:
--ORA-00001: 무결성 제약 조건(SCOTT.ID_DEPT2_NAME)에 위배됩니다.

*키 컬럼의 데이터들이 중복이 없다는 유일성을 보장하는 인덱스라 속도는 빠르지만
반면 중복되는 데이터가 들어올 수 없다는 단점이 있다.