--emp 테이블에서 ename, job

--desc emp;

--SELECT ename, 
--       job
--FROM emp;	   
ENAME                JOB
-------------------- ------------------
SMITH                CLERK
ALLEN                SALESMAN
WARD                 SALESMAN
JONES                MANAGER
MARTIN               SALESMAN
BLAKE                MANAGER
CLARK                MANAGER
KING                 PRESIDENT
TURNER               SALESMAN
JAMES                CLERK
FORD                 ANALYST
MILLER               CLERK

12 행이 선택되었습니다.
--CREATE INDEX idx_emp_comp
--ON emp(ename, job);

SELECT ename,
       job
FROM emp
WHERE ename > '0'
AND job > '0'
;	   
ENAME                JOB
-------------------- ------------------
ALLEN                SALESMAN
BLAKE                MANAGER
CLARK                MANAGER
FORD                 ANALYST
JAMES                CLERK
JONES                MANAGER
KING                 PRESIDENT
MARTIN               SALESMAN
MILLER               CLERK
SMITH                CLERK
TURNER               SALESMAN
WARD                 SALESMAN

12 행이 선택되었습니다.