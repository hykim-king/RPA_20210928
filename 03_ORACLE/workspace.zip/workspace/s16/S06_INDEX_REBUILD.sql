STEP.1 
CREATE TABLE i_test(
	no NUMBER,
	name VARCHAR2(20)
);

10000건 입력
BEGIN
	FOR i IN 1..10000 LOOP
		INSERT INTO i_test VALUES (i, 'eStudent'||i);
	END LOOP;
	COMMIT;

END;
/

건수 확인
SELECT  COUNT(*)
FROM i_test
;

NO INDEX DESC 생성
CREATE INDEX idx_itest_no
ON i_test(no DESC)
;

STEP. 2 인텍스 상태 조회						

STATIC DICTIONARY조회 하므로 통계정보 갱신
ANALYZE INDEX IDX_ITEST_NO VALIDATE STRUCTURE;


DESC index_stats;
lf_rows_len:     입력데이터
del_lf_rows_len: 삭제 데이터

SELECT lf_rows_len,
       del_lf_rows_len,
	   (del_lf_rows_len/lf_rows_len)*100 balance
FROM index_stats
WHERE name = 'IDX_ITEST_NO'	  
;     

--BALANCE가 0에 가까울 수록 우수.
LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
----------- --------------- ----------
     159801               0          0
	 
STEP. 3 10000건중에 4000건 삭제후 인텍스 상태 조회													
SELECT COUNT(*)
FROM i_test	 
WHERE no BETWEEN 1 AND 4000
;

DELETE FROM i_test	 
WHERE no BETWEEN 1 AND 4000
;

SELECT COUNT(*)
FROM i_test	 

COMMIT;

STATIC DICTIONARY조회 하므로 통계정보 갱신
ANALYZE INDEX IDX_ITEST_NO VALIDATE STRUCTURE;

SELECT lf_rows_len,
       del_lf_rows_len,
	   (del_lf_rows_len/lf_rows_len)*100 balance
FROM index_stats
WHERE name = 'IDX_ITEST_NO'	  
;


--BALANCE가 0에 가까울 수록 우수.(39.9628288 만큼 BALANCE무너 짐)
LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
----------- --------------- ----------
     159801           63861 39.9628288

STEP. 4 Rebuild			

ALTER INDEX IDX_ITEST_NO REBUILD;

--STATIC DICTIONARY조회 하므로 통계정보 갱신
ANALYZE INDEX IDX_ITEST_NO VALIDATE STRUCTURE;


SELECT lf_rows_len,
       del_lf_rows_len,
	   (del_lf_rows_len/lf_rows_len)*100 balance
FROM index_stats
WHERE name = 'IDX_ITEST_NO'	  
;

LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
----------- --------------- ----------
      95940               0          0