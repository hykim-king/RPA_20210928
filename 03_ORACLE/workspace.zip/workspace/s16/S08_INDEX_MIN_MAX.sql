--SELECT MIN(name)
--FROM new_emp4
--;
--
--
--SELECT MAX(name)
--FROM new_emp4
--;
--
--MIN(NAME)
----------------------
--ALLEN
--
--
--MAX(NAME)
----------------------
--SMITH
--explain plan for
--SELECT MIN(name)
--FROM new_emp4
--;
--col plan_table_output format a80;									
--select * from table(dbms_xplan.display);									


--INDEX ASC 사용 최소값 
--SELECT name
--FROM new_emp4
--WHERE name > '0'
--AND ROWNUM = 1
--;

--ORACLE HINT : /*+ HINT   */
SELECT /*+ INDEX_DESC(t1 IDX_NEWEMP4_NAME) */ MAX(name)
FROM new_emp4 t1
WHERE name > '0'
AND ROWNUM = 1
;

NAME
--------------------
SMITH