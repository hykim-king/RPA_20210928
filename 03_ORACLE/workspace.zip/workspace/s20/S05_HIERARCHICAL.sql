--col "depth_name" for a20
--col  LEVEL  for 99
--col  empno  for 9999
--col "MGR_NM" for a20
--col "depth_list" for a30

--계층 구조가 회손된다.
--SELECT LEVEL,
--       empno,
--	   PRIOR ename as "MGR_NM",
--       LPAD(' ',LEVEL*2,' ')|| ename "depth_name",
--	   SYS_CONNECT_BY_PATH(ename,'-') "depth_list"
--FROM emp
--WHERE ename <> 'JONES'
--CONNECT BY PRIOR empno = mgr
--START WITH mgr IS NULL 
--ORDER SIBLINGS BY ename
--; 

--LEVEL EMPNO MGR_NM               depth_name           depth_list
------- ----- -------------------- -------------------- ------------------------------
--    1  7839                        KING               -KING
--    2  7698 KING                     BLAKE            -KING-BLAKE
--    3  7499 BLAKE                      ALLEN          -KING-BLAKE-ALLEN
--    3  7900 BLAKE                      JAMES          -KING-BLAKE-JAMES
--    3  7654 BLAKE                      MARTIN         -KING-BLAKE-MARTIN
--    3  7844 BLAKE                      TURNER         -KING-BLAKE-TURNER
--    3  7521 BLAKE                      WARD           -KING-BLAKE-WARD
--    2  7782 KING                     CLARK            -KING-CLARK
--    3  7934 CLARK                      MILLER         -KING-CLARK-MILLER
--    3  7902 JONES                      FORD           -KING-JONES-FORD
--    4  7369 FORD                         SMITH        -KING-JONES-FORD-SMITH
--
--11 행이 선택되었습니다.

--계층 구조에서 일부분만 계층화(하위 요소들도 같이 삭제)
col  empno  for 9999
col "MGR_NM" for a20
col "depth_list" for a30
SELECT LEVEL,
       empno,
	   PRIOR ename as "MGR_NM",
       LPAD(' ',LEVEL*2,' ')|| ename "depth_name",
	   SYS_CONNECT_BY_PATH(ename,'-') "depth_list"
FROM emp 
CONNECT BY PRIOR empno = mgr
      AND ename <> 'JONES'
START WITH mgr IS NULL 
ORDER SIBLINGS BY ename
; 

LEVEL EMPNO MGR_NM               depth_name           depth_list
----- ----- -------------------- -------------------- ------------------------------
    1  7839                        KING               -KING
    2  7698 KING                     BLAKE            -KING-BLAKE
    3  7499 BLAKE                      ALLEN          -KING-BLAKE-ALLEN
    3  7900 BLAKE                      JAMES          -KING-BLAKE-JAMES
    3  7654 BLAKE                      MARTIN         -KING-BLAKE-MARTIN
    3  7844 BLAKE                      TURNER         -KING-BLAKE-TURNER
    3  7521 BLAKE                      WARD           -KING-BLAKE-WARD
    2  7782 KING                     CLARK            -KING-CLARK
    3  7934 CLARK                      MILLER         -KING-CLARK-MILLER

9 행이 선택되었습니다.