col name for a20
col mgr_name for a20
SELECT t1.name,
       PRIOR  t1.name AS mgr_name     
FROM emp2 t1
START WITH t1.pempno IS NULL
CONNECT BY PRIOR t1.empno = t1.pempno
;