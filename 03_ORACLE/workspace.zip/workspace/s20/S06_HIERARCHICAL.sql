col level for 99
col ename for a20
col "ORDER(ROW->HIGH)" for a30
SELECT level,
       LPAD(ename, LEVEL*5,'*') ename,
	   SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
FROM emp
START WITH empno = 7369
CONNECT BY empno = PRIOR mgr
;

LEVEL ENAME                ORDER(ROW->HIGH)
----- -------------------- ------------------------------
    1 SMITH                ->SMITH
    2 ******FORD           ->SMITH->FORD
    3 **********JONES      ->SMITH->FORD->JONES
    4 ****************KING ->SMITH->FORD->JONES->KING


col level for 99
col ename for a20
col "ORDER(ROW->HIGH)" for a30
SELECT level,
       LPAD(ename, LEVEL*5,'*') ename,
	   SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
FROM emp
WHERE CONNECT_BY_ISLEAF = 0
START WITH empno = 7369
CONNECT BY empno = PRIOR mgr
;
마지막 king 사라짐
LEVEL ENAME                ORDER(ROW->HIGH)
----- -------------------- ------------------------------
    1 SMITH                ->SMITH
    2 ******FORD           ->SMITH->FORD
    3 **********JONES      ->SMITH->FORD->JONES

col level for 99
col ename for a20
col "ORDER(ROW->HIGH)" for a30
SELECT level,
       LPAD(ename, LEVEL*5,'*') ename,
	   SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
FROM emp
WHERE CONNECT_BY_ISLEAF = 1
START WITH empno = 7369
CONNECT BY empno = PRIOR mgr
;
--1을 주면 마지막 값만 볼수 있다.
--LEVEL ENAME                ORDER(ROW->HIGH)
------- -------------------- ------------------------------
--    4 ****************KING ->SMITH->FORD->JONES->KING