col "Name and Position" for a180
SELECT LPAD(t1.name||'-'||t2.dname||'-'||NVL(t1.position,'Team Worker'),LEVEL*25,'-') "Name and Position"       
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.name ='Kevin Costner'
CONNECT BY  t1.empno = PRIOR t1.pempno
ORDER SIBLINGS BY t1.name 
;