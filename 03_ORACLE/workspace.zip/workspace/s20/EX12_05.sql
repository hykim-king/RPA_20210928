col empno for 99999999
col "ENAME AND POSITION" for a67
SELECT t1.empno,
       t1.name ||'-'||t2.dname||'-'|| NVL(t1.position,'Team Worker') "ENAME AND POSITION",
	   (SELECT COUNT(*)
	    FROM emp2 e
		START WITH e.empno = t1.empno
		CONNECT BY PRIOR e.empno = e.pempno
	   )-1 count
FROM emp2 t1, dept2 t2
WHERE t1.deptno = t2.dcode
ORDER BY 3 DESC
;
    EMPNO ENAME AND POSITION                                                       COUNT
--------- ------------------------------------------------------------------- ----------
 19900101 Kurt Russell-President-Boss                                                 19
 19970112 Val Kilmer-Business Department-Department head                               9
 19960212 Chris O'Donnell-Business Planning Team-Section head                          8
 19966102 Kevin Bacon-Engineering division-Department head                             4
 19960101 AL Pacino-Management Support Team-Department head                            3
 19930402 Hugh Grant-H/W Support Team-Section head                                     1
 19960303 Keanu Reeves-S/W Support Team-Deputy Section chief                           1
 20000210 Clint Eastwood-S/W Support Team-Team Worker                                  0
 20000101 Jack Nicholson-Sales1 Team-Team Worker                                       0
 20000102 Denzel Washington-Sales2 Team-Team Worker                                    0
 19950303 Gene Hackman-General affairs-Section head                                    0
 20000334 Kevin Costner-Sales4 Team-Team Worker                                        0
 20000305 JohnTravolta-Sales1 Team-Team Worker                                         0
 20006106 Robert De Niro-Sales2 Team-Team Worker                                       0
 20000407 Sly Stallone-Sales3 Team-Team Worker                                         0
 20000308 Tom Cruise-Sales4 Team-Team Worker                                           0
 20000119 Harrison Ford-H/W Support Team-Team Worker                                   0
 19970201 Woody Harrelson-Management Support Team-Section head                         0
 19930331 Tommy Lee Jones-Financial Management Team-Deputy department head             0
 20000203 Richard Gere-Sales3 Team-Team Worker                                         0

20 행이 선택되었습니다.