--1. START WITH											
--	-계층형 질의에 루트(부모행)										
--	-서브쿼리를 사용할수 있다.										
--											
--2. CONNECT BY											
--	-계층 질의에서 상위계층과 하위계층의 관계를 규정										
--	-PRIOR연산자와 함께 사용하여 계층 구조로 표현										
--		ex) connect by prior 자식컬럼 = 부모컬럼(부모에서 자식) top down									
--		ex) connect by  자식컬럼 = prior 부모컬럼(자식에서 부모로) bottom up									
--											
--3. LEVEL : Pseudo column											
--	- 계층 구조의 depth를 표현하는 컬럼										
--											
--4. 계층 구조간의 정렬											
--	- ORDER BY SIBLINGS BY 										

col LEVEL for 9999
col "ENAME" for a20
SELECT LEVEL,
       LPAD(ename,LEVEL*4,'*') "ENAME"
FROM emp
CONNECT BY  empno = PRIOR mgr
START WITH empno = 7839
;

LEVEL ENAME
----- --------------------
    1 KING

SELECT LEVEL,
       LPAD(ename,LEVEL*5,'-') "ENAME"
FROM emp
CONNECT BY  empno = PRIOR mgr
START WITH empno = 7369
;

LEVEL ENAME
----- --------------------
    1 SMITH
    2 ------FORD
    3 ----------JONES
    4 ----------------KING