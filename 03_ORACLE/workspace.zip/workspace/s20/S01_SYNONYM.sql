scott에 권한 할당
09:13:57 SCOTT>conn / as sysdba
SCOTT
GRANT CREATE SYNONYM TO scott;

--여러 사람들이 한꺼번에 볼수 있도록
GRANT CREATE PUBLIC SYNONYM TO scott;
권한이 부여되었습니다.


권한이 부여되었습니다.

생성
scott에 emp테이블에 동이어를 e
09:16:16 SYS>conn scott/scott

CREATE SYNONYM e FOR emp;

scott에 dept테이블에 동이어를 d2
모든 USER가 d2로 dept를 접근 가능
CREATE PUBLIC  SYNONYM d2 FOR dept;
SELECT *
FROM e;

SELECT *
FROM d2;

    DEPTNO DNAME                        LOC
---------- ---------------------------- --------------------------
        10 ACCOUNTING                   NEW YORK
        20 RESEARCH                     DALLAS
        30 SALES                        CHICAGO
        40 OPERATIONS                   BOSTON

SYNONYM조회
DESC user_synonyms;
l synonym_name FOR a15
l table_owner FOR a10
l table_name FOR a10
SELECT synonym_name,
       table_owner,
	   table_name
FROM user_synonyms
WHERE table_name = 'EMP'
;
SYNONYM_NAME    TABLE_OWNE TABLE_NAME
--------------- ---------- ----------
E               SCOTT      EMP

public SYNONYM user_synonyms에 보이지 않는다.
dba_synonyms에서 조회 가능.

SELECT synonym_name,
       table_owner,
	   table_name
FROM dba_synonyms
WHERE table_name = 'DEPT'

SYNONYM_NAME    TABLE_OWNE TABLE_NAME
--------------- ---------- ----------
D2              SCOTT      DEPT

시노님 삭제
DROP PUBLIC SYNONYM D2;

동의어가 삭제되었습니다.