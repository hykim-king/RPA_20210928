UPDATE board
SET read_cnt = NVL(read_cnt,0)+1
WHERE board_id = &board_id
;