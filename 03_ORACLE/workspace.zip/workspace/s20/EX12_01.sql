--13:17:06 SCOTT>desc emp2;
-- 이름             널?      유형
-- --------------- -------- -----------------
-- EMPNO           NOT NULL NUMBER
-- NAME            NOT NULL VARCHAR2(30)
-- BIRTHDAY                 DATE
-- DEPTNO          NOT NULL VARCHAR2(6)
-- EMP_TYPE                 VARCHAR2(30)
-- TEL                      VARCHAR2(15)
-- HOBBY                    VARCHAR2(30)
-- PAY                      NUMBER
-- POSITION                 VARCHAR2(30)
-- PEMPNO                   NUMBER
-- 
--13:17:17 SCOTT>desc dept2
-- 이름          널?      유형
-- ----------- -------- ------------------------------------
-- DCODE       NOT NULL VARCHAR2(6)
-- DNAME       NOT NULL VARCHAR2(30)
-- PDEPT                VARCHAR2(6)
-- AREA                 VARCHAR2(30) 

--col EMPNO for 999999999999999
col "Name and Position" for a150
SELECT LPAD(t1.name||'-'||t2.dname||'-'||NVL(t1.position,'Team Worker'),LEVEL*25,'-') "Name and Position"       
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.pempno IS NULL
CONNECT BY PRIOR t1.empno = t1.pempno
ORDER SIBLINGS BY t1.name
;


