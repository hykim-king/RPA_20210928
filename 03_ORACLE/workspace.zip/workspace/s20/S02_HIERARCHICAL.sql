--DESC emp;
--col empno for 9999
--col ename for a20
--col mgr for 9999
--SELECT empno,
--       ename,
--	   mgr
--FROM emp;

col LEVEL for 9999
col "ENAME" for a20
SELECT LEVEL,
       LPAD(ename,LEVEL*4,'*') "ENAME"
FROM emp
CONNECT BY PRIOR empno = mgr
START WITH empno = 7839
;
LEVEL ENAME
----- --------------------
    1 KING
    2 ***JONES
    3 ********FORD
    4 ***********SMITH
    2 ***BLAKE
    3 *******ALLEN
    3 ********WARD
    3 ******MARTIN
    3 ******TURNER
    3 *******JAMES
    2 ***CLARK
    3 ******MILLER

12 행이 선택되었습니다.