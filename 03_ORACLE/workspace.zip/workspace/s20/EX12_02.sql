--SELECT  name,empno
--FROM emp2
--WHERE name ='Kevin Bacon'
--;
--
--NAME                        EMPNO
------------------ ----------------
--Kevin Bacon              19966102


col "Name and Position" for a170
SELECT LPAD(t1.name||'-'||t2.dname||'-'||NVL(t1.position,'Team Worker'),LEVEL*26,'-') "Name and Position"       
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.empno ='19966102'
CONNECT BY PRIOR t1.empno = t1.pempno
ORDER SIBLINGS BY t1.name
;

-- Name and Position
-- ----------------------------------------------------------------------------------------------------
-- Kevin Bacon-Engineering di
-- ------------Hugh Grant-H/W Support Team-Section head
-- ------------------------------------Harrison Ford-H/W Support Team-Team Worker
-- --Keanu Reeves-S/W Support Team-Deputy Section chief
-- -----------------------------------Clint Eastwood-S/W Support Team-Team Worker