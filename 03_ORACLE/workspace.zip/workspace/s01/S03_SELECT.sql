--원하는 컬럼만 조회 하기.
--keywork는 대문자,
--컬럼, 테이블은 소문자
SELECT empno,
       ename
FROM emp
;