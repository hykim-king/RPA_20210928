--sql 한줄 comment 
--SELECT명령어를 이용한 데이터 조회
--SELECT [컬럼 또 표현식] FROM [테이블,뷰]

--SELECT *
--FROM emp
--;

--테이블에 구조 보기
--DESC 테이블명
--DESC  dept
--;
--이름                                      널?      유형
-- ----------------------------------------- -------- ----------------------------
-- DEPTNO                                    NOT NULL NUMBER(2)
-- DNAME                                              VARCHAR2(14)
-- LOC                                                VARCHAR2(13)

DESC emp;
