--1.시퀀스의 사용
--CREATE TABLE s_order(
--  ord_no NUMBER(4),
--  ord_name VARCHAR2(10),
--  p_name VARCHAR2(20),
--  p_qty NUMBER
--);

--2.데이터 입력
--INSERT INTO s_order VALUES (jon_seq.NEXTVAL,'james','apple',3);
--INSERT INTO s_order VALUES (jon_seq.NEXTVAL,'Ford','berry',5);

--SELECT ord_no,p_name,p_qty
--FROM s_order;
--
--    ORD_NO P_NAME                                        P_QTY
------------ ---------------------------------------- ----------
--       100 apple                                             3
--       101 berry                                             5

--현재 시퀀스 값
--SELECT jon_seq.CURRVAL
--FROM dual;

--MAXVALUE와 MINVALUE 테스트

--BEGIN
--	FOR i IN 1..9 LOOP
--	  INSERT INTO s_order VALUES (jon_seq.NEXTVAL,'Allen','Banana',3); 
--	END LOOP;
--	COMMIT;
--END;
--/

--SELECT ord_no,p_name,p_qty
--FROM s_order;
--    ORD_NO P_NAME                                        P_QTY
------------ ---------------------------------------- ----------
--       100 apple                                             3
--       101 berry                                             5
--       102 Banana                                            3
--       103 Banana                                            3
--       104 Banana                                            3
--       105 Banana                                            3
--       106 Banana                                            3
--       107 Banana                                            3
--       108 Banana                                            3
--       109 Banana                                            3
--       110 Banana                                            3
--
--11
--INSERT INTO s_order VALUES (jon_seq.NEXTVAL,'Smith','Grape',3);

SELECT ord_no,p_name,p_qty
FROM s_order;

--    ORD_NO P_NAME                                        P_QTY
------------ ---------------------------------------- ----------
--       100 apple                                             3
--       101 berry                                             5
--       102 Banana                                            3
--       103 Banana                                            3
--       104 Banana                                            3
--       105 Banana                                            3
--       106 Banana                                            3
--       107 Banana                                            3
--       108 Banana                                            3
--       109 Banana                                            3
--       110 Banana                                            3
--        90 Grape                                             3
--
--12 행이 선택되었습니다.