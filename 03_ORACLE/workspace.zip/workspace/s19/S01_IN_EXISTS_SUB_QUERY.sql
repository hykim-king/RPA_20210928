--고객테이블 (CUST_T) 9000건 입력(SAMLL TABLE)																				
--주문테이블(ORDER_T)3,000,000건 입력(BIG TABLE)																				
--		우리 고객중 한 번이라도 주문을 한 고객이 몇 명인지를 안고 싶을때.																		
--1. Sub query에 T2테이블이 매우크고 T1 테이블이 상대적으로 작다면 , 그리고 t2테이블 c1컬럼에 인덱스가 존재하면																																	
--Exists연산자가 IN연산자에 비해 빠르다.																																	
--																																	
--2. T1테이블이 매우크고, T2테이블이 작다면 그리고 t1테이블에 c1컬럼에 인덱스가 존재하면 IN연산자가 빠르다.																																	

--SMALL TABLE 생성, 9000건 입력
--CREATE TABLE cust_t (
--  cust_no VARCHAR2(1000),
--  cust_nm VARCHAR2(1000)
--);

--INSERT INTO cust_t
--SELECT level,'NM'||TO_CHAR(level,'000')
--FROM dual
--CONNECT BY level <=9000
--;
--COMMIT;

--입력건 확인
--SELECT COUNT(*)
--FROM cust_t;
--
--  COUNT(*)
------------
--      9000

--주문테이블
--CREATE TABLE order_t(
--  order_no VARCHAR2(4000),
--  cust_no  VARCHAR2(1000),
--  orderdd  VARCHAR2(8),
--  product_nm VARCHAR2(4000)
--);

--데이터 입력 300만건
--INSERT INTO order_t
--SELECT level AS order_no,
--       MOD(level,500) AS cust_no,
--	   TO_CHAR(sysdate - mod(LEVEL,30),'YYYYMMDD') AS orderdd,
--	   'TEST PRODUCT LONG NAME~~' AS product_nm
--FROM dual
--CONNECT BY LEVEL < =1000000;
--
--COMMIT;
--
--SELECT COUNT(*) FROM order_t;

--ANALYZE TABLE ORDER_T COMPUTE STATISTICS;   
--ANALYZE TABLE CUST_T COMPUTE STATISTICS;  
--col table_name for a10
--SELECT table_name,
--       num_rows,
--	   blocks,
--	   avg_row_len,
--	   sample_size
--FROM user_tables
--WHERE TABLE_NAME IN ('ORDER_T','CUST_T')
--;

--주문 테이블에 INDEX생성 : cust_no
--1. Sub query에 T2테이블이 매우크고 T1 테이블이 상대적으로 작다면 , 그리고 t2테이블 c1컬럼에 인덱스가 존재하면																																	
--Exists연산자가 IN연산자에 비해 빠르다.		

--CREATE INDEX ix_order_t_01 
--ON ORDER_T(cust_no);

--EXISTS연산자 서브 쿼리 수행
--SET TIMING ON
--SELECT COUNT(*)
--FROM cust_t a
--WHERE EXISTS ( SELECT 1 
--               FROM order_t b 
--			   WHERE a.cust_no =b.cust_no);
--			   
--  COUNT(*)
------------
--       499
--
--경   과: 00:00:00.21			   

--EXISTS 실행 계획
--explain plan for
--SELECT COUNT(*)
--FROM cust_t a
--WHERE EXISTS ( SELECT 1 
--               FROM order_t b 
--			   WHERE a.cust_no =b.cust_no);
			   		   
--col plan_table_output format a80;			   
--select * from table(dbms_xplan.display);

--PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------
--Plan hash value: 3864235660
--
------------------------------------------------------------------------------------------
--
--| Id  | Operation              | Name          | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT       |               |     1 |     7 |   588   (4)| 00:00:01 |
--|   1 |  SORT AGGREGATE        |               |     1 |     7 |            |          |
--|*  2 |   HASH JOIN SEMI       |               |   500 |  3500 |   588   (4)| 00:00:01 |
--|   3 |    TABLE ACCESS FULL   | CUST_T        |  9000 | 36000 |     9   (0)| 00:00:01 |
--|   4 |    INDEX FAST FULL SCAN| IX_ORDER_T_01 |  1000K|  2929K|   570   (2)| 00:00:01 |
------------------------------------------------------------------------------------------
--
--
--Predicate Information (identified by operation id):
-----------------------------------------------------
--
--   2 - access("A"."CUST_NO"="B"."CUST_NO")
--
--Note
-------
--   - this is an adaptive plan
--
--20 행이 선택되었습니다.

--2. T1테이블이 매우크고, T2테이블이 작다면 그리고 t1테이블에 c1컬럼에 인덱스가 존재하면 IN연산자가 빠르다.

--기존 인덱스 삭제 
--DROP INDEX ix_order_t_01;


--cust_t cust_no에 인덱스 생성
--CREATE INDEX ix_cust_t_01 
--ON cust_t(cust_no);

--IN연산자 서브 쿼리로 수행: HINT사용
--set timing on
----LEADING : 먼전 읽을 테이블
----use_nl: join을 nested loop join을 수행 하시오.
--SELECT /*+ LEADING(order_t) use_nl(order_t cust_t) */
--       COUNT(*)
--FROM cust_t
--WHERE cust_no IN ( SELECT cust_no FROM order_t)
--;

--경   과: 00:00:00.43

--실행 계획

--explain plan for
--SELECT /*+ LEADING(order_t) use_nl(order_t cust_t) */
--       COUNT(*)
--FROM cust_t
--WHERE cust_no IN ( SELECT cust_no FROM order_t)
--;

col plan_table_output format a80;			   
select * from table(dbms_xplan.display);



PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------
Plan hash value: 2788842126

-------------------------------------------------------------------------------------

| Id  | Operation            | Name         | Rows  | Bytes | Cost (%CPU)| Time|
-------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT     |              |     1 |     7 |  7636   (2)| 00:00:01 |
|   1 |  SORT AGGREGATE      |              |     1 |     7 |            | |
|   2 |   NESTED LOOPS       |              |   500 |  3500 |  7636   (2)| 00:00:01 |
|   3 |    SORT UNIQUE       |              |  1000K|  2929K|  4416   (1)| 00:00:01 |
|   4 |     TABLE ACCESS FULL| ORDER_T      |  1000K|  2929K|  4416   (1)| 00:00:01 |
|*  5 |    INDEX RANGE SCAN  | IX_CUST_T_01 |     1 |     4 |     1   (0)| 00:00:01 |
-------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("CUST_NO"="CUST_NO")
17 행이 선택되었습니다.

경   과: 00:00:00.15



