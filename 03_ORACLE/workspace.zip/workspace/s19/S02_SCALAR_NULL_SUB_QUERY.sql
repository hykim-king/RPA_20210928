--DEPT2에 없는 부서 입력
--INSERT INTO emp2(
--    empno,
--	name,
--	birthday,
--	deptno,
--	emp_type,
--	tel
--)VALUES(
--    2020000219,
--	'Ray',
--	TO_DATE('1988/03/22','YYYY/MM/DD'),
--	'999',
--	'Intern',
--	'02)909-2345'
--);

--commit;
--DESC dept2;
--SELECT dcode
--FROM dept2;

--EMP2 NAME, DEPT DNAME
COL name FOR a35
COL dname FOR a35
--null처리 않됨.
--SELECT t1.name,
--       (SELECT NVL(t2.dname,'NOT BELOG TO A DEPT')
--	    FROM dept2 t2
--		WHERE t1.deptno = t2.dcode
--		) dname
--FROM emp2 t1
--;

SELECT t1.name,
       NVL((SELECT t2.dname
	        FROM dept2 t2
		    WHERE t1.deptno = t2.dcode
		  ),'NOT BELOG TO A DEPT') dname
FROM emp2 t1
;

NAME                                DNAME
----------------------------------- -----------------------------------
Ray                                 NOT BELOG TO A DEPT
Kurt Russell                        President
AL Pacino                           Management Support Team
Woody Harrelson                     Management Support Team
Tommy Lee Jones                     Financial Management Team
Gene Hackman                        General affairs
Kevin Bacon                         Engineering division
Hugh Grant                          H/W Support Team
Keanu Reeves                        S/W Support Team
Val Kilmer                          Business Department
Chris O'Donnell                     Business Planning Team
Jack Nicholson                      Sales1 Team
Denzel Washington                   Sales2 Team
Richard Gere                        Sales3 Team
Kevin Costner                       Sales4 Team
JohnTravolta                        Sales1 Team
Robert De Niro                      Sales2 Team
Sly Stallone                        Sales3 Team
Tom Cruise                          Sales4 Team
Harrison Ford                       H/W Support Team
Clint Eastwood                      S/W Support Team

21 행이 선택되었습니다.
