--CREATE OR REPLACE PROCEDURE SCOTT.res_sequence (sequencename IN VARCHAR2) 
--as curr_val INTEGER;
--BEGIN
--  EXECUTE IMMEDIATE 'alter sequence ' ||sequencename||' MINVALUE 0';
--  EXECUTE IMMEDIATE 'SELECT ' ||sequencename ||'.nextval FROM dual' INTO curr_val;
--  EXECUTE IMMEDIATE 'alter sequence ' ||sequencename||' increment by -'||curr_val;
--  EXECUTE IMMEDIATE 'SELECT ' ||sequencename ||'.nextval FROM dual' INTO curr_val;
--  EXECUTE IMMEDIATE 'alter sequence ' ||sequencename||' increment by 1';
--END res_sequence;

--시퀀스 생성
--CREATE SEQUENCE seq_test;

--시퀀스 증가
--SELECT seq_test.NEXTVAL
--FROM dual;


--초기화
--EXEC res_sequence('SEQ_TEST');
--PL/SQL 처리가 정상적으로 완료되었습니다.
SELECT seq_test.CURRVAL
FROM dual;

--   CURRVAL
------------
--         0