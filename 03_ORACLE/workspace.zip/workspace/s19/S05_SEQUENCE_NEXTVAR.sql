--CREATE SEQUENCE jno_seq_rev
--INCREMENT BY -2
--START WITH 10
--MINVALUE 0
--MAXVALUE 20
--;


--CREATE TABLE s_rev1 ( no NUMBER);
--6번 반복: 6번째 오류

INSERT INTO s_rev1 VALUES (jno_seq_rev.NEXTVAL);

--*
--1행에 오류:
--ORA-08004: 시퀀스 JNO_SEQ_REV.NEXTVAL goes below MINVALUE은 사례로 될 수 없 습니다