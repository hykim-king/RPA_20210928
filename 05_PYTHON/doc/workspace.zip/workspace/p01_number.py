#숫자형: 정수, 실수, 8진수, 16진수

#숫자형은 어떻게 만들고 사용할까?
#정수형: 양에 정수, 음에 정수, 0
a = 123
print(a)

a = -178
print(a)

a = 0
print(a)

#실수형: 소숫점이 포함된 숫자
a = 1.2
print(a)

a = -3.14
print( a )

#10에 10승
a = 4.24E10
print(a) #42400000000.0

a = 4.24e-10 #4.24e-10
print( a )

#8진수 : 0숫자+알파벳 소문자 o/O
a = 0o16

print(a) #14

#16진수 : 0숫자+알파벳 소문자 x
a = 0xF
print(a) #15

#숫자형을 활용하기 위한 연산자
#사칙연산
a = 3
b = 4
print(a+b)
print(a-b)
print(a*b)
print(a/b) #0.75

# %:나머지 연산
print(a%b) #3

# //: 몫을 반환
print(a//b) #0
# / : 나누기

#x의 y제곱 연산자 : **
print(a ** b) #81