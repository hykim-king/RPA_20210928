pocket = ['paper','cellphone']
card = True
#and : &&
#or  : ||
#not : not x

if 'money' in pocket and card:
    print('if 택시를 타고 가라!')
    print('if 택시를 타고 가라!')
elif card == True :
    print('elif 택시를 타고 가라!') #택시를 타고 가라!
else:
    print('걸어 가라!')


