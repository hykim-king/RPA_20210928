add = 0
for i in range(1,11):  # 1<=i<11
    add = add +1
    print(i)
print(add)
