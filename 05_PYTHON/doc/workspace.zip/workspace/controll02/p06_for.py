test_list =['one','two','three']
for i in test_list:
    print(i)