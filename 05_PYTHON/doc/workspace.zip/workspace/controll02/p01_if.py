money = 2000
if money >= 3000:
    print('택시를 타고 가라')
else:
    print('걸어 가라')

    