coffee = 10 # 자판기 커피 10잔 있음
money  = 300

while money:
    print("돈을 받았으니 커피를 줍니다.")
    coffee = coffee -1
    print("남은 커피는 %d잔 입니다." % coffee)
    if coffee == 0:
        print('커피가 없습니다. 판매를 중지 합니다.')
        break

