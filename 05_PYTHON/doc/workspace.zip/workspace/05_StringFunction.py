#문자열 관련 함수
# 문자 개수 세기(count)
a = "hobby"
#a문자열 에서 'b' 개수
print(a.count('b'))#2

#위치 알려 주기
a = "Life is too short"
print(a.find('t'))#8

#위치 알려 주기2 index
print(a.index("t"))#8


#문자열 삽입:join
print(",".join('abcd'))#abcd문자열 사이에 쉼표 삽입

#소문자를 대문자로 바꾸기(upper)
a = "hi"
print(a.upper()) #HI

#대문자를 소문자로 바꾸기(lower)
a = "HI"
print(a.lower()) #hi

#공백지우기 (lstrip:왼쪽,rstrip:오른쪽,strip:양쪽)
a = " hi "
print(a.strip())#hi

#문자열 바꾸기(replace)
a = "Life is too short"
print(a.replace("Life","Your leg")) #Your leg is too short

#문자열을 배열로 만들기(split)
print(a.split()) #['Life', 'is', 'too', 'short']

b = "a,b,c,d"
print(b.split(","))#['a', 'b', 'c', 'd']




