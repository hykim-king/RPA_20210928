import mod06.mod02
from mod02 import *

print(add(4,2))
a=mod06.mod02.Math()
print(a.solv(10))