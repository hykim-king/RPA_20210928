def say_myself(name, old, man=True):
    print("나의 이름은 %s 입니다." % name)
    print("나의 나이는 %d 입니다." % old)

    if man:
        print("남자 입니다.")
    else:
        print("여자 입니다.")

say_myself('이상무',24)
'''
나의 이름은 이상무 입니다.
나의 나이는 24 입니다.
남자 입니다.
'''
say_myself('이상무',24,False)
'''
나의 이름은 이상무 입니다.
나의 나이는 24 입니다.
여자 입니다
'''