#def 함수 이름(매개변수):
#  수행 할문장
#  수행 할문장

def add(a,b):
    return a+b

a = 3
b = 4
c = add(a,b)
print(c) #7

###############################
result = add(a=11,b=13)
print(result) #24

