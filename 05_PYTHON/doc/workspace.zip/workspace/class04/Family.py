class Family :
    lastname = "김"



a = Family()
b = Family()

print(a.lastname)#김
print(b.lastname)#김

Family.lastname = "박"
print(a.lastname)#박
print(b.lastname)#박