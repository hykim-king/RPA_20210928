class FourCal:

    def __init__(self,first,second):
        self.first  = first
        self.second = second

    def setdata(self,first,second):
        self.first  = first
        self.second = second

    def  add(self):
        result = self.first + self.second
        return result

    def  sub(self):
        result = self.first - self.second
        return result

    def  mul(self):
        result = self.first * self.second
        return result

    def  div(self):
        result = self.first / self.second
        return result

'''
a = FourCal(4,2)

print(a.first)#4
print(a.second)#2

print(a.add())#6
print(a.mul())#8
print(a.div())#2.0
print(a.sub())#2
'''

#상속
class MoreFourCal(FourCal):
    pass

a = MoreFourCal(4,2)
print(a.add()) #6
print(a.mul()) #8

