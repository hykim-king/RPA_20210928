print( "Hello, world" )
