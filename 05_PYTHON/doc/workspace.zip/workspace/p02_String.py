#문자열 자료형: ' ', " ", '''   ''', """ """

food = "Python's foot is perl"
print(food) #Python's foot is perl

say  = '" Python is very easy." he says.'
print(say) #" Python is very easy." he says.

food = "Python\'s foot is perl"
print(food) #Python's foot is perl

multiline = '''
             Life is too short
             You need python
'''
print(multiline)
#Life is too short
#You need python

#이스케이프 코드
# \n : 줄바 꿈
# \t : 탭 간격
# \\  : \를 표현
# \'  : '를 문자 그대로 표현
# \"  : "를 문자 그대로 표현

#문자열 연산
#1 문자열 더해서 연결하기
head = "Python"
tail = " is fun"
print( head + tail) #Python is fun

#2 문자열 곱하기
a = "-"
print(a*20) #--------------------

a = "Python"
print ( a * 5)

#3문자열 길이 : len() 함수로 구할수 있다.
a = "Life is too short"
print(len(a)) #17






