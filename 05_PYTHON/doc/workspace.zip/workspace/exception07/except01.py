
try:
    4/0
except ZeroDivisionError as e:
    print(e) #division by zero
