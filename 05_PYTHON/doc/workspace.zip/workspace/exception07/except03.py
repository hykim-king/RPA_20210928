try:
    f = open('없는 파일','r')
except FileNotFoundError as e:
    pass

#print("파일 경로를 확인 하세요. %s" % e) #파일 경로를 확인 하세요. [Errno 2] No such file or directory: '없는 파일'
