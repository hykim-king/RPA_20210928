class Bird:
    def fly(self):
        raise NotImplementedError



class Eagle(Bird):
    pass


eagle = Eagle()
eagle.fly()
