try:
    a = [1,2]
    2 / 0
    print(a[3])
except ZeroDivisionError as e:
    print("0으로 나눌 수 없습니다. %s" % e) #0으로 나눌 수 없습니다. division by zero
except IndexError:
    print("배열 인덱스 초과")

