dic01 = {1: 'hi'}
print(dic01) #{1: 'hi'}

#key value입력
dic01[2] = 'b'
print(dic01) #{1: 'hi', 2: 'b'}

#key값으로 value접근
grade ={'pay':10,'julliet':99}
print(grade['pay'])#10

#딕셔너리 함수
#keys() : key만을 모아서 객체 반환
a = {'name':'pey','phone':'01012345678','birth':'0126'}
print(a.keys()) #dict_keys(['name', 'phone', 'birth'])

for k in a.keys():
    #print(k)
    print(a.get(k))
    #print(a[k])

# values(): value만을 모아서 객체 반환
# items() : key value의 쌍을 튜플로 묶어 반환
# get() : key대응 되는 value출력




