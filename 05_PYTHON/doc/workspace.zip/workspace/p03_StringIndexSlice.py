#문자열 인덱싱 : 배열 형태로 구성( 파이썬은 0부터 인덱스를 준다.)
a  ="Life is too short, You need Python"
print(a[0])# L

# 인덱스가 -이면 오른쪽 끝에서 인덱스 시작
print(a[-1])# n
print(a[-2])# o
print(a[-0])# L

b  = a[0] + a[1] +a[2] +a[3]
print(b) #Life

#문자열 슬라이싱
#a[시작번호: 끝번호]
#시작은 포함, 끝번호는 미포함
#시작번호<= <끝번호

a  ="Life is too short, You need Python"

#0<= a <3
print(a[0:3]) #Life

strArray = "20220118Sunyday"
date = strArray[:8]
print(date) #20220118

weather = strArray[8:]
print(weather) #Sunyday