import requests

response = requests.get("https://www.naver.com")
print(response.status_code) #상태값
print(response.text) # web page 

