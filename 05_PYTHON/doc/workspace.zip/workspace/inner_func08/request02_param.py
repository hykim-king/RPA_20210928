import requests

url = "https://section.blog.naver.com/Search/Post.nhn"
params = {
    'pageNo' :1,
    'rangeType':'ALL',
    'orderBy':'sim',
    'keyword': 'python'
}

response = requests.get(url,params=params)
print(response.status_code)
print(response.url)
print(response.text)

