import requests
from bs4 import BeautifulSoup
import openpyxl

wb = openpyxl.Workbook()
sheet = wb.active

#header
sheet.append(['제목','채널','조회수','좋아요'])

#크롤링
response = requests.get("https://tv.naver.com/r")
html = BeautifulSoup(response.text,"html.parser")

container = html.select("div.inner")
#print(container)

for con in container:
    title=con.select_one("dt.title").text.strip()  #제목
    cha  =con.select_one("dd.chn").text.strip()    #채널
    hit  =con.select_one("span.hit").text.strip()  #조회수
    like = con.select_one("span.like").text.strip() #좋아요

    #sheet에 추가
    sheet.append([title,cha,hit,like])

wb.save("naver_tv.xlsx")
