import openpyxl
#workbook생성
wb    = openpyxl.Workbook()

#sheet활성화
sheet = wb.active

#cell에 기록
sheet['A1'] = 'PCWK'

#파일에 저장
wb.save("pcwk.xlsx")

## 행번호, 열번호로 데이터 입력하기
# sheet.cell(row = 1, column = 1).value = 1


