#절대값
print( abs(3))
print( abs(-3))

#아스키 코드에 해당하는 문자 return
print(chr(97))# a
print(chr(48))# 0

#len : 입력값의 길이 반환
print(len("python"))#6
print(len([1,2,3])) #3

#round : 반올림
print(round(4.6))#5
print(round(4.2))#4

print(round(5.678,2))#5.68

import calendar
print(calendar.calendar(2022))#2022년 전체 달력

print(calendar.prmonth(2022,1))#2022년 1월 달력