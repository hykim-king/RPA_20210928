import requests
import datetime
from bs4 import BeautifulSoup
from urllib.request import urlopen



now=datetime.datetime.now()
newDate=now.strftime("%Y-%m-%d %H:%M")
print("="*30)
print(newDate)
print("="*30)

#오늘의 날씨:https://weather.naver.com/today/09545101
print("#오늘에 날씨")
naverWetherUrl = "https://weather.naver.com/today/09545101"
html = urlopen(naverWetherUrl)
bsObject = BeautifulSoup(html,"html.parser")
tmpes  = bsObject.find('strong','current')
print('-->서울 날씨:',tmpes.getText())

codes = {'079550':'LIG넥스원','005930':'삼성전자'}
prices = {} #가격정보

for code in codes.keys():
    url = 'https://finance.naver.com/item/main.naver?code='+code
    response = requests.get(url)
    response.raise_for_status()
    html = response.text
    soup = BeautifulSoup(html,'html.parser')
    today = soup.select_one('#chart_area > div.rate_info > div')
    #print(todayPrice)
    price=today.select_one(".blind")
    prices[codes[code]] = price.get_text()
    #print(price.get_text())

print(prices)
'''
==============================
2022-01-26 11:26
==============================
#오늘에 날씨
-->서울 날씨: 현재 온도3°
{'LIG넥스원': '60,800', '삼성전자': '73,700'}
'''




