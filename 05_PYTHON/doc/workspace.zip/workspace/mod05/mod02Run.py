#from mod01 import add,sub
from mod01 import *

print(add(4,2))#6
print(sub(4,2))#2