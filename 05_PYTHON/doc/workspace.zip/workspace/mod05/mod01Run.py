import mod01

print(mod01.add(4,2))#6
print(mod01.sub(3,2))#1