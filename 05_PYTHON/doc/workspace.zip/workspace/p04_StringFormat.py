#문자열 포매팅
#숫자 대입 %d
#문자 대입 %s

strString = "I eat %d apples." % 3
print(strString) #I eat 3 apples.

strString = "I eat %s apples"  % 'five'
print(strString) #I eat five apples

#2개 이상 값 대입
number = 10
day    = "three"

strString = "I eat %d apples. so I was sick for %s days." %(number,day)
print(strString) #I eat 10 apples. so I was sick for three days.

#정렬과 공백
#%s를 숫자와 함께 하면 , 공백과 정렬 표현 가능
strString = "%10s" % "hi"
#+오른쪽 정렬
print(strString)#________hi

#-왼쪽 정렬
strString = "%-10s" % "hi"
print(strString)#hi________

#숫자 formatting
floatNum = "%0.4f"  % 3.123456
print(floatNum)#3.1235

floatNum = "%10.4f"  % 3.123456
print(floatNum)#____3.1235

name = "이상무"
age  = 24

strString = f"나에 이름은 {name}, 나이는 {age} 입니다."
print(strString)#나에 이름은 이상무, 나이는 24 입니다.




